// Technical Indicators - Pure calculation library

export interface Candle {
  openTime: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

// Simple Moving Average
export function sma(values: number[], period: number): number[] {
  const result: number[] = [];
  for (let i = 0; i < values.length; i++) {
    if (i < period - 1) {
      result.push(NaN);
    } else {
      const slice = values.slice(i - period + 1, i + 1);
      result.push(slice.reduce((a, b) => a + b, 0) / period);
    }
  }
  return result;
}

// Exponential Moving Average
export function ema(values: number[], period: number): number[] {
  const k = 2 / (period + 1);
  const result: number[] = [];
  let prev = NaN;

  for (let i = 0; i < values.length; i++) {
    if (i < period - 1) {
      result.push(NaN);
    } else if (i === period - 1) {
      const init =
        values.slice(0, period).reduce((a, b) => a + b, 0) / period;
      result.push(init);
      prev = init;
    } else {
      const val = values[i] * k + prev * (1 - k);
      result.push(val);
      prev = val;
    }
  }
  return result;
}

// RSI
export function rsi(closes: number[], period = 14): number[] {
  const result: number[] = new Array(closes.length).fill(NaN);
  if (closes.length < period + 1) return result;

  let avgGain = 0;
  let avgLoss = 0;

  for (let i = 1; i <= period; i++) {
    const change = closes[i] - closes[i - 1];
    if (change >= 0) avgGain += change;
    else avgLoss += Math.abs(change);
  }
  avgGain /= period;
  avgLoss /= period;

  for (let i = period + 1; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    const gain = change >= 0 ? change : 0;
    const loss = change < 0 ? Math.abs(change) : 0;

    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;

    if (avgLoss === 0) {
      result[i] = 100;
    } else {
      const rs = avgGain / avgLoss;
      result[i] = 100 - 100 / (1 + rs);
    }
  }
  return result;
}

// MACD
export function macd(
  closes: number[],
  fastPeriod = 12,
  slowPeriod = 26,
  signalPeriod = 9
): { macd: number[]; signal: number[]; histogram: number[] } {
  const fastEma = ema(closes, fastPeriod);
  const slowEma = ema(closes, slowPeriod);

  const macdLine = closes.map((_, i) => {
    if (isNaN(fastEma[i]) || isNaN(slowEma[i])) return NaN;
    return fastEma[i] - slowEma[i];
  });

  const validMacd = macdLine.map((v) => (isNaN(v) ? 0 : v));
  const signalLine = ema(validMacd, signalPeriod);

  const histogram = macdLine.map((m, i) => {
    if (isNaN(m) || isNaN(signalLine[i])) return NaN;
    return m - signalLine[i];
  });

  return { macd: macdLine, signal: signalLine, histogram };
}

// Bollinger Bands
export function bollingerBands(
  closes: number[],
  period = 20,
  stdDevMult = 2
): { upper: number[]; middle: number[]; lower: number[] } {
  const middle = sma(closes, period);
  const upper: number[] = [];
  const lower: number[] = [];

  for (let i = 0; i < closes.length; i++) {
    if (isNaN(middle[i])) {
      upper.push(NaN);
      lower.push(NaN);
    } else {
      const slice = closes.slice(i - period + 1, i + 1);
      const mean = middle[i];
      const variance =
        slice.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / period;
      const stdDev = Math.sqrt(variance);
      upper.push(mean + stdDevMult * stdDev);
      lower.push(mean - stdDevMult * stdDev);
    }
  }

  return { upper, middle, lower };
}

// ATR - Average True Range
export function atr(candles: Candle[], period = 14): number[] {
  const trs: number[] = [0];
  for (let i = 1; i < candles.length; i++) {
    const high = candles[i].high;
    const low = candles[i].low;
    const prevClose = candles[i - 1].close;
    const tr = Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose));
    trs.push(tr);
  }
  return sma(trs, period);
}

export type SignalType = "LONG" | "SHORT" | "HOLD";

export interface AnalysisResult {
  signal: SignalType;
  confidence: number; // 0-100
  rsiValue: number;
  macdValue: number;
  macdSignalValue: number;
  ema20Value: number;
  ema50Value: number;
  bbUpper: number;
  bbLower: number;
  bbMiddle: number;
  atrValue: number;
  reasons: string[];
}

// Main strategy: Multi-indicator confluence
export function analyzeMarket(candles: Candle[]): AnalysisResult {
  if (candles.length < 30) {
    return {
      signal: "HOLD",
      confidence: 0,
      rsiValue: 50,
      macdValue: 0,
      macdSignalValue: 0,
      ema20Value: candles[candles.length - 1]?.close ?? 0,
      ema50Value: candles[candles.length - 1]?.close ?? 0,
      bbUpper: 0,
      bbLower: 0,
      bbMiddle: 0,
      atrValue: 0,
      reasons: ["Not enough data"],
    };
  }

  const closes = candles.map((c) => c.close);
  const last = closes.length - 1;

  // Adapt periods based on available data
  const rsiPeriod = Math.min(14, Math.floor(candles.length / 3));
  const ema20Period = Math.min(20, Math.floor(candles.length / 3));
  const ema50Period = Math.min(50, Math.floor(candles.length / 2));
  const macdFast = Math.min(12, Math.floor(candles.length / 4));
  const macdSlow = Math.min(26, Math.floor(candles.length / 2));
  const macdSignalPeriod = Math.min(9, Math.floor(candles.length / 5));
  
  const rsiValues = rsi(closes, rsiPeriod);
  const macdResult = macd(closes, macdFast, macdSlow, macdSignalPeriod);
  const ema20 = ema(closes, ema20Period);
  const ema50 = ema(closes, ema50Period);
  const bb = bollingerBands(closes, Math.min(20, ema20Period), 2);
  const atrValues = atr(candles, Math.min(14, rsiPeriod));

  const rsiNow = rsiValues[last];
  const macdNow = macdResult.macd[last];
  const macdSignalNow = macdResult.signal[last];
  const macdHistNow = macdResult.histogram[last];
  const macdHistPrev = macdResult.histogram[last - 1];
  const ema20Now = ema20[last];
  const ema50Now = ema50[last];
  const bbUpperNow = bb.upper[last];
  const bbLowerNow = bb.lower[last];
  const bbMiddleNow = bb.middle[last];
  const atrNow = atrValues[last];
  const priceNow = closes[last];

  let longScore = 0;
  let shortScore = 0;
  const reasons: string[] = [];

  // RSI signals
  if (rsiNow < 30) {
    longScore += 25;
    reasons.push(`RSI oversold (${rsiNow.toFixed(1)})`);
  } else if (rsiNow < 45) {
    longScore += 10;
    reasons.push(`RSI bearish zone (${rsiNow.toFixed(1)})`);
  } else if (rsiNow > 70) {
    shortScore += 25;
    reasons.push(`RSI overbought (${rsiNow.toFixed(1)})`);
  } else if (rsiNow > 55) {
    shortScore += 10;
    reasons.push(`RSI bullish zone (${rsiNow.toFixed(1)})`);
  }

  // MACD crossover
  if (macdHistNow > 0 && macdHistPrev <= 0) {
    longScore += 30;
    reasons.push("MACD bullish crossover");
  } else if (macdHistNow < 0 && macdHistPrev >= 0) {
    shortScore += 30;
    reasons.push("MACD bearish crossover");
  } else if (macdNow > macdSignalNow) {
    longScore += 10;
    reasons.push("MACD above signal");
  } else if (macdNow < macdSignalNow) {
    shortScore += 10;
    reasons.push("MACD below signal");
  }

  // EMA trend
  if (ema20Now > ema50Now) {
    longScore += 15;
    reasons.push("EMA20 > EMA50 (uptrend)");
  } else {
    shortScore += 15;
    reasons.push("EMA20 < EMA50 (downtrend)");
  }

  // Price vs EMA
  if (priceNow > ema20Now) {
    longScore += 10;
  } else {
    shortScore += 10;
  }

  // Bollinger Bands
  if (priceNow <= bbLowerNow) {
    longScore += 20;
    reasons.push("Price at/below BB lower band");
  } else if (priceNow >= bbUpperNow) {
    shortScore += 20;
    reasons.push("Price at/above BB upper band");
  } else if (priceNow > bbMiddleNow) {
    longScore += 5;
  } else {
    shortScore += 5;
  }

  const totalScore = longScore + shortScore;
  const threshold = 45;

  let signal: SignalType = "HOLD";
  let confidence = 0;

  if (longScore > shortScore && longScore >= threshold) {
    signal = "LONG";
    confidence = Math.min(100, (longScore / totalScore) * 100);
  } else if (shortScore > longScore && shortScore >= threshold) {
    signal = "SHORT";
    confidence = Math.min(100, (shortScore / totalScore) * 100);
  } else {
    confidence = 50 - Math.abs(longScore - shortScore);
  }

  return {
    signal,
    confidence: Math.round(confidence),
    rsiValue: rsiNow,
    macdValue: macdNow,
    macdSignalValue: macdSignalNow,
    ema20Value: ema20Now,
    ema50Value: ema50Now,
    bbUpper: bbUpperNow,
    bbLower: bbLowerNow,
    bbMiddle: bbMiddleNow,
    atrValue: atrNow,
    reasons,
  };
}

// Dynamic SL/TP based on ATR
export function calcSlTp(
  direction: "LONG" | "SHORT",
  entryPrice: number,
  atrValue: number,
  slMultiplier = 1.5,
  tpMultiplier = 3.0
): { sl: number; tp: number } {
  const slDist = atrValue * slMultiplier;
  const tpDist = atrValue * tpMultiplier;

  if (direction === "LONG") {
    return {
      sl: entryPrice - slDist,
      tp: entryPrice + tpDist,
    };
  } else {
    return {
      sl: entryPrice + slDist,
      tp: entryPrice - tpDist,
    };
  }
}
