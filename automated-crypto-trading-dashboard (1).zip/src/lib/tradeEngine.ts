// Trade Engine - Virtual trading logic with risk management

import { db } from "@/db";
import { trades, virtualWallets, botConfigs } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { analyzeMarket, calcSlTp, type Candle } from "./indicators";

const MAKER_FEE = 0.0002; // 0.02%
const TAKER_FEE = 0.0004; // 0.04%

export interface TradeOpenResult {
  success: boolean;
  tradeId?: number;
  message: string;
  direction?: string;
  entryPrice?: number;
  sl?: number;
  tp?: number;
  quantity?: number;
  margin?: number;
}

export async function evaluateAndTrade(
  candles: Candle[],
  symbol: string,
  walletId = 1
): Promise<TradeOpenResult> {
  // Get bot config
  const [config] = await db
    .select()
    .from(botConfigs)
    .where(eq(botConfigs.walletId, walletId));

  if (!config || !config.isRunning) {
    return { success: false, message: "Bot is not running" };
  }

  // Get wallet
  const [wallet] = await db
    .select()
    .from(virtualWallets)
    .where(eq(virtualWallets.id, walletId));

  if (!wallet) {
    return { success: false, message: "Wallet not found" };
  }

  const balance = parseFloat(wallet.currentBalance);

  // Check open trades count
  const openTrades = await db
    .select()
    .from(trades)
    .where(
      and(
        eq(trades.walletId, walletId),
        eq(trades.status, "OPEN"),
        eq(trades.symbol, symbol)
      )
    );

  if (openTrades.length >= config.maxOpenTrades) {
    return {
      success: false,
      message: `Max open trades (${config.maxOpenTrades}) reached`,
    };
  }

  // Analyze market
  const analysis = analyzeMarket(candles);

  if (analysis.signal === "HOLD" || analysis.confidence < 55) {
    return {
      success: false,
      message: `No signal (${analysis.signal}, confidence: ${analysis.confidence}%)`,
    };
  }

  // Check if same direction trade already open
  const sameDir = openTrades.find((t) => t.direction === analysis.signal);
  if (sameDir) {
    return {
      success: false,
      message: `Already have ${analysis.signal} trade open`,
    };
  }

  const leverage = config.leverage;
  const riskPercent = parseFloat(config.riskPerTrade) / 100;
  const margin = balance * riskPercent;
  const entryPrice = candles[candles.length - 1].close;

  // Dynamic SL/TP based on ATR
  const { sl, tp } = calcSlTp(
    analysis.signal as "LONG" | "SHORT",
    entryPrice,
    analysis.atrValue,
    parseFloat(config.slPercent),
    parseFloat(config.tpPercent)
  );

  const positionSize = (margin * leverage) / entryPrice;
  const fee = margin * leverage * TAKER_FEE;

  const [newTrade] = await db
    .insert(trades)
    .values({
      walletId,
      symbol,
      direction: analysis.signal as "LONG" | "SHORT",
      status: "OPEN",
      entryPrice: entryPrice.toString(),
      stopLoss: sl.toString(),
      takeProfit: tp.toString(),
      leverage,
      quantity: positionSize.toString(),
      margin: margin.toString(),
      fees: fee.toString(),
      timeframe: config.timeframe,
      strategyName: config.strategy,
      strategySignals: {
        rsi: analysis.rsiValue,
        macd: analysis.macdValue,
        macdSignal: analysis.macdSignalValue,
        ema20: analysis.ema20Value,
        ema50: analysis.ema50Value,
        confidence: analysis.confidence,
        reasons: analysis.reasons,
      },
    })
    .returning();

  // Deduct margin from wallet
  await db
    .update(virtualWallets)
    .set({
      currentBalance: (balance - margin - fee).toString(),
      updatedAt: new Date(),
    })
    .where(eq(virtualWallets.id, walletId));

  return {
    success: true,
    tradeId: newTrade.id,
    message: `${analysis.signal} trade opened`,
    direction: analysis.signal,
    entryPrice,
    sl,
    tp,
    quantity: positionSize,
    margin,
  };
}

export async function checkAndCloseTrades(
  currentPrice: number,
  symbol: string,
  walletId = 1
): Promise<{ closed: number; details: string[] }> {
  const openTrades = await db
    .select()
    .from(trades)
    .where(
      and(
        eq(trades.walletId, walletId),
        eq(trades.status, "OPEN"),
        eq(trades.symbol, symbol)
      )
    );

  const [wallet] = await db
    .select()
    .from(virtualWallets)
    .where(eq(virtualWallets.id, walletId));

  if (!wallet) return { closed: 0, details: [] };

  let balance = parseFloat(wallet.currentBalance);
  let totalPnl = parseFloat(wallet.totalPnl);
  let winCount = wallet.winCount;
  let lossCount = wallet.lossCount;
  let totalTrades = wallet.totalTrades;
  const details: string[] = [];
  let closedCount = 0;

  for (const trade of openTrades) {
    const entry = parseFloat(trade.entryPrice);
    const sl = trade.stopLoss ? parseFloat(trade.stopLoss) : null;
    const tp = trade.takeProfit ? parseFloat(trade.takeProfit) : null;
    const margin = parseFloat(trade.margin);
    const qty = parseFloat(trade.quantity);
    const leverage = trade.leverage;
    const direction = trade.direction;

    let shouldClose = false;
    let closeReason = "";
    let closePrice = currentPrice;

    // Check SL/TP hit
    if (direction === "LONG") {
      if (sl && currentPrice <= sl) {
        shouldClose = true;
        closeReason = "Stop Loss";
        closePrice = sl;
      } else if (tp && currentPrice >= tp) {
        shouldClose = true;
        closeReason = "Take Profit";
        closePrice = tp;
      }
    } else {
      // SHORT
      if (sl && currentPrice >= sl) {
        shouldClose = true;
        closeReason = "Stop Loss";
        closePrice = sl;
      } else if (tp && currentPrice <= tp) {
        shouldClose = true;
        closeReason = "Take Profit";
        closePrice = tp;
      }
    }

    if (!shouldClose) continue;

    // Calculate PnL
    let rawPnl = 0;
    if (direction === "LONG") {
      rawPnl = (closePrice - entry) * qty;
    } else {
      rawPnl = (entry - closePrice) * qty;
    }

    const exitFee = margin * leverage * TAKER_FEE;
    const entryFee = parseFloat(trade.fees);
    const netPnl = rawPnl - exitFee;
    const pnlPercent = (netPnl / margin) * 100;

    const tradeResult =
      netPnl > 0 ? "WIN" : netPnl < 0 ? "LOSS" : "BREAKEVEN";

    // Update trade
    await db
      .update(trades)
      .set({
        status: "CLOSED",
        result: tradeResult,
        exitPrice: closePrice.toString(),
        pnl: netPnl.toString(),
        pnlPercent: pnlPercent.toString(),
        fees: (entryFee + exitFee).toString(),
        closedAt: new Date(),
        closedReason: closeReason,
      })
      .where(eq(trades.id, trade.id));

    // Update balance
    balance += margin + netPnl; // Return margin + profit
    totalPnl += netPnl;

    if (tradeResult === "WIN") winCount++;
    else if (tradeResult === "LOSS") lossCount++;
    totalTrades++;

    closedCount++;
    details.push(
      `${direction} ${trade.symbol} closed at ${closePrice.toFixed(2)} - ${closeReason} - PnL: ${netPnl >= 0 ? "+" : ""}${netPnl.toFixed(2)} USDT (${pnlPercent.toFixed(2)}%)`
    );
  }

  if (closedCount > 0) {
    const initialBalance = parseFloat(wallet.initialBalance);
    const totalPnlPercent = ((balance - initialBalance) / initialBalance) * 100;

    await db
      .update(virtualWallets)
      .set({
        currentBalance: balance.toString(),
        totalPnl: totalPnl.toString(),
        totalPnlPercent: totalPnlPercent.toString(),
        winCount,
        lossCount,
        totalTrades,
        updatedAt: new Date(),
      })
      .where(eq(virtualWallets.id, walletId));
  }

  return { closed: closedCount, details };
}

export async function getOrCreateWallet(walletId = 1) {
  const existing = await db
    .select()
    .from(virtualWallets)
    .where(eq(virtualWallets.id, walletId));

  if (existing.length > 0) return existing[0];

  const [created] = await db
    .insert(virtualWallets)
    .values({
      name: "Main Virtual Wallet",
      initialBalance: "10000",
      currentBalance: "10000",
    })
    .returning();

  return created;
}

export async function getOrCreateBotConfig(walletId = 1) {
  const existing = await db
    .select()
    .from(botConfigs)
    .where(eq(botConfigs.walletId, walletId));

  if (existing.length > 0) return existing[0];

  const [created] = await db
    .insert(botConfigs)
    .values({ walletId })
    .returning();

  return created;
}
