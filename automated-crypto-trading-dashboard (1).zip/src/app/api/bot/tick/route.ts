import { NextResponse } from "next/server";
import { evaluateAndTrade, checkAndCloseTrades } from "@/lib/tradeEngine";
import { fetchKlines, fetch24hTicker } from "@/lib/binance";
import { db } from "@/db";
import { botConfigs } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST() {
  try {
    const [config] = await db
      .select()
      .from(botConfigs)
      .where(eq(botConfigs.walletId, 1));

    if (!config || !config.isRunning) {
      return NextResponse.json({ message: "Bot is stopped", actions: [] });
    }

    const symbol = config.symbol;
    const timeframe = config.timeframe;

    // Fetch real market data
    const klines = await fetchKlines(symbol, timeframe, 200);
    const ticker = await fetch24hTicker(symbol);
    const currentPrice = ticker.price;

    const candles = klines.map((k) => ({
      openTime: k.openTime,
      open: k.open,
      high: k.high,
      low: k.low,
      close: k.close,
      volume: k.volume,
    }));

    // Check existing trades first (SL/TP)
    const closeResult = await checkAndCloseTrades(currentPrice, symbol, 1);

    // Evaluate new trade signal
    const tradeResult = await evaluateAndTrade(candles, symbol, 1);

    return NextResponse.json({
      currentPrice,
      symbol,
      timeframe,
      closeResult,
      tradeResult,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    console.error("Tick error:", err);
    return NextResponse.json({ error: "Tick failed", details: String(err) }, { status: 500 });
  }
}
