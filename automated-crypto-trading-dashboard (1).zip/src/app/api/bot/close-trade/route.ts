import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { trades, virtualWallets } from "@/db/schema";
import { eq } from "drizzle-orm";
import { fetch24hTicker } from "@/lib/binance";

export async function POST(req: NextRequest) {
  try {
    const { tradeId } = await req.json();

    const [trade] = await db.select().from(trades).where(eq(trades.id, tradeId));
    if (!trade || trade.status !== "OPEN") {
      return NextResponse.json({ error: "Trade not found or not open" }, { status: 404 });
    }

    const ticker = await fetch24hTicker(trade.symbol);
    const currentPrice = ticker.price;
    const entry = parseFloat(trade.entryPrice);
    const margin = parseFloat(trade.margin);
    const qty = parseFloat(trade.quantity);
    const fee = margin * trade.leverage * 0.0004;

    let rawPnl = 0;
    if (trade.direction === "LONG") {
      rawPnl = (currentPrice - entry) * qty;
    } else {
      rawPnl = (entry - currentPrice) * qty;
    }

    const netPnl = rawPnl - fee;
    const pnlPercent = (netPnl / margin) * 100;
    const tradeResult = netPnl > 0 ? "WIN" : netPnl < 0 ? "LOSS" : "BREAKEVEN";

    await db.update(trades).set({
      status: "CLOSED",
      result: tradeResult,
      exitPrice: currentPrice.toString(),
      pnl: netPnl.toString(),
      pnlPercent: pnlPercent.toString(),
      closedAt: new Date(),
      closedReason: "Manual close",
    }).where(eq(trades.id, tradeId));

    // Update wallet
    const [wallet] = await db.select().from(virtualWallets).where(eq(virtualWallets.id, trade.walletId));
    if (wallet) {
      const newBalance = parseFloat(wallet.currentBalance) + margin + netPnl;
      const newPnl = parseFloat(wallet.totalPnl) + netPnl;
      const initBal = parseFloat(wallet.initialBalance);
      await db.update(virtualWallets).set({
        currentBalance: newBalance.toString(),
        totalPnl: newPnl.toString(),
        totalPnlPercent: (((newBalance - initBal) / initBal) * 100).toString(),
        winCount: tradeResult === "WIN" ? wallet.winCount + 1 : wallet.winCount,
        lossCount: tradeResult === "LOSS" ? wallet.lossCount + 1 : wallet.lossCount,
        totalTrades: wallet.totalTrades + 1,
        updatedAt: new Date(),
      }).where(eq(virtualWallets.id, wallet.id));
    }

    return NextResponse.json({
      success: true,
      pnl: netPnl,
      pnlPercent,
      closePrice: currentPrice,
    });
  } catch (err) {
    console.error("Close trade error:", err);
    return NextResponse.json({ error: "Failed to close trade" }, { status: 500 });
  }
}
