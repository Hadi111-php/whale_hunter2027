import { NextResponse } from "next/server";
import { getOrCreateWallet, getOrCreateBotConfig } from "@/lib/tradeEngine";
import { db } from "@/db";
import { trades } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";

export async function GET() {
  try {
    const wallet = await getOrCreateWallet(1);
    const config = await getOrCreateBotConfig(1);

    const openTrades = await db
      .select()
      .from(trades)
      .where(and(eq(trades.walletId, 1), eq(trades.status, "OPEN")))
      .orderBy(desc(trades.openedAt));

    const recentClosed = await db
      .select()
      .from(trades)
      .where(and(eq(trades.walletId, 1), eq(trades.status, "CLOSED")))
      .orderBy(desc(trades.closedAt))
      .limit(20);

    return NextResponse.json({
      wallet,
      config,
      openTrades,
      recentClosed,
    });
  } catch (err) {
    console.error("Status error:", err);
    return NextResponse.json({ error: "Failed to get status" }, { status: 500 });
  }
}
