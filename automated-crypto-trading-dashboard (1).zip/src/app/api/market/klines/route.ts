import { NextRequest, NextResponse } from "next/server";
import { fetchKlines } from "@/lib/binance";
import { analyzeMarket } from "@/lib/indicators";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const symbol = searchParams.get("symbol") ?? "BTCUSDT";
  const interval = searchParams.get("interval") ?? "15m";
  const limit = parseInt(searchParams.get("limit") ?? "200");

  try {
    const klines = await fetchKlines(symbol, interval, limit);

    const candles = klines.map((k) => ({
      openTime: k.openTime,
      open: k.open,
      high: k.high,
      low: k.low,
      close: k.close,
      volume: k.volume,
    }));

    const analysis = analyzeMarket(candles);

    return NextResponse.json({
      klines,
      analysis,
      symbol,
      interval,
    });
  } catch (err) {
    console.error("Klines error:", err);
    return NextResponse.json({ error: "Failed to fetch klines" }, { status: 500 });
  }
}
