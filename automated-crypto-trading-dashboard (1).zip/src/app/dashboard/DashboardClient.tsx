"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import dynamic from "next/dynamic";
import { SUPPORTED_SYMBOLS, TIMEFRAMES } from "@/lib/binance";

const CandleChart = dynamic(() => import("@/components/CandleChart"), {
  ssr: false,
  loading: () => (
    <div
      className="w-full flex items-center justify-center"
      style={{ height: 420, background: "#131c2e" }}
    >
      <span style={{ color: "#8892a4" }}>Loading chart...</span>
    </div>
  ),
});

// ---- Types ----
interface Wallet {
  id: number;
  currentBalance: string;
  initialBalance: string;
  totalPnl: string;
  totalPnlPercent: string;
  winCount: number;
  lossCount: number;
  totalTrades: number;
}

interface BotConfig {
  id: number;
  isRunning: boolean;
  symbol: string;
  timeframe: string;
  leverage: number;
  riskPerTrade: string;
  maxOpenTrades: number;
  strategy: string;
  autoSl: boolean;
  autoTp: boolean;
  slPercent: string;
  tpPercent: string;
}

interface Trade {
  id: number;
  symbol: string;
  direction: "LONG" | "SHORT";
  status: string;
  result: string | null;
  entryPrice: string;
  exitPrice: string | null;
  stopLoss: string | null;
  takeProfit: string | null;
  leverage: number;
  margin: string;
  pnl: string | null;
  pnlPercent: string | null;
  openedAt: Date | string;
  closedAt: Date | string | null;
  closedReason: string | null;
  strategySignals: unknown;
}

interface Kline {
  openTime: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface Analysis {
  signal: "LONG" | "SHORT" | "HOLD";
  confidence: number;
  rsiValue: number;
  macdValue: number;
  ema20Value: number;
  ema50Value: number;
  bbUpper: number;
  bbLower: number;
  atrValue: number;
  reasons: string[];
}

interface Ticker {
  symbol: string;
  price: number;
  changePercent: number;
  volume24h: number;
  high24h: number;
  low24h: number;
}

// ---- Helper Components ----
function StatCard({
  label,
  value,
  sub,
  color,
  icon,
}: {
  label: string;
  value: string;
  sub?: string;
  color?: string;
  icon?: string;
}) {
  return (
    <div
      className="rounded-xl p-4 card-hover"
      style={{ background: "var(--bg-card)", border: "1px solid var(--border)" }}
    >
      <div className="flex items-center justify-between mb-2">
        <span style={{ color: "var(--text-secondary)", fontSize: "0.72rem", textTransform: "uppercase", letterSpacing: "0.08em" }}>
          {label}
        </span>
        {icon && <span style={{ fontSize: "1.1rem" }}>{icon}</span>}
      </div>
      <div
        className="font-bold"
        style={{ fontSize: "1.35rem", color: color ?? "var(--text-primary)" }}
      >
        {value}
      </div>
      {sub && (
        <div style={{ color: "var(--text-muted)", fontSize: "0.75rem", marginTop: 4 }}>
          {sub}
        </div>
      )}
    </div>
  );
}

function Badge({
  children,
  type,
}: {
  children: React.ReactNode;
  type: "long" | "short" | "hold" | "win" | "loss";
}) {
  const cls =
    type === "long" || type === "win"
      ? "signal-long"
      : type === "short" || type === "loss"
      ? "signal-short"
      : "signal-hold";
  return (
    <span
      className={`${cls} px-2 py-0.5 rounded text-xs font-semibold uppercase`}
    >
      {children}
    </span>
  );
}

function fmt(n: number, decimals = 2) {
  return n.toLocaleString(undefined, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

function fmtPrice(n: number) {
  if (n > 1000) return fmt(n, 2);
  if (n > 1) return fmt(n, 4);
  return fmt(n, 6);
}

// ---- Main Dashboard ----
export default function DashboardClient({
  initialWallet,
  initialConfig,
  initialOpenTrades,
  initialClosedTrades,
}: {
  initialWallet: Wallet;
  initialConfig: BotConfig;
  initialOpenTrades: Trade[];
  initialClosedTrades: Trade[];
}) {
  const [wallet, setWallet] = useState<Wallet>(initialWallet);
  const [config, setConfig] = useState<BotConfig>(initialConfig);
  const [openTrades, setOpenTrades] = useState<Trade[]>(initialOpenTrades);
  const [closedTrades, setClosedTrades] = useState<Trade[]>(initialClosedTrades);
  const [klines, setKlines] = useState<Kline[]>([]);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [tickers, setTickers] = useState<Ticker[]>([]);
  const [currentPrice, setCurrentPrice] = useState<number>(0);
  const [selectedSymbol, setSelectedSymbol] = useState(initialConfig.symbol);
  const [selectedTf, setSelectedTf] = useState(initialConfig.timeframe);
  const [isLoading, setIsLoading] = useState(false);
  const [botLog, setBotLog] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<"open" | "closed" | "config">("open");
  const [tickCount, setTickCount] = useState(0);
  const tickInterval = useRef<ReturnType<typeof setInterval> | null>(null);

  const addLog = useCallback((msg: string) => {
    const time = new Date().toLocaleTimeString("fa-IR");
    setBotLog((prev) => [`[${time}] ${msg}`, ...prev].slice(0, 50));
  }, []);

  // Fetch chart data
  const fetchChart = useCallback(async (sym: string, tf: string) => {
    try {
      const res = await fetch(`/api/market/klines?symbol=${sym}&interval=${tf}&limit=200`);
      const data = await res.json();
      if (data.klines) {
        setKlines(data.klines);
        setAnalysis(data.analysis);
        if (data.klines.length > 0) {
          setCurrentPrice(data.klines[data.klines.length - 1].close);
        }
      }
    } catch (e) {
      console.error("Chart fetch error:", e);
    }
  }, []);

  // Fetch tickers for top bar
  const fetchTickers = useCallback(async () => {
    try {
      const res = await fetch("/api/market/tickers");
      const data = await res.json();
      if (data.tickers) setTickers(data.tickers);
    } catch (e) {
      console.error("Tickers error:", e);
    }
  }, []);

  // Fetch bot status
  const fetchStatus = useCallback(async () => {
    try {
      const res = await fetch("/api/bot/status");
      const data = await res.json();
      if (data.wallet) setWallet(data.wallet);
      if (data.openTrades) setOpenTrades(data.openTrades);
      if (data.recentClosed) setClosedTrades(data.recentClosed);
    } catch (e) {
      console.error("Status fetch error:", e);
    }
  }, []);

  // Run a bot tick
  const runTick = useCallback(async () => {
    try {
      const res = await fetch("/api/bot/tick", { method: "POST" });
      const data = await res.json();
      if (data.error) {
        addLog(`❌ Error: ${data.error}`);
        return;
      }
      setCurrentPrice(data.currentPrice ?? currentPrice);

      if (data.closeResult?.closed > 0) {
        data.closeResult.details.forEach((d: string) => addLog(`🔔 ${d}`));
      }
      if (data.tradeResult?.success) {
        addLog(
          `✅ ${data.tradeResult.direction} opened @ ${fmtPrice(data.tradeResult.entryPrice)} | SL: ${fmtPrice(data.tradeResult.sl)} | TP: ${fmtPrice(data.tradeResult.tp)}`
        );
      } else if (data.tradeResult) {
        addLog(`ℹ️ ${data.tradeResult.message}`);
      }

      setTickCount((c) => c + 1);
      await fetchStatus();
    } catch (e) {
      addLog(`❌ Tick error: ${e}`);
    }
  }, [addLog, fetchStatus, currentPrice]);

  // Start/stop bot
  const toggleBot = async () => {
    const newState = !config.isRunning;
    try {
      const res = await fetch("/api/bot/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...config, isRunning: newState }),
      });
      const data = await res.json();
      if (data.config) setConfig(data.config);
      addLog(newState ? "🚀 Bot started" : "⏹️ Bot stopped");
    } catch (e) {
      addLog(`❌ Toggle error: ${e}`);
    }
  };

  // Save config
  const saveConfig = async (updates: Partial<BotConfig>) => {
    try {
      const res = await fetch("/api/bot/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...config, ...updates }),
      });
      const data = await res.json();
      if (data.config) {
        setConfig(data.config);
        addLog("⚙️ Config saved");
      }
    } catch (e) {
      addLog(`❌ Config error: ${e}`);
    }
  };

  // Close trade manually
  const closeTrade = async (tradeId: number) => {
    try {
      const res = await fetch("/api/bot/close-trade", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tradeId }),
      });
      const data = await res.json();
      if (data.success) {
        addLog(`🔒 Trade #${tradeId} closed manually - PnL: ${data.pnl >= 0 ? "+" : ""}${fmt(data.pnl)} USDT`);
        await fetchStatus();
      }
    } catch (e) {
      addLog(`❌ Close error: ${e}`);
    }
  };

  // Reset wallet
  const resetWallet = async () => {
    if (!confirm("Reset wallet to 10,000 USDT? All trades will be cancelled.")) return;
    try {
      await fetch("/api/bot/reset", { method: "POST" });
      await fetchStatus();
      setBotLog([]);
      addLog("🔄 Wallet reset to 10,000 USDT");
    } catch (e) {
      addLog(`❌ Reset error: ${e}`);
    }
  };

  // Auto-tick when bot is running
  useEffect(() => {
    if (config.isRunning) {
      tickInterval.current = setInterval(() => {
        runTick();
      }, 30000); // Every 30 seconds
      runTick(); // Immediate first tick
    } else {
      if (tickInterval.current) clearInterval(tickInterval.current);
    }
    return () => {
      if (tickInterval.current) clearInterval(tickInterval.current);
    };
  }, [config.isRunning, runTick]);

  // Change symbol/timeframe
  useEffect(() => {
    fetchChart(selectedSymbol, selectedTf);
  }, [selectedSymbol, selectedTf, fetchChart]);

  // Refresh price periodically
  useEffect(() => {
    const interval = setInterval(() => {
      fetchChart(selectedSymbol, selectedTf);
    }, 15000);
    return () => clearInterval(interval);
  }, [selectedSymbol, selectedTf, fetchChart]);

  // Initial data fetch
  useEffect(() => {
    fetchTickers();
    fetchChart(selectedSymbol, selectedTf);
    const t = setInterval(fetchTickers, 30000);
    return () => clearInterval(t);
  }, [fetchTickers, fetchChart, selectedSymbol, selectedTf]);

  const balance = parseFloat(wallet.currentBalance);
  const totalPnl = parseFloat(wallet.totalPnl);
  const totalPnlPercent = parseFloat(wallet.totalPnlPercent);
  const winRate =
    wallet.totalTrades > 0
      ? ((wallet.winCount / wallet.totalTrades) * 100).toFixed(1)
      : "0.0";

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg-primary)" }}>
      {/* ── Top Ticker Bar ── */}
      <div
        className="overflow-hidden"
        style={{
          background: "var(--bg-secondary)",
          borderBottom: "1px solid var(--border)",
          height: 36,
        }}
      >
        <div className="flex ticker-scroll whitespace-nowrap" style={{ width: "max-content" }}>
          {[...tickers, ...tickers].map((t, i) => (
            <span key={i} className="inline-flex items-center gap-2 px-4" style={{ fontSize: "0.78rem" }}>
              <span style={{ color: "var(--text-secondary)" }}>{t.symbol.replace("USDT", "")}</span>
              <span style={{ color: "var(--text-primary)", fontFamily: "monospace" }}>
                ${fmtPrice(t.price)}
              </span>
              <span style={{ color: t.changePercent >= 0 ? "var(--accent-green)" : "var(--accent-red)" }}>
                {t.changePercent >= 0 ? "▲" : "▼"} {Math.abs(t.changePercent).toFixed(2)}%
              </span>
            </span>
          ))}
        </div>
      </div>

      {/* ── Header ── */}
      <header
        style={{
          background: "var(--bg-secondary)",
          borderBottom: "1px solid var(--border)",
          padding: "10px 20px",
        }}
      >
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div
              className="flex items-center justify-center rounded-lg"
              style={{
                width: 36, height: 36,
                background: "linear-gradient(135deg, #3b82f6, #8b5cf6)",
              }}
            >
              <span style={{ fontSize: "1.1rem" }}>🤖</span>
            </div>
            <div>
              <h1 style={{ color: "var(--text-primary)", fontWeight: 700, fontSize: "1.05rem", lineHeight: 1 }}>
                CryptoBot Pro
              </h1>
              <p style={{ color: "var(--text-muted)", fontSize: "0.7rem" }}>
                Virtual Auto-Trading · Real Binance Data
              </p>
            </div>

            {/* Live indicator */}
            <div className="flex items-center gap-1.5">
              <span
                className="pulse-dot"
                style={{
                  display: "inline-block", width: 7, height: 7,
                  borderRadius: "50%",
                  background: config.isRunning ? "var(--accent-green)" : "var(--text-muted)",
                }}
              />
              <span
                style={{
                  fontSize: "0.7rem",
                  color: config.isRunning ? "var(--accent-green)" : "var(--text-muted)",
                }}
              >
                {config.isRunning ? `LIVE · ${tickCount} ticks` : "STOPPED"}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={resetWallet}
              style={{
                background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)",
                color: "var(--accent-red)", padding: "6px 14px",
                borderRadius: 8, fontSize: "0.8rem", cursor: "pointer",
              }}
            >
              🔄 Reset
            </button>

            <button
              onClick={toggleBot}
              style={{
                background: config.isRunning
                  ? "rgba(239,68,68,0.15)"
                  : "linear-gradient(135deg, #10b981, #059669)",
                border: config.isRunning ? "1px solid rgba(239,68,68,0.4)" : "none",
                color: config.isRunning ? "var(--accent-red)" : "white",
                padding: "8px 20px", borderRadius: 8,
                fontWeight: 700, fontSize: "0.85rem", cursor: "pointer",
                transition: "all 0.2s",
              }}
            >
              {config.isRunning ? "⏹ Stop Bot" : "▶ Start Bot"}
            </button>
          </div>
        </div>
      </header>

      <div className="p-4" style={{ maxWidth: 1600, margin: "0 auto" }}>
        {/* ── Stat Cards ── */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 mb-4">
          <StatCard
            label="Balance"
            value={`$${fmt(balance)}`}
            sub="Virtual USDT"
            icon="💰"
          />
          <StatCard
            label="Total PnL"
            value={`${totalPnl >= 0 ? "+" : ""}$${fmt(totalPnl)}`}
            sub={`${totalPnlPercent >= 0 ? "+" : ""}${fmt(totalPnlPercent)}%`}
            color={totalPnl >= 0 ? "var(--accent-green)" : "var(--accent-red)"}
            icon="📈"
          />
          <StatCard
            label="Win Rate"
            value={`${winRate}%`}
            sub={`${wallet.winCount}W / ${wallet.lossCount}L`}
            color={parseFloat(winRate) >= 50 ? "var(--accent-green)" : "var(--accent-red)"}
            icon="🎯"
          />
          <StatCard
            label="Total Trades"
            value={wallet.totalTrades.toString()}
            sub={`${openTrades.length} open`}
            icon="📊"
          />
          <StatCard
            label="Open Trades"
            value={openTrades.length.toString()}
            sub={`Max: ${config.maxOpenTrades}`}
            icon="🔓"
          />
          <StatCard
            label="Leverage"
            value={`${config.leverage}x`}
            sub={`Risk: ${config.riskPerTrade}%`}
            icon="⚡"
          />
        </div>

        <div className="dashboard-grid">
          {/* ── Left Sidebar ── */}
          <div className="flex flex-col gap-3">
            {/* Symbol & Timeframe selector */}
            <div
              className="rounded-xl p-4"
              style={{ background: "var(--bg-card)", border: "1px solid var(--border)" }}
            >
              <h3
                style={{
                  color: "var(--text-secondary)",
                  fontSize: "0.72rem",
                  textTransform: "uppercase",
                  letterSpacing: "0.08em",
                  marginBottom: 10,
                }}
              >
                Market Selection
              </h3>
              <select
                value={selectedSymbol}
                onChange={(e) => {
                  setSelectedSymbol(e.target.value);
                  saveConfig({ symbol: e.target.value });
                }}
                style={{
                  width: "100%", padding: "8px 10px",
                  background: "var(--bg-secondary)",
                  border: "1px solid var(--border)",
                  borderRadius: 8, color: "var(--text-primary)",
                  fontSize: "0.85rem", marginBottom: 8,
                }}
              >
                {SUPPORTED_SYMBOLS.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
              <div className="flex flex-wrap gap-1">
                {TIMEFRAMES.map((tf) => (
                  <button
                    key={tf.value}
                    onClick={() => {
                      setSelectedTf(tf.value);
                      saveConfig({ timeframe: tf.value });
                    }}
                    style={{
                      padding: "4px 10px",
                      borderRadius: 6, fontSize: "0.78rem",
                      background: selectedTf === tf.value
                        ? "var(--accent-blue)"
                        : "var(--bg-secondary)",
                      color: selectedTf === tf.value ? "white" : "var(--text-secondary)",
                      border: "1px solid var(--border)",
                      cursor: "pointer",
                    }}
                  >
                    {tf.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Analysis Signal */}
            {analysis && (
              <div
                className="rounded-xl p-4"
                style={{ background: "var(--bg-card)", border: "1px solid var(--border)" }}
              >
                <h3
                  style={{
                    color: "var(--text-secondary)",
                    fontSize: "0.72rem",
                    textTransform: "uppercase",
                    letterSpacing: "0.08em",
                    marginBottom: 12,
                  }}
                >
                  Signal Analysis
                </h3>

                <div className="flex items-center justify-between mb-3">
                  <Badge
                    type={
                      analysis.signal === "LONG"
                        ? "long"
                        : analysis.signal === "SHORT"
                        ? "short"
                        : "hold"
                    }
                  >
                    {analysis.signal === "LONG"
                      ? "▲ LONG"
                      : analysis.signal === "SHORT"
                      ? "▼ SHORT"
                      : "— HOLD"}
                  </Badge>
                  <span
                    style={{
                      color:
                        analysis.confidence > 65
                          ? "var(--accent-green)"
                          : analysis.confidence > 50
                          ? "var(--accent-yellow)"
                          : "var(--text-muted)",
                      fontSize: "0.9rem",
                      fontWeight: 700,
                    }}
                  >
                    {analysis.confidence}%
                  </span>
                </div>

                <div className="progress-bar mb-4">
                  <div
                    className="progress-fill"
                    style={{
                      width: `${analysis.confidence}%`,
                      background:
                        analysis.signal === "LONG"
                          ? "var(--accent-green)"
                          : analysis.signal === "SHORT"
                          ? "var(--accent-red)"
                          : "var(--accent-yellow)",
                    }}
                  />
                </div>

                {/* Indicators */}
                <div className="flex flex-col gap-2">
                  {[
                    {
                      label: "RSI(14)",
                      value: fmt(analysis.rsiValue, 1),
                      color:
                        analysis.rsiValue < 30
                          ? "var(--accent-green)"
                          : analysis.rsiValue > 70
                          ? "var(--accent-red)"
                          : "var(--text-primary)",
                    },
                    {
                      label: "MACD",
                      value: fmt(analysis.macdValue, 4),
                      color:
                        analysis.macdValue > 0
                          ? "var(--accent-green)"
                          : "var(--accent-red)",
                    },
                    {
                      label: "EMA20",
                      value: fmtPrice(analysis.ema20Value),
                      color: "var(--accent-cyan)",
                    },
                    {
                      label: "EMA50",
                      value: fmtPrice(analysis.ema50Value),
                      color: "var(--accent-purple)",
                    },
                    {
                      label: "BB Upper",
                      value: fmtPrice(analysis.bbUpper),
                      color: "var(--text-secondary)",
                    },
                    {
                      label: "BB Lower",
                      value: fmtPrice(analysis.bbLower),
                      color: "var(--text-secondary)",
                    },
                    {
                      label: "ATR(14)",
                      value: fmtPrice(analysis.atrValue),
                      color: "var(--accent-yellow)",
                    },
                  ].map((ind) => (
                    <div key={ind.label} className="flex justify-between items-center">
                      <span style={{ color: "var(--text-muted)", fontSize: "0.75rem" }}>
                        {ind.label}
                      </span>
                      <span
                        style={{
                          color: ind.color,
                          fontSize: "0.82rem",
                          fontFamily: "monospace",
                          fontWeight: 600,
                        }}
                      >
                        {ind.value}
                      </span>
                    </div>
                  ))}
                </div>

                {analysis.reasons.length > 0 && (
                  <div className="mt-3 pt-3" style={{ borderTop: "1px solid var(--border)" }}>
                    <p style={{ color: "var(--text-muted)", fontSize: "0.68rem", marginBottom: 6 }}>
                      REASONS:
                    </p>
                    {analysis.reasons.map((r, i) => (
                      <div key={i} style={{ color: "var(--text-secondary)", fontSize: "0.73rem", marginBottom: 3 }}>
                        • {r}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Config Panel */}
            <div
              className="rounded-xl p-4"
              style={{ background: "var(--bg-card)", border: "1px solid var(--border)" }}
            >
              <h3
                style={{
                  color: "var(--text-secondary)",
                  fontSize: "0.72rem",
                  textTransform: "uppercase",
                  letterSpacing: "0.08em",
                  marginBottom: 12,
                }}
              >
                Bot Configuration
              </h3>
              <div className="flex flex-col gap-3">
                {/* Leverage */}
                <div>
                  <div className="flex justify-between mb-1">
                    <label style={{ color: "var(--text-muted)", fontSize: "0.75rem" }}>
                      Leverage
                    </label>
                    <span style={{ color: "var(--accent-yellow)", fontSize: "0.8rem", fontWeight: 700 }}>
                      {config.leverage}x
                    </span>
                  </div>
                  <input
                    type="range" min={1} max={20} step={1}
                    value={config.leverage}
                    onChange={(e) => setConfig({ ...config, leverage: parseInt(e.target.value) })}
                    onMouseUp={() => saveConfig({ leverage: config.leverage })}
                    style={{ width: "100%", accentColor: "var(--accent-blue)" }}
                  />
                  <div className="flex justify-between" style={{ color: "var(--text-muted)", fontSize: "0.65rem" }}>
                    <span>1x</span><span>20x</span>
                  </div>
                </div>

                {/* Risk per trade */}
                <div>
                  <div className="flex justify-between mb-1">
                    <label style={{ color: "var(--text-muted)", fontSize: "0.75rem" }}>
                      Risk Per Trade
                    </label>
                    <span style={{ color: "var(--accent-cyan)", fontSize: "0.8rem", fontWeight: 700 }}>
                      {config.riskPerTrade}%
                    </span>
                  </div>
                  <input
                    type="range" min={0.5} max={10} step={0.5}
                    value={parseFloat(config.riskPerTrade)}
                    onChange={(e) => setConfig({ ...config, riskPerTrade: e.target.value })}
                    onMouseUp={() => saveConfig({ riskPerTrade: config.riskPerTrade })}
                    style={{ width: "100%", accentColor: "var(--accent-cyan)" }}
                  />
                  <div className="flex justify-between" style={{ color: "var(--text-muted)", fontSize: "0.65rem" }}>
                    <span>0.5%</span><span>10%</span>
                  </div>
                </div>

                {/* SL % */}
                <div className="flex justify-between items-center">
                  <label style={{ color: "var(--text-muted)", fontSize: "0.75rem" }}>Stop Loss (ATR×)</label>
                  <input
                    type="number" min={0.5} max={5} step={0.1}
                    value={parseFloat(config.slPercent)}
                    onChange={(e) => {
                      const v = e.target.value;
                      setConfig({ ...config, slPercent: v });
                      saveConfig({ slPercent: v });
                    }}
                    style={{
                      width: 70, padding: "4px 8px",
                      background: "var(--bg-secondary)",
                      border: "1px solid var(--border)",
                      borderRadius: 6, color: "var(--accent-red)",
                      fontSize: "0.82rem", textAlign: "center",
                    }}
                  />
                </div>

                {/* TP % */}
                <div className="flex justify-between items-center">
                  <label style={{ color: "var(--text-muted)", fontSize: "0.75rem" }}>Take Profit (ATR×)</label>
                  <input
                    type="number" min={1} max={10} step={0.5}
                    value={parseFloat(config.tpPercent)}
                    onChange={(e) => {
                      const v = e.target.value;
                      setConfig({ ...config, tpPercent: v });
                      saveConfig({ tpPercent: v });
                    }}
                    style={{
                      width: 70, padding: "4px 8px",
                      background: "var(--bg-secondary)",
                      border: "1px solid var(--border)",
                      borderRadius: 6, color: "var(--accent-green)",
                      fontSize: "0.82rem", textAlign: "center",
                    }}
                  />
                </div>

                {/* Max open trades */}
                <div className="flex justify-between items-center">
                  <label style={{ color: "var(--text-muted)", fontSize: "0.75rem" }}>Max Open Trades</label>
                  <input
                    type="number" min={1} max={10} step={1}
                    value={config.maxOpenTrades}
                    onChange={(e) => {
                      const v = parseInt(e.target.value);
                      setConfig({ ...config, maxOpenTrades: v });
                      saveConfig({ maxOpenTrades: v });
                    }}
                    style={{
                      width: 70, padding: "4px 8px",
                      background: "var(--bg-secondary)",
                      border: "1px solid var(--border)",
                      borderRadius: 6, color: "var(--text-primary)",
                      fontSize: "0.82rem", textAlign: "center",
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Bot Log */}
            <div
              className="rounded-xl p-3 flex-1"
              style={{
                background: "var(--bg-card)",
                border: "1px solid var(--border)",
                minHeight: 160,
              }}
            >
              <h3
                style={{
                  color: "var(--text-secondary)",
                  fontSize: "0.72rem",
                  textTransform: "uppercase",
                  letterSpacing: "0.08em",
                  marginBottom: 8,
                }}
              >
                Bot Log
              </h3>
              <div
                className="overflow-y-auto"
                style={{ maxHeight: 200, fontSize: "0.72rem", fontFamily: "monospace" }}
              >
                {botLog.length === 0 ? (
                  <span style={{ color: "var(--text-muted)" }}>Waiting for events...</span>
                ) : (
                  botLog.map((l, i) => (
                    <div key={i} style={{ color: "var(--text-secondary)", marginBottom: 3, lineHeight: 1.5 }}>
                      {l}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* ── Right Main Area ── */}
          <div className="flex flex-col gap-3">
            {/* Chart */}
            <div className="chart-container">
              {klines.length > 0 ? (
                <CandleChart
                  klines={klines}
                  symbol={selectedSymbol}
                  interval={selectedTf}
                  currentPrice={currentPrice}
                />
              ) : (
                <div
                  className="flex items-center justify-center"
                  style={{ height: 420, color: "var(--text-muted)" }}
                >
                  <div className="text-center">
                    <div style={{ fontSize: "2rem", marginBottom: 8 }}>📊</div>
                    <div>Loading real Binance data...</div>
                  </div>
                </div>
              )}
            </div>

            {/* Tabs */}
            <div
              className="rounded-xl overflow-hidden"
              style={{ background: "var(--bg-card)", border: "1px solid var(--border)" }}
            >
              {/* Tab header */}
              <div
                className="flex"
                style={{ borderBottom: "1px solid var(--border)" }}
              >
                {(
                  [
                    { key: "open", label: `Open Trades (${openTrades.length})` },
                    { key: "closed", label: `History (${closedTrades.length})` },
                    { key: "config", label: "Performance" },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key)}
                    style={{
                      padding: "10px 16px",
                      fontSize: "0.8rem",
                      fontWeight: activeTab === tab.key ? 700 : 400,
                      color:
                        activeTab === tab.key
                          ? "var(--accent-blue)"
                          : "var(--text-secondary)",
                      background: "transparent",
                      border: "none",
                      borderBottom:
                        activeTab === tab.key
                          ? "2px solid var(--accent-blue)"
                          : "2px solid transparent",
                      cursor: "pointer",
                    }}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Open Trades */}
              {activeTab === "open" && (
                <div className="overflow-x-auto">
                  {openTrades.length === 0 ? (
                    <div className="p-8 text-center" style={{ color: "var(--text-muted)" }}>
                      <div style={{ fontSize: "2rem", marginBottom: 8 }}>🔍</div>
                      No open trades. Start the bot to begin trading.
                    </div>
                  ) : (
                    <table className="data-table w-full">
                      <thead>
                        <tr>
                          <th>Symbol</th>
                          <th>Dir</th>
                          <th>Entry</th>
                          <th>SL</th>
                          <th>TP</th>
                          <th>Margin</th>
                          <th>Lev</th>
                          <th>Unrealized</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {openTrades.map((t) => {
                          const entry = parseFloat(t.entryPrice);
                          const margin = parseFloat(t.margin);
                          const qty = parseFloat(t.margin) * t.leverage / entry;
                          const unrealizedRaw = t.direction === "LONG"
                            ? (currentPrice - entry) * qty
                            : (entry - currentPrice) * qty;
                          const unrealizedPct = (unrealizedRaw / margin) * 100;

                          return (
                            <tr key={t.id}>
                              <td style={{ color: "var(--text-primary)", fontWeight: 600 }}>{t.symbol}</td>
                              <td>
                                <Badge type={t.direction === "LONG" ? "long" : "short"}>
                                  {t.direction}
                                </Badge>
                              </td>
                              <td style={{ fontFamily: "monospace", color: "var(--accent-cyan)" }}>
                                ${fmtPrice(entry)}
                              </td>
                              <td style={{ fontFamily: "monospace", color: "var(--accent-red)" }}>
                                {t.stopLoss ? `$${fmtPrice(parseFloat(t.stopLoss))}` : "-"}
                              </td>
                              <td style={{ fontFamily: "monospace", color: "var(--accent-green)" }}>
                                {t.takeProfit ? `$${fmtPrice(parseFloat(t.takeProfit))}` : "-"}
                              </td>
                              <td style={{ fontFamily: "monospace" }}>
                                ${fmt(margin)}
                              </td>
                              <td style={{ color: "var(--accent-yellow)" }}>{t.leverage}x</td>
                              <td>
                                <span style={{
                                  color: unrealizedRaw >= 0 ? "var(--accent-green)" : "var(--accent-red)",
                                  fontFamily: "monospace", fontWeight: 600,
                                }}>
                                  {unrealizedRaw >= 0 ? "+" : ""}{fmt(unrealizedRaw)} ({unrealizedPct >= 0 ? "+" : ""}{fmt(unrealizedPct)}%)
                                </span>
                              </td>
                              <td>
                                <button
                                  onClick={() => closeTrade(t.id)}
                                  style={{
                                    padding: "4px 10px",
                                    background: "rgba(239,68,68,0.15)",
                                    border: "1px solid rgba(239,68,68,0.3)",
                                    borderRadius: 6, color: "var(--accent-red)",
                                    fontSize: "0.75rem", cursor: "pointer",
                                  }}
                                >
                                  Close
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  )}
                </div>
              )}

              {/* Trade History */}
              {activeTab === "closed" && (
                <div className="overflow-x-auto">
                  {closedTrades.length === 0 ? (
                    <div className="p-8 text-center" style={{ color: "var(--text-muted)" }}>
                      <div style={{ fontSize: "2rem", marginBottom: 8 }}>📋</div>
                      No closed trades yet.
                    </div>
                  ) : (
                    <table className="data-table w-full">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Symbol</th>
                          <th>Dir</th>
                          <th>Entry</th>
                          <th>Exit</th>
                          <th>Margin</th>
                          <th>PnL</th>
                          <th>%</th>
                          <th>Result</th>
                          <th>Reason</th>
                        </tr>
                      </thead>
                      <tbody>
                        {closedTrades.map((t) => {
                          const pnl = t.pnl ? parseFloat(t.pnl) : 0;
                          const pnlPct = t.pnlPercent ? parseFloat(t.pnlPercent) : 0;
                          return (
                            <tr key={t.id}>
                              <td style={{ color: "var(--text-muted)", fontSize: "0.75rem" }}>#{t.id}</td>
                              <td style={{ color: "var(--text-primary)", fontWeight: 600 }}>{t.symbol}</td>
                              <td>
                                <Badge type={t.direction === "LONG" ? "long" : "short"}>
                                  {t.direction}
                                </Badge>
                              </td>
                              <td style={{ fontFamily: "monospace", fontSize: "0.8rem" }}>
                                ${fmtPrice(parseFloat(t.entryPrice))}
                              </td>
                              <td style={{ fontFamily: "monospace", fontSize: "0.8rem" }}>
                                {t.exitPrice ? `$${fmtPrice(parseFloat(t.exitPrice))}` : "-"}
                              </td>
                              <td style={{ fontFamily: "monospace", fontSize: "0.8rem" }}>
                                ${fmt(parseFloat(t.margin))}
                              </td>
                              <td style={{
                                fontFamily: "monospace", fontWeight: 600,
                                color: pnl >= 0 ? "var(--accent-green)" : "var(--accent-red)",
                              }}>
                                {pnl >= 0 ? "+" : ""}{fmt(pnl)}
                              </td>
                              <td style={{
                                fontFamily: "monospace",
                                color: pnlPct >= 0 ? "var(--accent-green)" : "var(--accent-red)",
                              }}>
                                {pnlPct >= 0 ? "+" : ""}{fmt(pnlPct)}%
                              </td>
                              <td>
                                {t.result && (
                                  <Badge type={t.result === "WIN" ? "win" : t.result === "LOSS" ? "loss" : "hold"}>
                                    {t.result}
                                  </Badge>
                                )}
                              </td>
                              <td style={{ color: "var(--text-muted)", fontSize: "0.75rem" }}>
                                {t.closedReason ?? "-"}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  )}
                </div>
              )}

              {/* Performance */}
              {activeTab === "config" && (
                <div className="p-4 grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div
                    className="rounded-lg p-3 text-center"
                    style={{ background: "var(--bg-secondary)", border: "1px solid var(--border)" }}
                  >
                    <div style={{ color: "var(--text-muted)", fontSize: "0.7rem", marginBottom: 4 }}>Initial Capital</div>
                    <div style={{ color: "var(--text-primary)", fontWeight: 700, fontSize: "1.1rem" }}>
                      ${fmt(parseFloat(wallet.initialBalance))}
                    </div>
                  </div>
                  <div
                    className="rounded-lg p-3 text-center"
                    style={{ background: "var(--bg-secondary)", border: "1px solid var(--border)" }}
                  >
                    <div style={{ color: "var(--text-muted)", fontSize: "0.7rem", marginBottom: 4 }}>Current Balance</div>
                    <div style={{ color: "var(--accent-cyan)", fontWeight: 700, fontSize: "1.1rem" }}>
                      ${fmt(balance)}
                    </div>
                  </div>
                  <div
                    className="rounded-lg p-3 text-center"
                    style={{ background: "var(--bg-secondary)", border: "1px solid var(--border)" }}
                  >
                    <div style={{ color: "var(--text-muted)", fontSize: "0.7rem", marginBottom: 4 }}>Total Return</div>
                    <div
                      style={{
                        color: totalPnlPercent >= 0 ? "var(--accent-green)" : "var(--accent-red)",
                        fontWeight: 700, fontSize: "1.1rem",
                      }}
                    >
                      {totalPnlPercent >= 0 ? "+" : ""}{fmt(totalPnlPercent)}%
                    </div>
                  </div>
                  <div
                    className="rounded-lg p-3 text-center"
                    style={{ background: "var(--bg-secondary)", border: "1px solid var(--border)" }}
                  >
                    <div style={{ color: "var(--text-muted)", fontSize: "0.7rem", marginBottom: 4 }}>Win Rate</div>
                    <div
                      style={{
                        color: parseFloat(winRate) >= 50 ? "var(--accent-green)" : "var(--accent-red)",
                        fontWeight: 700, fontSize: "1.1rem",
                      }}
                    >
                      {winRate}%
                    </div>
                  </div>

                  {/* Mini PnL breakdown */}
                  <div
                    className="col-span-2 md:col-span-4 rounded-lg p-4"
                    style={{ background: "var(--bg-secondary)", border: "1px solid var(--border)" }}
                  >
                    <div style={{ color: "var(--text-muted)", fontSize: "0.7rem", marginBottom: 12 }}>
                      TRADE BREAKDOWN
                    </div>
                    <div className="flex gap-6">
                      <div>
                        <div style={{ color: "var(--accent-green)", fontWeight: 700, fontSize: "1.3rem" }}>
                          {wallet.winCount}
                        </div>
                        <div style={{ color: "var(--text-muted)", fontSize: "0.72rem" }}>Wins</div>
                      </div>
                      <div>
                        <div style={{ color: "var(--accent-red)", fontWeight: 700, fontSize: "1.3rem" }}>
                          {wallet.lossCount}
                        </div>
                        <div style={{ color: "var(--text-muted)", fontSize: "0.72rem" }}>Losses</div>
                      </div>
                      <div>
                        <div style={{ color: "var(--text-primary)", fontWeight: 700, fontSize: "1.3rem" }}>
                          {wallet.totalTrades}
                        </div>
                        <div style={{ color: "var(--text-muted)", fontSize: "0.72rem" }}>Total</div>
                      </div>
                      <div>
                        <div
                          style={{
                            color: totalPnl >= 0 ? "var(--accent-green)" : "var(--accent-red)",
                            fontWeight: 700, fontSize: "1.3rem",
                          }}
                        >
                          {totalPnl >= 0 ? "+" : ""}{fmt(totalPnl)} USDT
                        </div>
                        <div style={{ color: "var(--text-muted)", fontSize: "0.72rem" }}>Net PnL</div>
                      </div>
                    </div>

                    {/* Win/Loss bar */}
                    {wallet.totalTrades > 0 && (
                      <div className="mt-4">
                        <div
                          className="flex rounded-full overflow-hidden"
                          style={{ height: 8, background: "var(--border)" }}
                        >
                          <div
                            style={{
                              width: `${(wallet.winCount / wallet.totalTrades) * 100}%`,
                              background: "var(--accent-green)",
                              transition: "width 0.5s ease",
                            }}
                          />
                          <div
                            style={{
                              width: `${(wallet.lossCount / wallet.totalTrades) * 100}%`,
                              background: "var(--accent-red)",
                            }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
