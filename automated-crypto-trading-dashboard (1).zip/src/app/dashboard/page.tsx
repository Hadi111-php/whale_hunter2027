import { Suspense } from "react";
import DashboardClient from "./DashboardClient";
import { getOrCreateWallet, getOrCreateBotConfig } from "@/lib/tradeEngine";
import { db } from "@/db";
import { trades } from "@/db/schema";
import { eq, and, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const wallet = await getOrCreateWallet(1);
  const config = await getOrCreateBotConfig(1);

  const openTrades = await db
    .select()
    .from(trades)
    .where(and(eq(trades.walletId, 1), eq(trades.status, "OPEN")))
    .orderBy(desc(trades.openedAt));

  const recentClosed = await db
    .select()
    .from(trades)
    .where(and(eq(trades.walletId, 1), eq(trades.status, "CLOSED")))
    .orderBy(desc(trades.closedAt))
    .limit(30);

  return (
    <Suspense fallback={<div className="min-h-screen bg-[#0a0e1a] flex items-center justify-center text-white">Loading...</div>}>
      <DashboardClient
        initialWallet={wallet}
        initialConfig={config}
        initialOpenTrades={openTrades}
        initialClosedTrades={recentClosed}
      />
    </Suspense>
  );
}
