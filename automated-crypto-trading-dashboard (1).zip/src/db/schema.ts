import {
  pgTable,
  serial,
  text,
  numeric,
  timestamp,
  integer,
  boolean,
  jsonb,
  pgEnum,
} from "drizzle-orm/pg-core";

export const tradeDirectionEnum = pgEnum("trade_direction", ["LONG", "SHORT"]);
export const tradeStatusEnum = pgEnum("trade_status", [
  "OPEN",
  "CLOSED",
  "CANCELLED",
]);
export const tradeResultEnum = pgEnum("trade_result", [
  "WIN",
  "LOSS",
  "BREAKEVEN",
]);

// Virtual Wallet
export const virtualWallets = pgTable("virtual_wallets", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().default("Main Wallet"),
  initialBalance: numeric("initial_balance", { precision: 20, scale: 8 })
    .notNull()
    .default("10000"),
  currentBalance: numeric("current_balance", { precision: 20, scale: 8 })
    .notNull()
    .default("10000"),
  totalPnl: numeric("total_pnl", { precision: 20, scale: 8 })
    .notNull()
    .default("0"),
  totalPnlPercent: numeric("total_pnl_percent", { precision: 10, scale: 4 })
    .notNull()
    .default("0"),
  winCount: integer("win_count").notNull().default(0),
  lossCount: integer("loss_count").notNull().default(0),
  totalTrades: integer("total_trades").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Trade History
export const trades = pgTable("trades", {
  id: serial("id").primaryKey(),
  walletId: integer("wallet_id").notNull().default(1),
  symbol: text("symbol").notNull(),
  direction: tradeDirectionEnum("direction").notNull(),
  status: tradeStatusEnum("status").notNull().default("OPEN"),
  result: tradeResultEnum("result"),
  entryPrice: numeric("entry_price", { precision: 20, scale: 8 }).notNull(),
  exitPrice: numeric("exit_price", { precision: 20, scale: 8 }),
  stopLoss: numeric("stop_loss", { precision: 20, scale: 8 }),
  takeProfit: numeric("take_profit", { precision: 20, scale: 8 }),
  leverage: integer("leverage").notNull().default(1),
  quantity: numeric("quantity", { precision: 20, scale: 8 }).notNull(),
  margin: numeric("margin", { precision: 20, scale: 8 }).notNull(),
  pnl: numeric("pnl", { precision: 20, scale: 8 }),
  pnlPercent: numeric("pnl_percent", { precision: 10, scale: 4 }),
  fees: numeric("fees", { precision: 20, scale: 8 }).notNull().default("0"),
  timeframe: text("timeframe").notNull().default("15m"),
  strategyName: text("strategy_name"),
  strategySignals: jsonb("strategy_signals"),
  openedAt: timestamp("opened_at").notNull().defaultNow(),
  closedAt: timestamp("closed_at"),
  closedReason: text("closed_reason"),
});

// Bot Config
export const botConfigs = pgTable("bot_configs", {
  id: serial("id").primaryKey(),
  walletId: integer("wallet_id").notNull().default(1),
  isRunning: boolean("is_running").notNull().default(false),
  symbol: text("symbol").notNull().default("BTCUSDT"),
  timeframe: text("timeframe").notNull().default("15m"),
  leverage: integer("leverage").notNull().default(5),
  riskPerTrade: numeric("risk_per_trade", { precision: 5, scale: 2 })
    .notNull()
    .default("2"),
  maxOpenTrades: integer("max_open_trades").notNull().default(3),
  strategy: text("strategy").notNull().default("RSI_MACD"),
  autoSl: boolean("auto_sl").notNull().default(true),
  autoTp: boolean("auto_tp").notNull().default(true),
  slPercent: numeric("sl_percent", { precision: 5, scale: 2 })
    .notNull()
    .default("1.5"),
  tpPercent: numeric("tp_percent", { precision: 5, scale: 2 })
    .notNull()
    .default("3"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Market snapshots for analysis
export const marketSnapshots = pgTable("market_snapshots", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  timeframe: text("timeframe").notNull(),
  openTime: timestamp("open_time").notNull(),
  open: numeric("open", { precision: 20, scale: 8 }).notNull(),
  high: numeric("high", { precision: 20, scale: 8 }).notNull(),
  low: numeric("low", { precision: 20, scale: 8 }).notNull(),
  close: numeric("close", { precision: 20, scale: 8 }).notNull(),
  volume: numeric("volume", { precision: 20, scale: 8 }).notNull(),
  rsi: numeric("rsi", { precision: 10, scale: 4 }),
  macd: numeric("macd", { precision: 20, scale: 8 }),
  macdSignal: numeric("macd_signal", { precision: 20, scale: 8 }),
  ema20: numeric("ema20", { precision: 20, scale: 8 }),
  ema50: numeric("ema50", { precision: 20, scale: 8 }),
  bbUpper: numeric("bb_upper", { precision: 20, scale: 8 }),
  bbLower: numeric("bb_lower", { precision: 20, scale: 8 }),
  signal: text("signal"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
