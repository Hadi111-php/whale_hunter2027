import { STORAGE_KEYS } from '../core/config.js';
import { readJson, uid, writeJson } from '../core/utils.js';

export class PaperBroker {
  constructor(settings, logger) {
    this.s = settings;
    this.log = logger;
    const saved = readJson(STORAGE_KEYS.state, null);
    this.state = this.normalise(saved || this.initial());
    this.migrateDay();
    // Trailing engine v2: track previous EMA state per symbol for real cross detection
    this.emaState = new Map();
  }

  initial() {
    const equity = Number(this.s.value.paperInitialEquity);
    return {
      paperEquity: equity,
      paperPositions: [],
      paperTrades: [],
      realOrders: [],
      lastCooldown: {},
      profileStarts: {},
      feesPaid: 0,
      day: new Date().toDateString(),
      dayStartEquity: equity,
      postExitTrackers: [] // FIX_POST_EXIT_STATE
    };
  }

  normalise(saved) {
    const base = this.initial();
    const positions = Array.isArray(saved.paperPositions)
      ? saved.paperPositions.map(position => ({ ...position, riskProfile: position.riskProfile || 'medium' }))
      : [];
    const trades = Array.isArray(saved.paperTrades)
      ? saved.paperTrades.map(trade => ({ ...trade, riskProfile: trade.riskProfile || 'medium' }))
      : [];
    const profileStarts = saved.profileStarts && typeof saved.profileStarts === 'object'
      ? { ...saved.profileStarts }
      : {};
    // Existing v3 history predates profile tags; treat it as the default medium run.
    if (trades.length && profileStarts.medium === undefined) profileStarts.medium = Number(this.s.value.paperInitialEquity);
    return {
      ...base,
      ...saved,
      paperPositions: positions,
      paperTrades: trades,
      realOrders: Array.isArray(saved.realOrders) ? saved.realOrders : [],
      lastCooldown: saved.lastCooldown && typeof saved.lastCooldown === 'object' ? saved.lastCooldown : {},
      profileStarts,
      feesPaid: Number.isFinite(Number(saved.feesPaid)) ? Number(saved.feesPaid) : 0
    };
  }

  save() {
    writeJson(STORAGE_KEYS.state, this.state);
  }

  reset() {
    this.state = this.initial();
    this.save();
  }

  migrateDay() {
    const today = new Date().toDateString();
    if (this.state.day !== today) {
      this.state.day = today;
      this.state.dayStartEquity = this.state.paperEquity;
      this.save();
    }
  }

  oneWayFee(notional, percentage) {
    return Math.abs(Number(notional)) * (Number(percentage) / 100);
  }

  grossPnl(position, mark) {
    const direction = position.side === 'LONG' ? 1 : -1;
    return (Number(mark) - Number(position.entry)) * direction * Number(position.qty);
  }

  closeFee(position, mark) {
    return this.oneWayFee(Number(mark) * Number(position.qty), this.s.value.feeClosePct);
  }

  // This is the cash/equity delta at a mark. Opening fee is already removed
  // from paperEquity when the position is opened, so it is not removed twice.
  markToMarketDelta(position, mark) {
    return this.grossPnl(position, mark) - this.closeFee(position, mark);
  }

  // Net PnL shown for validation: gross movement minus both entry and exit fees.
  netPnl(position, mark) {
    return this.grossPnl(position, mark)
      - Number(position.openFee || 0)
      - this.closeFee(position, mark);
  }

  dailyLossExceeded() {
    const start = Number(this.state.dayStartEquity);
    if (!(start > 0)) return true;
    return ((start - Number(this.state.paperEquity)) / start * 100) >= Number(this.s.value.dailyLossLimitPct);
  }

  canOpen(signal) {
    const s = this.s.value;
    if (!signal || signal.side === 'WAIT' || this.dailyLossExceeded()) return false;
    if (this.state.paperPositions.length >= Number(s.maxOpenPositions)) return false;
    if (this.state.paperPositions.some(position => position.symbol === signal.symbol)) return false;
    // FIX_SAMEDIR: حداکثر ۲ پوزیشن همجهت — جلوگیری از SL همزمان
    const sameDir = this.state.paperPositions.filter(p => p.side === signal.side).length;
    if (sameDir >= 2) return false;
    const cooldown = Number(s.cooldownSec) * 1000;
    return Date.now() - Number(this.state.lastCooldown[signal.symbol] || 0) > cooldown;
  }

  // FIX_LEDGER: ثبت همه سیگنالها (حتی WAIT) برای تحلیل بعدی
  logSignal(signal) {
    if (!signal) return;
    if (!Array.isArray(this.state.signalLedger)) this.state.signalLedger = [];

    // FIX_DEDUP: اگه آخرین سیگنال همین نماد + جهت + کندل بود، ثبت نکن
    const last = this.state.signalLedger[0];
    if (last
        && last.symbol === signal.symbol
        && last.side === signal.side
        && last.candleTs === signal.candleTs) {
      return;
    }

    this.state.signalLedger.unshift({
      ts: Date.now(),
      isoTime: new Date().toISOString(),
      symbol: signal.symbol,
      side: signal.side,
      score: signal.score,
      price: signal.price,
      candleTs: signal.candleTs,
      source: signal.source,
      why: signal.why,
      indicators: signal.auditSnapshot?.indicators || {
        movePct: signal.movePct, volX: signal.volX, atr: signal.atr, atrPct: signal.atrPct,
        rsi: signal.rsi, emaFast: signal.emaFast, emaSlow: signal.emaSlow
      },
      plan: signal.side !== 'WAIT' ? {
        entry: signal.entry, stop: signal.stop, take: signal.take,
        notional: signal.notional, fee: signal.fee, risk: signal.risk, reward: signal.reward
      } : null,
      fullSnapshot: signal.auditSnapshot || null
    });
    this.state.signalLedger = this.state.signalLedger.slice(0, 800);
    this.save();
  }

  open(signal, reason = 'auto', force = false) {
    if (!signal || signal.side === 'WAIT') return false;

    // FIX_SAME_DIR_LOSS: اگه پوزیشن باز هم‌جهت در ضرر داریم، این سیگنال رو رد کن
    if (!force) {
      const sameDir = this.state.paperPositions.filter(p => p.side === signal.side);
      const mark = Number(signal.price);
      if (sameDir.length > 0 && Number.isFinite(mark) && mark > 0) {
        const hasLosing = sameDir.some(p => this.netPnl(p, mark) < 0);
        if (hasLosing) {
          this.log.info('SKIP_SIGNAL_SAME_DIR_LOSS', { symbol: signal.symbol, side: signal.side });
          return false;
        }
      }
    }

    // Manual entry may bypass cooldown, never the account-level safety checks.
    if (this.dailyLossExceeded()) return false;
    if (this.state.paperPositions.length >= Number(this.s.value.maxOpenPositions)) return false;
    if (this.state.paperPositions.some(position => position.symbol === signal.symbol)) return false;
    if (!force && !this.canOpen(signal)) return false;

    const openFee = this.oneWayFee(signal.notional, this.s.value.feeOpenPct);
    const riskProfile = this.s.value.riskProfile || 'medium';
    if (!Object.prototype.hasOwnProperty.call(this.state.profileStarts, riskProfile)) {
      this.state.profileStarts[riskProfile] = this.state.paperEquity;
    }
    this.state.paperEquity -= openFee;
    this.state.feesPaid += openFee;
    this.state.paperPositions.push({
      id: uid(),
      symbol: signal.symbol,
      side: signal.side,
      entry: signal.entry,
      qty: signal.qty,
      notional: signal.notional,
      stop: signal.stop,
      initialStop: signal.stop,        // NEVER moved (hard SL floor)
      take: signal.take,
      openFee,
      openedAt: Date.now(),
      reason,
      score: signal.score,
      riskProfile,
      signalId: signal.signalId,
      source: signal.source,
      candleTs: signal.candleTs,
      auditSnapshot: signal.auditSnapshot || null,
      breakevenLocked: false,          // trail engine v2
      trailActive: false               // trail engine v2
    });
    this.state.lastCooldown[signal.symbol] = Date.now();
    this.save();
    this.log.info('PAPER OPEN', {
      symbol: signal.symbol,
      side: signal.side,
      entry: signal.entry,
      qty: signal.qty,
      score: signal.score,
      feeOpen: openFee,
      source: signal.source
    });
    return true;
  }

  close(position, mark, reason = 'manual') {
    const exit = Number(mark);
    if (!Number.isFinite(exit) || exit <= 0) return false;
    const gross = this.grossPnl(position, exit);
    const feeClose = this.closeFee(position, exit);
    const feeOpen = Number(position.openFee || 0);
    const net = gross - feeOpen - feeClose;

    // openFee has already been charged; here we settle gross PnL and exit fee.
    this.state.paperEquity += gross - feeClose;
    this.state.feesPaid += feeClose;
    this.state.paperPositions = this.state.paperPositions.filter(item => item.id !== position.id);
    this.state.paperTrades.unshift({
      time: Date.now(),
      symbol: position.symbol,
      side: position.side,
      entry: Number(position.entry),
      exit,
      grossPnl: gross,
      feeOpen,
      feeClose,
      fees: feeOpen + feeClose,
      pnl: net,
      reason,
      score: position.score,
      riskProfile: position.riskProfile || this.s.value.riskProfile || 'legacy',
      source: position.source,
      durationSec: Math.max(0, Math.round((Date.now() - Number(position.openedAt)) / 1000)),
      auditSnapshot: position.auditSnapshot || null,
      entrySnapshot: {
        entry: position.entry,
        stopInitial: position.stop,
        take: position.take,
        score: position.score,
        openedAt: position.openedAt,
        highWater: position.highWater,
        lowWater: position.lowWater
      }
    });
    this.state.paperTrades = this.state.paperTrades.slice(0, 350);

    // FIX_POST_EXIT_CREATE: create tracker to monitor post-exit price
    if (!Array.isArray(this.state.postExitTrackers)) this.state.postExitTrackers = [];
    this.state.postExitTrackers.unshift({
      symbol: position.symbol,
      side: position.side,
      entry: Number(position.entry),
      exitPrice: exit,
      exitAt: Date.now(),
      reason,
      score: position.score,
      riskProfile: position.riskProfile || this.s.value.riskProfile || 'medium',
      checkpoints: []
    });
    this.state.postExitTrackers = this.state.postExitTrackers.slice(0, 500);

    this.save();
    this.log.info('PAPER CLOSE', {
      symbol: position.symbol,
      side: position.side,
      exit,
      gross,
      fees: feeOpen + feeClose,
      net,
      reason
    });
    return true;
  }

  updateStops(marketMap, signalsMap) {
    const now = Date.now();
    const maxHoldMs = Math.max(0, Number(this.s.value.maxHoldMinutes) || 0) * 60_000;
    const minHoldMs = Math.max(0, Number(this.s.value.minHoldSec) || 0) * 1000;

    const trailActivationR = Number(this.s.value.trailActivationR ?? 0.5);
    const trailAtrMult      = Number(this.s.value.trailAtrMult ?? 1.8);
    const lockBreakevenAtR  = Number(this.s.value.lockBreakevenAtR ?? 0.3);
    const revVolX           = Number(this.s.value.reversalVolumeX ?? 1.5);
    const revRsiLong        = Number(this.s.value.reversalRsiLong ?? 70);
    const revRsiShort       = Number(this.s.value.reversalRsiShort ?? 30);

    for (const position of [...this.state.paperPositions]) {
      const market = marketMap.get(position.symbol);
      const signal = signalsMap ? signalsMap.get(position.symbol) : null;
      if (!market) continue;

      const mark = Number(market.price);
      if (!Number.isFinite(mark) || mark <= 0) continue;

      const isLong = position.side === 'LONG';
      const entry  = Number(position.entry);
      const hardStop = Number(position.initialStop || position.stop);
      const risk = Math.abs(entry - hardStop) || entry * 0.004;
      const rMultiple = isLong ? (mark - entry) / risk : (entry - mark) / risk;
      const heldMs = now - Number(position.openedAt || now);
      const holdSatisfied = heldMs >= minHoldMs;

      let exit = null;
      let reason = '';

      // Water marks for trailing
      position.highWater = Math.max(Number(position.highWater || entry), mark);
      position.lowWater  = Math.min(Number(position.lowWater  || entry), mark);

      // (1) HARD SL — the ONLY stop that is allowed below breakeven.
      if (isLong && mark <= hardStop) {
        exit = mark; reason = 'SL_HARD_STOP';
      } else if (!isLong && mark >= hardStop) {
        exit = mark; reason = 'SL_HARD_STOP';
      }

      // (2) Lock breakeven + fees once we reach lockBreakevenAtR
      const roundTripFee = Number(position.openFee || 0) + this.closeFee(position, mark);
      const feeInPrice = Number(position.qty) > 0 ? roundTripFee / Number(position.qty) : 0;
      const breakevenPlusFees = isLong
        ? entry + feeInPrice * 1.5
        : entry - feeInPrice * 1.5;

      if (!exit && rMultiple >= lockBreakevenAtR) {
        position.breakevenLocked = true;
        if (isLong && Number(position.stop) < breakevenPlusFees) {
          position.stop = breakevenPlusFees;
        } else if (!isLong && Number(position.stop) > breakevenPlusFees) {
          position.stop = breakevenPlusFees;
        }
      }

      // (3) TRAILING — activates at trailActivationR, follows high/low water
      if (!exit && rMultiple >= trailActivationR) {
        const atr = (signal && Number(signal.atr) > 0) ? Number(signal.atr) : mark * 0.005;
        const trailDistance = atr * trailAtrMult;

        if (isLong) {
          const newStop = position.highWater - trailDistance;
          if (newStop > Number(position.stop)) {
            position.stop = newStop;
            position.trailActive = true;
          }
          if (mark <= Number(position.stop)) {
            exit = mark;
            reason = position.breakevenLocked ? 'TRAIL_LOCKED_PROFIT' : 'TRAIL_STOP';
          }
        } else {
          const newStop = position.lowWater + trailDistance;
          if (newStop < Number(position.stop)) {
            position.stop = newStop;
            position.trailActive = true;
          }
          if (mark >= Number(position.stop)) {
            exit = mark;
            reason = position.breakevenLocked ? 'TRAIL_LOCKED_PROFIT' : 'TRAIL_STOP';
          }
        }
      }

      // (4) REAL REVERSAL — cross transition + volume + RSI confirmation
      //     Requires: holdSatisfied + in profit (rMultiple > 0)
      if (!exit && signal && holdSatisfied && rMultiple > 0) {
        const fast = Number(signal.emaFast);
        const slow = Number(signal.emaSlow);
        if (fast > 0 && slow > 0) {
          const nowFastAboveSlow = fast > slow;
          const prev = this.emaState.get(position.symbol) || {};
          const bearishCross = prev.fastAboveSlow === true  && nowFastAboveSlow === false;
          const bullishCross = prev.fastAboveSlow === false && nowFastAboveSlow === true;
          this.emaState.set(position.symbol, { fastAboveSlow: nowFastAboveSlow });

          const volX = Number(signal.volX) || 0;
          const rsi  = Number(signal.rsi)  || 50;

          if (isLong  && bearishCross && volX >= revVolX && rsi >= revRsiLong) {
            exit = mark; reason = 'REVERSAL_EMA_CROSS_CONFIRMED';
          }
          if (!isLong && bullishCross && volX >= revVolX && rsi <= revRsiShort) {
            exit = mark; reason = 'REVERSAL_EMA_CROSS_CONFIRMED';
          }
        }
      }

      // (5) MAX HOLD — only if user configured it (>0)
      if (!exit && maxHoldMs > 0 && heldMs >= maxHoldMs) {
        exit = mark; reason = 'MAX_HOLD_TIME';
      }

      if (exit !== null) this.close(position, exit, reason);
    }

    // Update post-exit trackers (existing)
    this.recordPostExit(marketMap);
  }

  // FIX_POST_EXIT_METHODS
  recordPostExit(marketMap) {
    if (!Array.isArray(this.state.postExitTrackers)) return;
    const now = Date.now();
    const CHECKPOINTS = [5, 15, 60, 240]; // minutes
    let dirty = false;
    for (const tracker of this.state.postExitTrackers) {
      const market = marketMap && marketMap.get ? marketMap.get(tracker.symbol) : null;
      if (!market) continue;
      const price = Number(market.price);
      if (!Number.isFinite(price) || price <= 0) continue;
      const ageMin = (now - tracker.exitAt) / 60000;
      for (const cp of CHECKPOINTS) {
        if (ageMin < cp) continue;
        if (tracker.checkpoints.some(c => c.minutes === cp)) continue;
        const raw = (price - tracker.exitPrice) / tracker.exitPrice * 100;
        const missedPct = tracker.side === 'LONG' ? raw : -raw;
        tracker.checkpoints.push({
          minutes: cp,
          price: Number(price.toFixed(8)),
          rawPct: Number(raw.toFixed(4)),
          missedPct: Number(missedPct.toFixed(4)),
          favorableForHolding: missedPct > 0
        });
        dirty = true;
      }
    }
    if (dirty) this.save();
  }

  getPostExitStats(minutes = 15) {
    if (!Array.isArray(this.state.postExitTrackers)) return null;
    const relevant = [];
    for (const t of this.state.postExitTrackers) {
      const cp = (t.checkpoints || []).find(c => c.minutes === minutes);
      if (cp) relevant.push({ tracker: t, cp });
    }
    if (!relevant.length) return null;
    let premature = 0, good = 0, totalMissed = 0;
    for (const { cp } of relevant) {
      if (cp.favorableForHolding) premature++; else good++;
      totalMissed += cp.missedPct;
    }
    return {
      minutes,
      total: relevant.length,
      premature,
      good,
      prematurePct: (premature / relevant.length) * 100,
      avgMissedPct: totalMissed / relevant.length
    };
  }

  exportFiltered(filters = {}) {
    const { symbol, fromDate, toDate, limit, side, minScore } = filters || {};
    const fromTs = fromDate ? new Date(fromDate).getTime() : 0;
    const toTs = toDate ? new Date(toDate).getTime() + 86400000 : Infinity;
    const maxCount = Math.max(1, Number(limit) || 5000);
    const symUp = symbol ? String(symbol).toUpperCase() : null;

    const filterFn = (item) => {
      if (!item) return false;
      const itemTs = Number(item.time || item.ts || item.exitAt || 0);
      if (itemTs < fromTs || itemTs > toTs) return false;
      if (symUp && String(item.symbol || '').toUpperCase() !== symUp) return false;
      if (side && item.side !== side) return false;
      if (minScore && Number(item.score || 0) < Number(minScore)) return false;
      return true;
    };

    return {
      exportedAt: new Date().toISOString(),
      filters: { symbol: symUp || 'ALL', fromDate: fromDate || 'all', toDate: toDate || 'all', limit: maxCount, side: side || 'ALL' },
      summary: {
        tradesCount: (this.state.paperTrades || []).filter(filterFn).length,
        signalsCount: (this.state.signalLedger || []).filter(filterFn).length,
        trackersCount: (this.state.postExitTrackers || []).filter(filterFn).length
      },
      paperTrades: (this.state.paperTrades || []).filter(filterFn).slice(0, maxCount),
      signalLedger: (this.state.signalLedger || []).filter(filterFn).slice(0, maxCount),
      postExitTrackers: (this.state.postExitTrackers || []).filter(filterFn).slice(0, maxCount)
    };
  }
}
