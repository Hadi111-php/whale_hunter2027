import { STORAGE_KEYS } from '../core/config.js';
import { readJson, uid, writeJson } from '../core/utils.js';

export class PaperBroker {
  constructor(settings, logger) {
    this.s = settings;
    this.log = logger;
    const saved = readJson(STORAGE_KEYS.state, null);
    this.state = this.normalise(saved || this.initial());
    this.migrateDay();
  }

  initial() {
    const equity = Number(this.s.value.paperInitialEquity);
    return {
      paperEquity: equity,
      paperPositions: [],
      paperTrades: [],
      realOrders: [],
      lastCooldown: {},
      profileStarts: {},
      feesPaid: 0,
      day: new Date().toDateString(),
      dayStartEquity: equity
    };
  }

  normalise(saved) {
    const base = this.initial();
    const positions = Array.isArray(saved.paperPositions)
      ? saved.paperPositions.map(position => ({ ...position, riskProfile: position.riskProfile || 'medium' }))
      : [];
    const trades = Array.isArray(saved.paperTrades)
      ? saved.paperTrades.map(trade => ({ ...trade, riskProfile: trade.riskProfile || 'medium' }))
      : [];
    const profileStarts = saved.profileStarts && typeof saved.profileStarts === 'object'
      ? { ...saved.profileStarts }
      : {};
    // Existing v3 history predates profile tags; treat it as the default medium run.
    if (trades.length && profileStarts.medium === undefined) profileStarts.medium = Number(this.s.value.paperInitialEquity);
    return {
      ...base,
      ...saved,
      paperPositions: positions,
      paperTrades: trades,
      realOrders: Array.isArray(saved.realOrders) ? saved.realOrders : [],
      lastCooldown: saved.lastCooldown && typeof saved.lastCooldown === 'object' ? saved.lastCooldown : {},
      profileStarts,
      feesPaid: Number.isFinite(Number(saved.feesPaid)) ? Number(saved.feesPaid) : 0
    };
  }

  save() {
    writeJson(STORAGE_KEYS.state, this.state);
  }

  reset() {
    this.state = this.initial();
    this.save();
  }

  migrateDay() {
    const today = new Date().toDateString();
    if (this.state.day !== today) {
      this.state.day = today;
      this.state.dayStartEquity = this.state.paperEquity;
      this.save();
    }
  }

  oneWayFee(notional, percentage) {
    return Math.abs(Number(notional)) * (Number(percentage) / 100);
  }

  grossPnl(position, mark) {
    const direction = position.side === 'LONG' ? 1 : -1;
    return (Number(mark) - Number(position.entry)) * direction * Number(position.qty);
  }

  closeFee(position, mark) {
    return this.oneWayFee(Number(mark) * Number(position.qty), this.s.value.feeClosePct);
  }

  // This is the cash/equity delta at a mark. Opening fee is already removed
  // from paperEquity when the position is opened, so it is not removed twice.
  markToMarketDelta(position, mark) {
    return this.grossPnl(position, mark) - this.closeFee(position, mark);
  }

  // Net PnL shown for validation: gross movement minus both entry and exit fees.
  netPnl(position, mark) {
    return this.grossPnl(position, mark)
      - Number(position.openFee || 0)
      - this.closeFee(position, mark);
  }

  dailyLossExceeded() {
    const start = Number(this.state.dayStartEquity);
    if (!(start > 0)) return true;
    return ((start - Number(this.state.paperEquity)) / start * 100) >= Number(this.s.value.dailyLossLimitPct);
  }

  canOpen(signal) {
    const s = this.s.value;
    if (!signal || signal.side === 'WAIT' || this.dailyLossExceeded()) return false;
    if (this.state.paperPositions.length >= Number(s.maxOpenPositions)) return false;
    if (this.state.paperPositions.some(position => position.symbol === signal.symbol)) return false;
    const cooldown = Number(s.cooldownSec) * 1000;
    return Date.now() - Number(this.state.lastCooldown[signal.symbol] || 0) > cooldown;
  }

  open(signal, reason = 'auto', force = false) {
    if (!signal || signal.side === 'WAIT') return false;
    // Manual entry may bypass cooldown, never the account-level safety checks.
    if (this.dailyLossExceeded()) return false;
    if (this.state.paperPositions.length >= Number(this.s.value.maxOpenPositions)) return false;
    if (this.state.paperPositions.some(position => position.symbol === signal.symbol)) return false;
    if (!force && !this.canOpen(signal)) return false;

    const openFee = this.oneWayFee(signal.notional, this.s.value.feeOpenPct);
    const riskProfile = this.s.value.riskProfile || 'medium';
    if (!Object.prototype.hasOwnProperty.call(this.state.profileStarts, riskProfile)) {
      this.state.profileStarts[riskProfile] = this.state.paperEquity;
    }
    this.state.paperEquity -= openFee;
    this.state.feesPaid += openFee;
    this.state.paperPositions.push({
      id: uid(),
      symbol: signal.symbol,
      side: signal.side,
      entry: signal.entry,
      qty: signal.qty,
      notional: signal.notional,
      stop: signal.stop,
      take: signal.take,
      openFee,
      openedAt: Date.now(),
      reason,
      score: signal.score,
      riskProfile,
      signalId: signal.signalId,
      source: signal.source,
      candleTs: signal.candleTs,
      auditSnapshot: signal.auditSnapshot || null
    });
    this.state.lastCooldown[signal.symbol] = Date.now();
    this.save();
    this.log.info('PAPER OPEN', {
      symbol: signal.symbol,
      side: signal.side,
      entry: signal.entry,
      qty: signal.qty,
      score: signal.score,
      feeOpen: openFee,
      source: signal.source
    });
    return true;
  }

  close(position, mark, reason = 'manual') {
    const exit = Number(mark);
    if (!Number.isFinite(exit) || exit <= 0) return false;
    const gross = this.grossPnl(position, exit);
    const feeClose = this.closeFee(position, exit);
    const feeOpen = Number(position.openFee || 0);
    const net = gross - feeOpen - feeClose;

    // openFee has already been charged; here we settle gross PnL and exit fee.
    this.state.paperEquity += gross - feeClose;
    this.state.feesPaid += feeClose;
    this.state.paperPositions = this.state.paperPositions.filter(item => item.id !== position.id);
    this.state.paperTrades.unshift({
      time: Date.now(),
      symbol: position.symbol,
      side: position.side,
      entry: Number(position.entry),
      exit,
      grossPnl: gross,
      feeOpen,
      feeClose,
      fees: feeOpen + feeClose,
      pnl: net,
      reason,
      score: position.score,
      riskProfile: position.riskProfile || this.s.value.riskProfile || 'legacy',
      source: position.source,
      durationSec: Math.max(0, Math.round((Date.now() - Number(position.openedAt)) / 1000)),
      auditSnapshot: position.auditSnapshot || null,
      entrySnapshot: {
        entry: position.entry,
        stopInitial: position.stop,
        take: position.take,
        score: position.score,
        openedAt: position.openedAt,
        highWater: position.highWater,
        lowWater: position.lowWater
      }
    });
    this.state.paperTrades = this.state.paperTrades.slice(0, 350);
    this.save();
    this.log.info('PAPER CLOSE', {
      symbol: position.symbol,
      side: position.side,
      exit,
      gross,
      fees: feeOpen + feeClose,
      net,
      reason
    });
    return true;
  }

  updateStops(marketMap, signalsMap) {
    const now = Date.now();
    const maxHoldMs = Math.max(0, Number(this.s.value.maxHoldMinutes) || 0) * 60_000;

    for (const position of [...this.state.paperPositions]) {
      const market = marketMap.get(position.symbol);
      const signal = signalsMap ? signalsMap.get(position.symbol) : null;
      if (!market) continue;

      const mark = Number(market.price);
      if (!Number.isFinite(mark) || mark <= 0) continue;
      const isLong = position.side === 'LONG';
      const entry = Number(position.entry);
      let exit = null;
      let reason = '';

      // Do not use the whole current candle's high/low to manage a position
      // opened mid-candle: those extremes may have happened before entry.
      // This scanner only has snapshots, so exits are evaluated against live mark.
      position.highWater = Math.max(Number(position.highWater || entry), mark);
      position.lowWater = Math.min(Number(position.lowWater || entry), mark);

      if (isLong && mark <= Number(position.stop)) {
        exit = Number(position.stop);
        reason = 'SL_HARD_STOP';
      } else if (!isLong && mark >= Number(position.stop)) {
        exit = Number(position.stop);
        reason = 'SL_HARD_STOP';
      }

      if (!exit && Number(position.take) > 0) {
        if (isLong && mark >= Number(position.take)) {
          exit = Number(position.take);
          reason = 'TAKE_PROFIT';
        } else if (!isLong && mark <= Number(position.take)) {
          exit = Number(position.take);
          reason = 'TAKE_PROFIT';
        }
      }

      if (!exit && maxHoldMs > 0 && now - Number(position.openedAt || now) >= maxHoldMs) {
        exit = mark;
        reason = 'MAX_HOLD_TIME';
      }

      const gross = this.grossPnl(position, mark);
      // FIX: use round-trip fee, not just 1.5x open fee
      const roundTripFee = Number(position.openFee || 0) + this.closeFee(position, mark);
      const isInProfit = gross > roundTripFee * 2.5;
      if (!exit && isInProfit) {
        const breakevenStop = isLong ? entry * 1.002 : entry * 0.998;
        if (isLong && Number(position.stop) < breakevenStop) {
          position.stop = breakevenStop;
        } else if (!isLong && Number(position.stop) > breakevenStop) {
          position.stop = breakevenStop;
        }

        const atr = (signal && Number(signal.atr) > 0) ? Number(signal.atr) : mark * 0.005;
        const trailDistance = atr * 1.25;
        if (isLong) {
          position.stop = Math.max(Number(position.stop), position.highWater - trailDistance);
          if (mark <= Number(position.stop)) {
            exit = mark;
            reason = 'PROFIT_TRAIL_REVERSED';
          }
        } else {
          position.stop = Math.min(Number(position.stop), position.lowWater + trailDistance);
          if (mark >= Number(position.stop)) {
            exit = mark;
            reason = 'PROFIT_TRAIL_REVERSED';
          }
        }

        if (!exit && signal) {
          if (isLong) {
            const rsiReversal = Number(signal.rsi) > 68 && Number(signal.movePct) < -0.15;
            const emaBearCross = Number(signal.emaFast) > 0 && Number(signal.emaSlow) > 0
              && Number(signal.emaFast) < Number(signal.emaSlow) && Number(signal.volX) > 1.3;
            if (rsiReversal || emaBearCross) {
              exit = mark;
              reason = rsiReversal ? 'REVERSAL_RSI_OVERBOUGHT' : 'REVERSAL_EMA_CROSS';
            }
          } else {
            const rsiReversal = Number(signal.rsi) < 32 && Number(signal.movePct) > 0.15;
            const emaBullCross = Number(signal.emaFast) > 0 && Number(signal.emaSlow) > 0
              && Number(signal.emaFast) > Number(signal.emaSlow) && Number(signal.volX) > 1.3;
            if (rsiReversal || emaBullCross) {
              exit = mark;
              reason = rsiReversal ? 'REVERSAL_RSI_OVERSOLD' : 'REVERSAL_EMA_CROSS';
            }
          }
        }
      }

      if (exit !== null) this.close(position, exit, reason);
    }
  }
}
