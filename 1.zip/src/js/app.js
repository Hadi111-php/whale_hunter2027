import { $ } from './core/utils.js';
import { SettingsStore } from './services/settings-store.js';
import { Logger } from './services/logger.js';
import { MarketFeed } from './core/market-feed.js';
import { MomentumScalpStrategy } from './services/strategy.js';
import { PaperBroker } from './services/paper-broker.js';
import { RealBroker } from './services/real-broker.js';
import { PerformanceReport } from './services/performance-report.js';
import { DashboardView } from './ui/view.js';

export class ScalpLabApp {
  constructor() {
    this.settings = new SettingsStore();
    this.logger = new Logger();
    this.signals = new Map();
    this.prices = new Map();
    this.marketData = new Map();
    this.dataErrors = new Map();
    this.lastErrorLog = new Map();
    this.performance = new PerformanceReport();

    this.rebuildServices();

    // ---- Shared market feed (single source of truth) ----
    this.feed = new MarketFeed(this.settings, this.logger);
    try { window.__marketFeed = this.feed; } catch (e) { /* SSR safe */ }
    this.feedUnsub = this.feed.subscribe(payload => this.onFeed(payload));

    this.view = new DashboardView(this);
  }

  rebuildServices() {
    this.strategy = new MomentumScalpStrategy(this.settings);
    this.paper = this.paper || new PaperBroker(this.settings, this.logger);
    // Never silently preserve real-order permission across a settings change
    if (this.real?.enabled) this.real.kill();
    this.real = new RealBroker(this.settings, this.paper, this.logger);
    if (typeof document !== 'undefined' && $('#realAutoToggle')) {
      $('#realAutoToggle').checked = false;
    }
  }

  modeLabel() {
    const mode = this.settings.value.dataMode;
    if (mode === 'mock-local') return 'MOCK LOCAL';
    if (mode === 'mock-server') return 'MOCK SERVER';
    return 'BYBIT LIVE';
  }

  // Manual refresh button -> one immediate tick
  async scan() { return this.feed.tick(); }

  // Called by MarketFeed on every successful tick
  onFeed({ data, errors, at }) {
    const symbols = [...new Set(this.settings.value.symbols)].filter(Boolean);
    this.marketData = data;
    this.dataErrors = errors;

    this.signals.clear();
    this.prices.clear();
    this.paper.migrateDay();

    let ok = 0;
    for (const symbol of symbols) {
      const market = data.get(symbol);
      if (!market) {
        const err = errors.get(symbol) || 'NO DATA';
        if (this.lastErrorLog.get(symbol) !== err) {
          this.logger.info('DATA ERROR', { symbol, error: err });
          this.lastErrorLog.set(symbol, err);
        }
        continue;
      }
      ok++;
      this.lastErrorLog.delete(symbol);

      const signal = this.strategy.analyze(market);
      this.signals.set(symbol, signal);
      this.prices.set(symbol, market.price);
      try { this.paper.logSignal(signal); } catch (e) { /* silent */ }
    }

    // ---- Exit engine FIRST (protects open positions) ----
    this.paper.updateStops(this.marketData, this.signals);
    try { this.paper.recordPostExit(this.marketData); } catch (e) { /* silent */ }

    // ---- Then entries ----
    const paperToggle = $('#paperAutoToggle');
    const paperEnabled = !!paperToggle?.checked || this.real.enabled;
    for (const signal of this.signals.values()) {
      if (paperEnabled && signal.side !== 'WAIT') this.paper.open(signal, 'auto');
    }

    // Real broker (fire-and-forget; gate inside RealBroker)
    if (this.real.enabled) {
      for (const signal of this.signals.values()) {
        if (signal.side !== 'WAIT' && signal.score >= Number(this.settings.value.minScore)) {
          this.real.send(signal).catch(() => {});
        }
      }
    }

    const update = new Date().toLocaleTimeString();
    const statusEl = $('#statusText');
    const lastEl = $('#lastUpdate');
    if (lastEl) lastEl.textContent = `آخرین اسکن: ${update} • ${ok}/${symbols.length}`;
    if (statusEl) {
      statusEl.textContent = ok > 0
        ? `${this.modeLabel()} • ${ok}/${symbols.length} بازار • ${this.settings.value.timeframe}m`
        : 'دیتای بازار در دسترس نیست؛ هیچ fallback ساختگی استفاده نشد';
    }

    this.view.renderAll();
  }

  applyRiskProfile(profile) {
    this.settings.applyRiskProfile(profile);
    this.rebuildServices();
    this.view.renderSettings();
    this.schedule();
    this.logger.info('RISK PROFILE APPLIED', { profile: this.settings.value.riskProfile });
    this.view.renderAll();
    void this.scan();
  }

  schedule() {
    if ($('#autoScanToggle')?.checked) this.feed.start();
    else this.feed.stop();
  }

  closeAllPaper() {
    for (const position of [...this.paper.state.paperPositions]) {
      this.paper.close(position, this.prices.get(position.symbol) || position.entry, 'close-all');
    }
    this.view.renderAll();
  }

  resetPaper() {
    this.paper.reset();
    this.view.renderAll();
  }

  async start() {
    this.view.bind();
    this.view.renderSettings();
    this.view.renderAll();
    this.schedule();
    this.logger.info('APP START', {
      mode: this.modeLabel(),
      paperDefault: this.settings.value.paperAutoDefault,
    });
    await this.scan().catch(error =>
      this.logger.info('INITIAL SCAN ERROR', { error: error.message })
    );
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
  }
}
