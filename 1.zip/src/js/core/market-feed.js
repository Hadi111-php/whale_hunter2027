// src/js/core/market-feed.js
// ============================================================
//  MarketFeed — shared, singleton-friendly market data provider
// ============================================================
//  - Fetches each symbol ONCE per tick
//  - Pushes updates to all subscribers atomically
//  - External consumers (pump-dump, alerting, ...) subscribe to
//    window.__marketFeed instead of doing their own network calls
// ============================================================
import { MarketClient } from '../services/market-client.js';

export class MarketFeed {
  constructor(settings, logger) {
    this.s = settings;
    this.log = logger;
    this.market = new MarketClient(settings, logger);
    this.data = new Map();           // symbol -> market object
    this.errors = new Map();         // symbol -> error message
    this.subscribers = new Set();
    this.timer = null;
    this.inFlight = false;
    this.lastUpdateAt = 0;
    this.tickCount = 0;
  }

  // ---------- Subscription ----------
  subscribe(fn) {
    if (typeof fn !== 'function') return () => {};
    this.subscribers.add(fn);
    // Fire immediately if we already have data
    if (this.data.size > 0) {
      try { fn(this.snapshot()); }
      catch (e) { this.log.info('FEED_SUB_ERR', { err: e.message }); }
    }
    return () => this.subscribers.delete(fn);
  }

  snapshot() {
    return {
      data: new Map(this.data),
      errors: new Map(this.errors),
      at: this.lastUpdateAt,
      tick: this.tickCount,
    };
  }

  notify() {
    const payload = this.snapshot();
    for (const fn of this.subscribers) {
      try { fn(payload); }
      catch (e) { this.log.info('FEED_SUB_ERR', { err: e.message }); }
    }
  }

  // ---------- Accessors ----------
  get(symbol)      { return this.data.get(symbol) || null; }
  getPrice(sym)    { const m = this.data.get(sym); return m ? Number(m.price) : null; }
  getSymbols()     { return [...this.data.keys()]; }
  getErrors()      { return new Map(this.errors); }
  isReady()        { return this.data.size > 0; }

  // ---------- Lifecycle ----------
  async tick() {
    if (this.inFlight) return;
    this.inFlight = true;
    const symbols = [...new Set(this.s.value.symbols)].filter(Boolean);

    try {
      const results = await Promise.allSettled(
        symbols.map(sym => this.market.get(sym))
      );

      const nextData = new Map();
      const nextErrors = new Map();
      let ok = 0;

      results.forEach((r, i) => {
        const sym = symbols[i];
        if (r.status === 'fulfilled') {
          nextData.set(sym, r.value);
          ok++;
        } else {
          nextErrors.set(sym, r.reason?.message || 'unknown');
        }
      });

      // Atomic swap — subscribers always see a consistent snapshot
      this.data = nextData;
      this.errors = nextErrors;
      this.lastUpdateAt = Date.now();
      this.tickCount++;

      this.log.info('FEED_TICK', { ok, total: symbols.length, tick: this.tickCount });
      this.notify();
      return { ok, total: symbols.length };
    } finally {
      this.inFlight = false;
    }
  }

  start() {
    this.stop();
    const sec = Math.max(3, Number(this.s.value.scanIntervalSec) || 5);
    this.timer = setInterval(() => { this.tick().catch(() => {}); }, sec * 1000);
    this.log.info('FEED_START', { interval: sec });
    return this.tick();
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  destroy() {
    this.stop();
    this.subscribers.clear();
  }
}
