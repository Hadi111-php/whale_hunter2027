import { DEFAULT_SETTINGS, RISK_PROFILES, STORAGE_KEYS } from '../core/config.js';
import { clone, readJson, writeJson } from '../core/utils.js';

export class SettingsStore {
  constructor() {
    this.value = { ...clone(DEFAULT_SETTINGS), ...readJson(STORAGE_KEYS.settings, {}) };
    // FIX: force-migrate timeframe if stored as 1m by buggy agent
    const tf = Number(this.value.timeframe);
    if (!this.value.timeframe || tf < 5) {
      this.value.timeframe = '15';
      writeJson(STORAGE_KEYS.settings, this.value);
      console.log('[SettingsStore] FIX migrated timeframe -> 15m (was ' + tf + 'm)');
    }
  }

  save(next = this.value) {
    this.value = { ...clone(DEFAULT_SETTINGS), ...next };
    writeJson(STORAGE_KEYS.settings, this.value);
  }

  applyRiskProfile(profile = 'medium') {
    const selected = RISK_PROFILES[profile] ? profile : 'medium';
    this.save({ ...this.value, ...clone(RISK_PROFILES[selected]), riskProfile: selected });
  }

  reset() {
    this.save(clone(DEFAULT_SETTINGS));
  }
}
