import { readJson, writeJson } from '../core/utils.js';
import { STORAGE_KEYS } from '../core/config.js';

export class Logger {
  constructor() {
    this.lines = readJson(STORAGE_KEYS.logs, []);
    this.signalLog = [];
    this.listeners = new Set();
  }

  onChange(fn) { this.listeners.add(fn); fn(this.lines); }

  emit() {
    writeJson(STORAGE_KEYS.logs, this.lines);
    this.listeners.forEach(fn => fn(this.lines));
  }

  info(msg, obj) {
    const line = `[${new Date().toLocaleString()}] ${msg}${obj ? ' ' + JSON.stringify(obj) : ''}`;
    this.lines.unshift(line);
    this.lines = this.lines.slice(0, 700);
    this.emit();
  }

  // Rich signal log — every parameter, ready for JSON export
  signal(sig) {
    if (!sig) return;
    const entry = {
      ts: Date.now(),
      iso: new Date().toISOString(),
      symbol: sig.symbol,
      source: sig.source,
      side: sig.side,
      score: sig.score,
      price: sig.price,
      // raw indicators
      movePct: sig.movePct,
      oneCandlePct: sig.oneCandlePct,
      volX: sig.volX,
      atr: sig.atr,
      atrPct: sig.atrPct,
      rsi: sig.rsi,
      emaFast: sig.emaFast,
      emaSlow: sig.emaSlow,
      bodyPct: sig.auditSnapshot?.indicators?.bodyPct ?? null,
      breakoutUp: sig.auditSnapshot?.indicators?.breakoutUp ?? null,
      breakoutDown: sig.auditSnapshot?.indicators?.breakoutDown ?? null,
      trendUp: sig.auditSnapshot?.indicators?.trendUp ?? null,
      trendDown: sig.auditSnapshot?.indicators?.trendDown ?? null,
      // plan
      entry: sig.entry,
      stop: sig.stop,
      take: sig.take,
      qty: sig.qty,
      notional: sig.notional,
      feeOpen: sig.feeOpen,
      feeClose: sig.feeClose,
      feeRoundTrip: sig.fee,
      risk: sig.risk,
      reward: sig.reward,
      // why + scoring
      why: sig.why,
      longScore: sig.auditSnapshot?.scoring?.longScore ?? null,
      shortScore: sig.auditSnapshot?.scoring?.shortScore ?? null,
      reasons: sig.auditSnapshot?.scoring?.reasons ?? [],
      // settings snapshot at signal time
      settingsSnapshot: sig.auditSnapshot?.settingsSnapshot ?? null,
      // last candles
      lastCandle: sig.auditSnapshot?.lastCandle ?? null,
      prevCandle: sig.auditSnapshot?.previousCandle ?? null,
    };
    this.signalLog.unshift(entry);
    this.signalLog = this.signalLog.slice(0, 1000);
    return entry;
  }

  exportSignalLog() {
    return {
      exportedAt: new Date().toISOString(),
      count: this.signalLog.length,
      signals: this.signalLog,
    };
  }

  clear() {
    this.lines = [];
    this.signalLog = [];
    this.emit();
  }
}
