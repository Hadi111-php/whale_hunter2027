#!/data/data/com.termux/files/usr/bin/bash

OUT="/sdcard/Download/project_dump.sh"

echo "#!/data/data/com.termux/files/usr/bin/bash" > "$OUT"
echo "# Auto-generated project dump" >> "$OUT"
echo "" >> "$OUT"

# پیدا کردن همه فایل‌ها به جز پوشه‌های اضافی
find . -type f \
  -not -path "./.git/*" \
  -not -path "./node_modules/*" \
  -not -path "./.venv/*" \
  -not -path "./__pycache__/*" \
  | sort | while read -r file; do

    # مسیر رو تمیز کن (حذف ./ از اول)
    clean="${file#./}"

    echo "mkdir -p \"\$(dirname \"$clean\")\"" >> "$OUT"
    echo "cat > \"$clean\" << 'EOF_FILE_XYZ'" >> "$OUT"
    cat "$file" >> "$OUT"
    echo "" >> "$OUT"
    echo "EOF_FILE_XYZ" >> "$OUT"
    echo "" >> "$OUT"
done

echo "echo '✅ پروژه بازسازی شد!'" >> "$OUT"
chmod +x "$OUT"
echo "✅ ساخته شد: $OUT"
