#!/data/data/com.termux/files/usr/bin/bash

echo "=========================================="
echo "  Futures Scalp Lab Patcher v2 (Python)"
echo "=========================================="
echo ""

if [ ! -f "src/js/core/config.js" ]; then
  echo "[!!] Run this inside project root"
  echo "     Current dir: $(pwd)"
  echo "     Missing: src/js/core/config.js"
  exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "[!!] python3 missing. Install:"
  echo "     pkg install python -y"
  exit 1
fi

BACKUP="backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP/src/js/core" "$BACKUP/src/js/services"
for f in src/js/core/config.js src/js/services/strategy.js src/js/services/paper-broker.js src/js/services/settings-store.js; do
  [ -f "$f" ] && cp "$f" "$BACKUP/$f"
done
echo "[OK] Backup -> $BACKUP"
echo ""

python3 << 'PYEOF'
import os

def patch(path, pairs):
    if not os.path.exists(path):
        print(f"  [!!] MISSING: {path}")
        return 0, len(pairs)
    with open(path, 'r', encoding='utf-8') as f:
        src = f.read()
    done = 0
    for i, (old, new) in enumerate(pairs):
        if old in src:
            src = src.replace(old, new, 1)
            done += 1
        else:
            print(f"  [!!] anchor #{i+1} NOT FOUND in {path}")
            print(f"       preview: {old[:90]!r}")
    with open(path, 'w', encoding='utf-8') as f:
        f.write(src)
    status = "OK" if done == len(pairs) else "PARTIAL"
    print(f"  [{status}] {path}: {done}/{len(pairs)}")
    return done, len(pairs)

# ============ config.js ============
patch('src/js/core/config.js', [
    (
        "timeframe: '60', // \u067e\u06cc\u0634\u200c\u0641\u0631\u0636 \u06f1 \u0633\u0627\u0639\u062a\u0647 \u0637\u0644\u0627\u06cc\u06cc (\u06f1h) \u0628\u0631\u0627\u06cc \u062d\u0630\u0641 \u0646\u0648\u06cc\u0632\u0647\u0627",
        "timeframe: '15', // FIX: \u067e\u06cc\u0634\u200c\u0641\u0631\u0636 \u06f1\u06f5 \u062f\u0642\u06cc\u0642\u0647"
    ),
    (
        """  medium: Object.freeze({
    minScore: 72,
    minMovePct: 0.18,
    volumeSpikeX: 1.65,
    atrStopMult: 1.25,
    takeProfitR: 1.35,
    cooldownSec: 150,
    maxHoldMinutes: 20,
    orderMargin: 40,
    leverage: 5,
    dailyLossLimitPct: 3,
    maxOpenPositions: 3
  }),""",
        """  medium: Object.freeze({
    minScore: 82,
    minMovePct: 0.35,
    volumeSpikeX: 2.2,
    atrStopMult: 2.0,
    takeProfitR: 1.8,
    cooldownSec: 300,
    maxHoldMinutes: 60,
    orderMargin: 40,
    leverage: 5,
    dailyLossLimitPct: 3,
    maxOpenPositions: 3
  }),"""
    ),
    (
        """  high: Object.freeze({
    minScore: 65,
    minMovePct: 0.12,
    volumeSpikeX: 1.35,
    atrStopMult: 1.0,
    takeProfitR: 1.1,
    cooldownSec: 60,
    maxHoldMinutes: 30,
    orderMargin: 80,
    leverage: 10,
    dailyLossLimitPct: 5,
    maxOpenPositions: 5
  })""",
        """  high: Object.freeze({
    minScore: 75,
    minMovePct: 0.25,
    volumeSpikeX: 1.8,
    atrStopMult: 1.6,
    takeProfitR: 1.5,
    cooldownSec: 180,
    maxHoldMinutes: 45,
    orderMargin: 60,
    leverage: 7,
    dailyLossLimitPct: 4,
    maxOpenPositions: 4
  })"""
    ),
])

# ============ settings-store.js ============
patch('src/js/services/settings-store.js', [
    (
        """  constructor() {
    this.value = { ...clone(DEFAULT_SETTINGS), ...readJson(STORAGE_KEYS.settings, {}) };
  }""",
        """  constructor() {
    this.value = { ...clone(DEFAULT_SETTINGS), ...readJson(STORAGE_KEYS.settings, {}) };
    // FIX: force-migrate timeframe if stored as 1m by buggy agent
    const tf = Number(this.value.timeframe);
    if (!this.value.timeframe || tf < 5) {
      this.value.timeframe = '15';
      writeJson(STORAGE_KEYS.settings, this.value);
      console.log('[SettingsStore] FIX migrated timeframe -> 15m (was ' + tf + 'm)');
    }
  }"""
    ),
])

# ============ strategy.js ============
patch('src/js/services/strategy.js', [
    # 1. Weak-volume penalty
    (
        """    if (volumeX >= Number(s.volumeSpikeX)) {
      longScore += 22;
      shortScore += 22;
      reasons.push(`\u062d\u062c\u0645 ${volumeX.toFixed(2)}x`);
    }""",
        """    if (volumeX >= Number(s.volumeSpikeX)) {
      longScore += 22;
      shortScore += 22;
      reasons.push(`\u062d\u062c\u0645 ${volumeX.toFixed(2)}x`);
    }
    // FIX: penalty for weak volume (was emitting score=100 on volX=0.15)
    if (volumeX < 0.8) {
      longScore -= 40;
      shortScore -= 40;
      reasons.push(`\u062d\u062c\u0645 \u0628\u0633\u06cc\u0627\u0631 \u0636\u0639\u06cc\u0641 (${volumeX.toFixed(2)}x)`);
    } else if (volumeX < Number(s.volumeSpikeX) * 0.8) {
      longScore -= 18;
      shortScore -= 18;
      reasons.push(`\u062d\u062c\u0645 \u0632\u06cc\u0631 \u0622\u0633\u062a\u0627\u0646\u0647 (${volumeX.toFixed(2)}x)`);
    }"""
    ),
    # 2. Wider min stop + full audit snapshot
    (
        """    const stopDistance = Math.max(atr * Number(s.atrStopMult), price * 0.0015);
    const entry = price * (1 + direction * (Number(s.slippagePct) / 100));
    const stop = direction ? entry - direction * stopDistance : null;
    const take = direction ? entry + direction * stopDistance * Number(s.takeProfitR) : null;
    const notional = Number(s.orderMargin) * Number(s.leverage);
    const qty = notional / (entry || price);
    const feeOpen = this.fee(notional, s.feeOpenPct);
    const feeClose = this.fee(notional, s.feeClosePct);
    const roundTripFee = feeOpen + feeClose;
    const risk = stopDistance * qty + roundTripFee;
    const reward = stopDistance * Number(s.takeProfitR) * qty - roundTripFee;
    const candleTs = Number(last.ts || 0);

    return {
      symbol: market.symbol,
      source: market.source,
      price,
      side,""",
        """    const stopDistance = Math.max(atr * Number(s.atrStopMult), price * 0.004);
    const entry = price * (1 + direction * (Number(s.slippagePct) / 100));
    const stop = direction ? entry - direction * stopDistance : null;
    const take = direction ? entry + direction * stopDistance * Number(s.takeProfitR) : null;
    const notional = Number(s.orderMargin) * Number(s.leverage);
    const qty = notional / (entry || price);
    const feeOpen = this.fee(notional, s.feeOpenPct);
    const feeClose = this.fee(notional, s.feeClosePct);
    const roundTripFee = feeOpen + feeClose;
    const risk = stopDistance * qty + roundTripFee;
    const reward = stopDistance * Number(s.takeProfitR) * qty - roundTripFee;
    const candleTs = Number(last.ts || 0);

    // FIX: full market snapshot captured at signal time for post-mortem analysis
    const auditSnapshot = {
      ts: Date.now(),
      isoTime: new Date().toISOString(),
      symbol: market.symbol,
      source: market.source,
      side,
      score,
      price,
      lastCandle: last ? { ts: last.ts, open: last.open, high: last.high, low: last.low, close: last.close, volume: last.volume } : null,
      previousCandle: previous ? { ts: previous.ts, open: previous.open, high: previous.high, low: previous.low, close: previous.close, volume: previous.volume } : null,
      indicators: {
        movePct, oneCandlePct, volX: volumeX,
        atr, atrPct, rsi: rsiVal, emaFast, emaSlow,
        averageVolume, bodyPct,
        breakoutUp, breakoutDown, trendUp, trendDown,
        rangeHigh: rangeHighs.length ? Math.max(...rangeHighs) : null,
        rangeLow: rangeLows.length ? Math.min(...rangeLows) : null
      },
      scoring: { longScore, shortScore, reasons: [...reasons] },
      plan: {
        entry, stop, take, qty, notional,
        feeOpen, feeClose, fee: roundTripFee, risk, reward,
        riskRewardRatio: risk > 0 ? reward / risk : null
      },
      settingsSnapshot: {
        timeframe: s.timeframe, riskProfile: s.riskProfile,
        minScore: s.minScore, minMovePct: s.minMovePct,
        volumeSpikeX: s.volumeSpikeX, atrStopMult: s.atrStopMult,
        takeProfitR: s.takeProfitR, orderMargin: s.orderMargin, leverage: s.leverage
      }
    };

    return {
      symbol: market.symbol,
      source: market.source,
      price,
      side,
      auditSnapshot,"""
    ),
])

# ============ paper-broker.js ============
patch('src/js/services/paper-broker.js', [
    # 1. Round-trip fee for trail
    (
        """      const gross = this.grossPnl(position, mark);
      const isInProfit = gross > (Number(position.openFee || 0) * 1.5);""",
        """      const gross = this.grossPnl(position, mark);
      // FIX: use round-trip fee, not just 1.5x open fee
      const roundTripFee = Number(position.openFee || 0) + this.closeFee(position, mark);
      const isInProfit = gross > roundTripFee * 2.5;"""
    ),
    # 2. Snapshot on open
    (
        """      signalId: signal.signalId,
      source: signal.source,
      candleTs: signal.candleTs
    });""",
        """      signalId: signal.signalId,
      source: signal.source,
      candleTs: signal.candleTs,
      auditSnapshot: signal.auditSnapshot || null
    });"""
    ),
    # 3. Snapshot on close
    (
        """      riskProfile: position.riskProfile || this.s.value.riskProfile || 'legacy',
      source: position.source,
      durationSec: Math.max(0, Math.round((Date.now() - Number(position.openedAt)) / 1000))
    });""",
        """      riskProfile: position.riskProfile || this.s.value.riskProfile || 'legacy',
      source: position.source,
      durationSec: Math.max(0, Math.round((Date.now() - Number(position.openedAt)) / 1000)),
      auditSnapshot: position.auditSnapshot || null,
      entrySnapshot: {
        entry: position.entry,
        stopInitial: position.stop,
        take: position.take,
        score: position.score,
        openedAt: position.openedAt,
        highWater: position.highWater,
        lowWater: position.lowWater
      }
    });"""
    ),
])
PYEOF

echo ""
echo "========== VERIFICATION =========="

check() {
  if grep -q "$2" "$1" 2>/dev/null; then
    echo "  [OK]  $3"
  else
    echo "  [!!]  $3  (FAILED)"
  fi
}
check "src/js/core/config.js"             "timeframe: '15'"           "config.js: timeframe=15"
check "src/js/core/config.js"             "minScore: 82"              "config.js: medium profile"
check "src/js/services/settings-store.js" "FIX migrated timeframe"    "settings-store.js: force migrate"
check "src/js/services/strategy.js"       "حجم بسیار ضعیف"            "strategy.js: weak-volume penalty"
check "src/js/services/strategy.js"       "price \* 0.004"            "strategy.js: min stop 0.4%"
check "src/js/services/strategy.js"       "auditSnapshot"             "strategy.js: audit snapshot"
check "src/js/services/paper-broker.js"   "roundTripFee"              "paper-broker.js: fee fix"
check "src/js/services/paper-broker.js"   "auditSnapshot"             "paper-broker.js: entry snapshot"

echo ""
echo "========== SYNTAX CHECK =========="
if command -v npm >/dev/null 2>&1; then
  npm run check 2>&1 | tail -8 || echo "[!!] npm run check failed"
else
  echo "  (npm not installed, skipped)"
fi

echo ""
echo "=========================================="
echo "Done. Next steps:"
echo "  1. Clear browser cache:"
echo "     Open http://localhost:8787 -> F12 Console ->"
echo "     localStorage.clear(); location.reload()"
echo "  2. Settings tab -> verify timeframe = 15"
echo "  3. Let it scan for 1-2 hours, then export JSON"
echo "=========================================="
