#!/data/data/com.termux/files/usr/bin/bash
echo "=============================================="
echo "  Futures Scalp Lab — Patch 5-Bugs v1"
echo "=============================================="
echo ""

if [ ! -f "src/js/core/config.js" ]; then
  echo "[!!] Run inside ~/futures-pwa"
  exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "[!!] pkg install python -y"
  exit 1
fi

BACKUP="backup_5bugs_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP/src/js/services" "$BACKUP/src/js"
for f in src/js/services/strategy.js src/js/services/paper-broker.js src/js/app.js; do
  [ -f "$f" ] && cp "$f" "$BACKUP/$f"
done
echo "[OK] Backup -> $BACKUP"
echo ""

python3 << 'PYEOF'
import os

def readf(p):
    with open(p, 'r', encoding='utf-8') as f: return f.read()

def writef(p, s):
    with open(p, 'w', encoding='utf-8') as f: f.write(s)

def apply_patch(name, path, marker, old, new):
    if not os.path.exists(path):
        print(f"  [!] MISSING: {path}"); return False
    src = readf(path)
    if marker in src:
        print(f"  [-] {name}: already patched")
        return True
    if old not in src:
        print(f"  [!] {name}: ANCHOR NOT FOUND")
        return False
    src = src.replace(old, new, 1)
    writef(path, src)
    print(f"  [OK] {name}")
    return True

# ================================================================
# FIX 1 + 3: strategy.js — چک کیفیت داده + جریمه RSI اشباع
# ================================================================
print("\n=== strategy.js ===")

# FIX 1: افزودن متد checkDataQuality + فراخوانی در ابتدای analyze
apply_patch(
    "FIX 1: data quality check",
    "src/js/services/strategy.js",
    "FIX_DATA_QUALITY",
    """  analyze(market) {
    const s = this.s.value;
    const candles = market.candles;
    const last = candles.at(-1);""",
    """  checkDataQuality(market, settings) {
    const candles = market.candles || [];
    const tfMs = Math.max(1, Number(settings.timeframe) || 15) * 60 * 1000;

    // FIX_DATA_QUALITY: 3 لایه اعتبارسنجی

    // لایه ۱: تعداد کندل کافی (حداقل ۵۰ کندل بسته برای RSI/EMA/ATR)
    if (candles.length < 50) {
      return { ok: false, reason: `کندل ناکافی (${candles.length}/50)` };
    }

    // لایه ۲: ترتیب + پیوستگی زمانی (هر فاصله باید == تایم‌فریم باشه)
    const sorted = [...candles].sort((a, b) => a.ts - b.ts);
    const maxGap = tfMs * 1.5;
    for (let i = 1; i < sorted.length; i++) {
      const gap = sorted[i].ts - sorted[i - 1].ts;
      if (gap <= 0) {
        return { ok: false, reason: `ترتیب زمانی کندل‌ها معیوب` };
      }
      if (gap > maxGap) {
        const gapMin = Math.round(gap / 60000);
        return { ok: false, reason: `Gap در کندل‌ها (${gapMin} دقیقه)` };
      }
    }

    // لایه ۳: تازگی آخرین کندل (نباید بیشتر از ۳ برابر تایم‌فریم کهنه باشه)
    const lastTs = sorted[sorted.length - 1].ts;
    const age = Date.now() - lastTs;
    if (age > tfMs * 3) {
      const ageMin = Math.round(age / 60000);
      return { ok: false, reason: `داده کهنه (${ageMin} دقیقه)` };
    }

    return { ok: true };
  }

  analyze(market) {
    const s = this.s.value;
    const candles = market.candles;

    // FIX_DATA_QUALITY: قبل از هر تحلیلی، داده رو اعتبارسنجی کن
    const dq = this.checkDataQuality(market, s);
    if (!dq.ok) {
      return this.waitSignal(market, `داده نامعتبر: ${dq.reason}`);
    }

    const last = candles.at(-1);"""
)

# FIX 3: جریمه سنگین RSI اشباع
apply_patch(
    "FIX 3: RSI extreme penalty",
    "src/js/services/strategy.js",
    "FIX_RSI_EXTREME",
    """    if (rsiVal < 35) {
      longScore += 15;
      reasons.push(`RSI کف (${rsiVal.toFixed(0)})`);
    } else if (rsiVal > 65) {
      shortScore += 15;
      reasons.push(`RSI سقف (${rsiVal.toFixed(0)})`);
    }""",
    """    if (rsiVal < 35) {
      longScore += 15;
      reasons.push(`RSI کف (${rsiVal.toFixed(0)})`);
    } else if (rsiVal > 65) {
      shortScore += 15;
      reasons.push(`RSI سقف (${rsiVal.toFixed(0)})`);
    }

    // FIX_RSI_EXTREME: جلوگیری از شورت در اشباع فروش، و لانگ در اشباع خرید
    // منطق: در RSI<25 بازار overextended به سمت پایین، شورت گرفتن = تعقیب کف
    if (rsiVal < 25) {
      shortScore -= 50;
      reasons.push(`RSI اشباع فروش ${rsiVal.toFixed(0)} — شورت جریمه`);
    }
    if (rsiVal > 75) {
      longScore -= 50;
      reasons.push(`RSI اشباع خرید ${rsiVal.toFixed(0)} — لانگ جریمه`);
    }"""
)

# ================================================================
# FIX 2: app.js — چک پیوستگی اسکن
# ================================================================
print("\n=== app.js ===")

apply_patch(
    "FIX 2a: lastScanAt field",
    "src/js/app.js",
    "this.lastScanAt",
    """    this.timer = null;
    this.scanInFlight = false;""",
    """    this.timer = null;
    this.scanInFlight = false;
    this.lastScanAt = 0; // FIX_SCAN_GAP"""
)

apply_patch(
    "FIX 2b: scan gap check",
    "src/js/app.js",
    "FIX_SCAN_GAP",
    """  async scan() {
    if (this.scanInFlight) return;
    this.scanInFlight = true;
    this.paper.migrateDay();""",
    """  async scan() {
    if (this.scanInFlight) return;

    // FIX_SCAN_GAP: اگه بین دو اسکن gap بزرگی افتاد، این اسکن رو نادیده بگیر
    // (چون در فاصله gap، دیتا از دست رفته و تحلیل ناقص می‌شه)
    const now = Date.now();
    const expectedInterval = Math.max(3, Number(this.settings.value.scanIntervalSec) || 5) * 1000;
    const maxAllowed = expectedInterval * 2.5;
    if (this.lastScanAt > 0 && (now - this.lastScanAt) > maxAllowed) {
      this.logger.info('SCAN GAP SKIPPED', { gapMs: now - this.lastScanAt, expected: expectedInterval });
      this.lastScanAt = now;
      return;
    }
    this.lastScanAt = now;

    this.scanInFlight = true;
    this.paper.migrateDay();"""
)

# ================================================================
# FIX 4 + 5: paper-broker.js — dedup + same-dir loss
# ================================================================
print("\n=== paper-broker.js ===")

# FIX 4: logSignal dedup
apply_patch(
    "FIX 4: signal dedup",
    "src/js/services/paper-broker.js",
    "FIX_DEDUP",
    """  logSignal(signal) {
    if (!signal) return;
    if (!Array.isArray(this.state.signalLedger)) this.state.signalLedger = [];
    this.state.signalLedger.unshift({
      ts: Date.now(),
      isoTime: new Date().toISOString(),
      symbol: signal.symbol,
      side: signal.side,
      score: signal.score,
      price: signal.price,
      source: signal.source,""",
    """  logSignal(signal) {
    if (!signal) return;
    if (!Array.isArray(this.state.signalLedger)) this.state.signalLedger = [];

    // FIX_DEDUP: اگه آخرین سیگنال همین نماد + جهت + کندل بود، ثبت نکن
    const last = this.state.signalLedger[0];
    if (last
        && last.symbol === signal.symbol
        && last.side === signal.side
        && last.candleTs === signal.candleTs) {
      return;
    }

    this.state.signalLedger.unshift({
      ts: Date.now(),
      isoTime: new Date().toISOString(),
      symbol: signal.symbol,
      side: signal.side,
      score: signal.score,
      price: signal.price,
      candleTs: signal.candleTs,
      source: signal.source,"""
)

# FIX 5: same-direction loss filter
apply_patch(
    "FIX 5: same-dir loss skip",
    "src/js/services/paper-broker.js",
    "FIX_SAME_DIR_LOSS",
    """  open(signal, reason = 'auto', force = false) {
    if (!signal || signal.side === 'WAIT') return false;
    // Manual entry may bypass cooldown, never the account-level safety checks.
    if (this.dailyLossExceeded()) return false;""",
    """  open(signal, reason = 'auto', force = false) {
    if (!signal || signal.side === 'WAIT') return false;

    // FIX_SAME_DIR_LOSS: اگه پوزیشن باز هم‌جهت در ضرر داریم، این سیگنال رو رد کن
    if (!force) {
      const sameDir = this.state.paperPositions.filter(p => p.side === signal.side);
      const mark = Number(signal.price);
      if (sameDir.length > 0 && Number.isFinite(mark) && mark > 0) {
        const hasLosing = sameDir.some(p => this.netPnl(p, mark) < 0);
        if (hasLosing) {
          this.log.info('SKIP_SIGNAL_SAME_DIR_LOSS', { symbol: signal.symbol, side: signal.side });
          return false;
        }
      }
    }

    // Manual entry may bypass cooldown, never the account-level safety checks.
    if (this.dailyLossExceeded()) return false;"""
)

print("\n✅ Patcher done.")
PYEOF

echo ""
echo "══════════ VERIFICATION ══════════"
check() {
  if grep -q "$2" "$1" 2>/dev/null; then echo "  [OK] $3"; else echo "  [!!] $3"; fi
}
check "src/js/services/strategy.js"     "FIX_DATA_QUALITY"     "strategy: data quality"
check "src/js/services/strategy.js"     "FIX_RSI_EXTREME"      "strategy: RSI penalty"
check "src/js/app.js"                   "FIX_SCAN_GAP"         "app: scan gap"
check "src/js/app.js"                   "this.lastScanAt"      "app: lastScanAt field"
check "src/js/services/paper-broker.js" "FIX_DEDUP"            "broker: signal dedup"
check "src/js/services/paper-broker.js" "FIX_SAME_DIR_LOSS"    "broker: same-dir loss"

echo ""
echo "══════════ SYNTAX CHECK ══════════"
npm run check 2>&1 | tail -5

echo ""
echo "══════════ READY ══════════"
echo "Next:"
echo "  1. npm start"
echo "  2. In Settings adjust:"
echo "     - minScore = 70"
echo "     - cooldownSec = 300"
echo "     - scanIntervalSec = 10"
echo "  3. Let it run 2 hours, then export Ledger"
