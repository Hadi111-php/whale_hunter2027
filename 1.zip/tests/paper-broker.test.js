import test from 'node:test';
import assert from 'node:assert/strict';
import { PaperBroker } from '../src/js/services/paper-broker.js';

const values = {
  paperInitialEquity: 1000, feeOpenPct: 0, feeClosePct: 0, dailyLossLimitPct: 10,
  maxOpenPositions: 3, cooldownSec: 0, riskProfile: 'medium', maxHoldMinutes: 60
};
const settings = { value: values };
const logger = { info() {} };
const signal = (overrides = {}) => ({
  symbol: 'BTCUSDT', side: 'LONG', entry: 100, qty: 1, notional: 100,
  stop: 95, take: 110, score: 90, signalId: 'test-signal', source: 'BYBIT LIVE', candleTs: Date.now(), ...overrides
});

test('paper position closes at take profit', () => {
  const broker = new PaperBroker(settings, logger);
  broker.reset();
  broker.open(signal(), 'test', true);
  broker.updateStops(new Map([['BTCUSDT', { price: 111, lastCandle: { high: 112, low: 90 } }]]), new Map());
  assert.equal(broker.state.paperPositions.length, 0);
  assert.equal(broker.state.paperTrades[0].reason, 'TAKE_PROFIT');
  assert.equal(broker.state.paperTrades[0].exit, 110);
});

test('current candle low from before entry does not trigger stop by itself', () => {
  const broker = new PaperBroker(settings, logger);
  broker.reset();
  broker.open(signal(), 'test', true);
  broker.updateStops(new Map([['BTCUSDT', { price: 100, lastCandle: { high: 105, low: 80 } }]]), new Map());
  assert.equal(broker.state.paperPositions.length, 1);
  assert.equal(broker.state.paperTrades.length, 0);
});

test('paper position closes when maximum hold time expires', () => {
  const broker = new PaperBroker(settings, logger);
  broker.reset();
  broker.open(signal({ openedAt: Date.now() - 61 * 60_000 }), 'test', true);
  const position = broker.state.paperPositions[0];
  position.openedAt = Date.now() - 61 * 60_000;
  broker.updateStops(new Map([['BTCUSDT', { price: 101, lastCandle: {} }]]), new Map());
  assert.equal(broker.state.paperPositions.length, 0);
  assert.equal(broker.state.paperTrades[0].reason, 'MAX_HOLD_TIME');
});
