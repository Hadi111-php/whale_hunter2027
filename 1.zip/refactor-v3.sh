#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  Futures Scalp Lab — Modular v3
#  1) Disable maxHoldTime (trailing handles exit)
#  2) Extract shared MarketFeed (modular data layer)
#  3) Expose window.__marketFeed for external consumers
#  4) Example: pump-dump integration template
# ============================================================

set -e
echo "=================================================="
echo "  Modular Refactor  v3"
echo "=================================================="
echo ""

if [ ! -f "src/js/core/config.js" ] || [ ! -f "src/js/app.js" ]; then
  echo "[!!] Run inside project root (~/futures-pwa)"
  echo "     Current dir: $(pwd)"
  exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "[!!] Install python first: pkg install python -y"
  exit 1
fi

BACKUP="backup_v3_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP/src/js/core" "$BACKUP/src/js/services" "$BACKUP/examples"
for f in src/js/core/config.js src/js/app.js src/js/services/paper-broker.js; do
  [ -f "$f" ] && cp "$f" "$BACKUP/$f"
done
echo "[OK] Backup -> $BACKUP"
echo ""

python3 << 'PYEOF'
# -*- coding: utf-8 -*-
import os, io

def readf(p):
    with io.open(p, 'r', encoding='utf-8') as f: return f.read()

def writef(p, s):
    d = os.path.dirname(p)
    if d and not os.path.exists(d): os.makedirs(d)
    with io.open(p, 'w', encoding='utf-8') as f: f.write(s)

def replace_once(name, path, old, new):
    if not os.path.exists(path):
        print("  [!] MISSING: %s" % path); return False
    src = readf(path)
    if old not in src:
        print("  [!] %s: anchor not found" % name); return False
    src = src.replace(old, new, 1)
    writef(path, src)
    print("  [OK] %s" % name)
    return True

# =========================================================
# 1) config.js — maxHoldMinutes = 0 (disabled by default)
# =========================================================
print("\n=== config.js ===")
replace_once(
    "disable maxHoldMinutes",
    "src/js/core/config.js",
    "  maxHoldMinutes: 120,",
    "  maxHoldMinutes: 0,   // FIX v3: 0 = no time cap, trailing handles exit"
)

# =========================================================
# 2) CREATE src/js/core/market-feed.js (shared feed)
# =========================================================
print("\n=== market-feed.js (NEW) ===")

feed_src = u"""// src/js/core/market-feed.js
// ============================================================
//  MarketFeed — shared, singleton-friendly market data provider
// ============================================================
//  - Fetches each symbol ONCE per tick
//  - Pushes updates to all subscribers atomically
//  - External consumers (pump-dump, alerting, ...) subscribe to
//    window.__marketFeed instead of doing their own network calls
// ============================================================
import { MarketClient } from '../services/market-client.js';

export class MarketFeed {
  constructor(settings, logger) {
    this.s = settings;
    this.log = logger;
    this.market = new MarketClient(settings, logger);
    this.data = new Map();           // symbol -> market object
    this.errors = new Map();         // symbol -> error message
    this.subscribers = new Set();
    this.timer = null;
    this.inFlight = false;
    this.lastUpdateAt = 0;
    this.tickCount = 0;
  }

  // ---------- Subscription ----------
  subscribe(fn) {
    if (typeof fn !== 'function') return () => {};
    this.subscribers.add(fn);
    // Fire immediately if we already have data
    if (this.data.size > 0) {
      try { fn(this.snapshot()); }
      catch (e) { this.log.info('FEED_SUB_ERR', { err: e.message }); }
    }
    return () => this.subscribers.delete(fn);
  }

  snapshot() {
    return {
      data: new Map(this.data),
      errors: new Map(this.errors),
      at: this.lastUpdateAt,
      tick: this.tickCount,
    };
  }

  notify() {
    const payload = this.snapshot();
    for (const fn of this.subscribers) {
      try { fn(payload); }
      catch (e) { this.log.info('FEED_SUB_ERR', { err: e.message }); }
    }
  }

  // ---------- Accessors ----------
  get(symbol)      { return this.data.get(symbol) || null; }
  getPrice(sym)    { const m = this.data.get(sym); return m ? Number(m.price) : null; }
  getSymbols()     { return [...this.data.keys()]; }
  getErrors()      { return new Map(this.errors); }
  isReady()        { return this.data.size > 0; }

  // ---------- Lifecycle ----------
  async tick() {
    if (this.inFlight) return;
    this.inFlight = true;
    const symbols = [...new Set(this.s.value.symbols)].filter(Boolean);

    try {
      const results = await Promise.allSettled(
        symbols.map(sym => this.market.get(sym))
      );

      const nextData = new Map();
      const nextErrors = new Map();
      let ok = 0;

      results.forEach((r, i) => {
        const sym = symbols[i];
        if (r.status === 'fulfilled') {
          nextData.set(sym, r.value);
          ok++;
        } else {
          nextErrors.set(sym, r.reason?.message || 'unknown');
        }
      });

      // Atomic swap — subscribers always see a consistent snapshot
      this.data = nextData;
      this.errors = nextErrors;
      this.lastUpdateAt = Date.now();
      this.tickCount++;

      this.log.info('FEED_TICK', { ok, total: symbols.length, tick: this.tickCount });
      this.notify();
      return { ok, total: symbols.length };
    } finally {
      this.inFlight = false;
    }
  }

  start() {
    this.stop();
    const sec = Math.max(3, Number(this.s.value.scanIntervalSec) || 5);
    this.timer = setInterval(() => { this.tick().catch(() => {}); }, sec * 1000);
    this.log.info('FEED_START', { interval: sec });
    return this.tick();
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  destroy() {
    this.stop();
    this.subscribers.clear();
  }
}
"""
writef("src/js/core/market-feed.js", feed_src)
print("  [OK] created src/js/core/market-feed.js")

# =========================================================
# 3) REWRITE app.js — consume feed, no direct fetch
# =========================================================
print("\n=== app.js (rewritten) ===")

app_src = u"""import { $ } from './core/utils.js';
import { SettingsStore } from './services/settings-store.js';
import { Logger } from './services/logger.js';
import { MarketFeed } from './core/market-feed.js';
import { MomentumScalpStrategy } from './services/strategy.js';
import { PaperBroker } from './services/paper-broker.js';
import { RealBroker } from './services/real-broker.js';
import { PerformanceReport } from './services/performance-report.js';
import { DashboardView } from './ui/view.js';

export class ScalpLabApp {
  constructor() {
    this.settings = new SettingsStore();
    this.logger = new Logger();
    this.signals = new Map();
    this.prices = new Map();
    this.marketData = new Map();
    this.dataErrors = new Map();
    this.lastErrorLog = new Map();
    this.performance = new PerformanceReport();

    this.rebuildServices();

    // ---- Shared market feed (single source of truth) ----
    this.feed = new MarketFeed(this.settings, this.logger);
    try { window.__marketFeed = this.feed; } catch (e) { /* SSR safe */ }
    this.feedUnsub = this.feed.subscribe(payload => this.onFeed(payload));

    this.view = new DashboardView(this);
  }

  rebuildServices() {
    this.strategy = new MomentumScalpStrategy(this.settings);
    this.paper = this.paper || new PaperBroker(this.settings, this.logger);
    // Never silently preserve real-order permission across a settings change
    if (this.real?.enabled) this.real.kill();
    this.real = new RealBroker(this.settings, this.paper, this.logger);
    if (typeof document !== 'undefined' && $('#realAutoToggle')) {
      $('#realAutoToggle').checked = false;
    }
  }

  modeLabel() {
    const mode = this.settings.value.dataMode;
    if (mode === 'mock-local') return 'MOCK LOCAL';
    if (mode === 'mock-server') return 'MOCK SERVER';
    return 'BYBIT LIVE';
  }

  // Manual refresh button -> one immediate tick
  async scan() { return this.feed.tick(); }

  // Called by MarketFeed on every successful tick
  onFeed({ data, errors, at }) {
    const symbols = [...new Set(this.settings.value.symbols)].filter(Boolean);
    this.marketData = data;
    this.dataErrors = errors;

    this.signals.clear();
    this.prices.clear();
    this.paper.migrateDay();

    let ok = 0;
    for (const symbol of symbols) {
      const market = data.get(symbol);
      if (!market) {
        const err = errors.get(symbol) || 'NO DATA';
        if (this.lastErrorLog.get(symbol) !== err) {
          this.logger.info('DATA ERROR', { symbol, error: err });
          this.lastErrorLog.set(symbol, err);
        }
        continue;
      }
      ok++;
      this.lastErrorLog.delete(symbol);

      const signal = this.strategy.analyze(market);
      this.signals.set(symbol, signal);
      this.prices.set(symbol, market.price);
      try { this.paper.logSignal(signal); } catch (e) { /* silent */ }
    }

    // ---- Exit engine FIRST (protects open positions) ----
    this.paper.updateStops(this.marketData, this.signals);
    try { this.paper.recordPostExit(this.marketData); } catch (e) { /* silent */ }

    // ---- Then entries ----
    const paperToggle = $('#paperAutoToggle');
    const paperEnabled = !!paperToggle?.checked || this.real.enabled;
    for (const signal of this.signals.values()) {
      if (paperEnabled && signal.side !== 'WAIT') this.paper.open(signal, 'auto');
    }

    // Real broker (fire-and-forget; gate inside RealBroker)
    if (this.real.enabled) {
      for (const signal of this.signals.values()) {
        if (signal.side !== 'WAIT' && signal.score >= Number(this.settings.value.minScore)) {
          this.real.send(signal).catch(() => {});
        }
      }
    }

    const update = new Date().toLocaleTimeString();
    const statusEl = $('#statusText');
    const lastEl = $('#lastUpdate');
    if (lastEl) lastEl.textContent = `آخرین اسکن: ${update} • ${ok}/${symbols.length}`;
    if (statusEl) {
      statusEl.textContent = ok > 0
        ? `${this.modeLabel()} • ${ok}/${symbols.length} بازار • ${this.settings.value.timeframe}m`
        : 'دیتای بازار در دسترس نیست؛ هیچ fallback ساختگی استفاده نشد';
    }

    this.view.renderAll();
  }

  applyRiskProfile(profile) {
    this.settings.applyRiskProfile(profile);
    this.rebuildServices();
    this.view.renderSettings();
    this.schedule();
    this.logger.info('RISK PROFILE APPLIED', { profile: this.settings.value.riskProfile });
    this.view.renderAll();
    void this.scan();
  }

  schedule() {
    if ($('#autoScanToggle')?.checked) this.feed.start();
    else this.feed.stop();
  }

  closeAllPaper() {
    for (const position of [...this.paper.state.paperPositions]) {
      this.paper.close(position, this.prices.get(position.symbol) || position.entry, 'close-all');
    }
    this.view.renderAll();
  }

  resetPaper() {
    this.paper.reset();
    this.view.renderAll();
  }

  async start() {
    this.view.bind();
    this.view.renderSettings();
    this.view.renderAll();
    this.schedule();
    this.logger.info('APP START', {
      mode: this.modeLabel(),
      paperDefault: this.settings.value.paperAutoDefault,
    });
    await this.scan().catch(error =>
      this.logger.info('INITIAL SCAN ERROR', { error: error.message })
    );
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js').catch(() => {});
    }
  }
}
"""
writef("src/js/app.js", app_src)
print("  [OK] rewrote src/js/app.js")

# =========================================================
# 4) CREATE examples/pump-dump-example.js (integration template)
# =========================================================
print("\n=== examples/pump-dump-example.js (NEW) ===")

example_src = u"""// examples/pump-dump-example.js
// ============================================================
//  EXAMPLE — How to hook into the shared MarketFeed
// ============================================================
//  The scalp app exposes its feed on window.__marketFeed.
//  Your pump-dump system can subscribe here WITHOUT fetching
//  market data on its own — zero extra network traffic.
//
//  To load:  <script type="module" src="examples/pump-dump-example.js"></script>
// ============================================================

(function attachPumpDump() {

  function bootstrap() {
    const feed = window.__marketFeed;
    if (!feed) {
      // scalp app hasn't booted yet — retry shortly
      setTimeout(bootstrap, 500);
      return;
    }

    // Local rolling window per symbol
    const HISTORY_LEN = 20;
    const history = new Map(); // symbol -> [ { ts, price, movePct, volX } ]

    const unsubscribe = feed.subscribe(({ data, errors, at }) => {
      for (const [symbol, market] of data) {
        const candles = market.candles || [];
        if (candles.length < 4) continue;

        const last = candles[candles.length - 1];
        const back4 = candles[candles.length - 4];
        const movePct = ((last.close - back4.close) / back4.close) * 100;

        const recentVols = candles.slice(-28, -1).map(c => c.volume);
        const avgVol = recentVols.length
          ? recentVols.reduce((a, b) => a + b, 0) / recentVols.length
          : last.volume;
        const volX = last.volume / (avgVol || last.volume || 1);

        const row = { ts: at, price: market.price, movePct, volX };

        if (!history.has(symbol)) history.set(symbol, []);
        const arr = history.get(symbol);
        arr.push(row);
        if (arr.length > HISTORY_LEN) arr.shift();

        // ---- Your pump/dump heuristic goes here ----
        if (movePct > 2.5 && volX > 2.5) {
          console.log(`[PUMP] ${symbol} ${movePct.toFixed(2)}% vol=${volX.toFixed(2)}x @ ${market.price}`);
          // TODO: trigger your pump-dump logic
        }
        if (movePct < -2.5 && volX > 2.5) {
          console.log(`[DUMP] ${symbol} ${movePct.toFixed(2)}% vol=${volX.toFixed(2)}x @ ${market.price}`);
          // TODO: trigger your dump logic
        }
      }
    });

    // Expose for debugging / cleanup
    window.__pumpDump = { unsubscribe, history };
    console.log('[pump-dump] subscribed to shared MarketFeed');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootstrap);
  } else {
    bootstrap();
  }
})();
"""
writef("examples/pump-dump-example.js", example_src)
print("  [OK] created examples/pump-dump-example.js")

print("\n[v] Patcher done.")
PYEOF

echo ""
echo "══════════ VERIFICATION ══════════"
check() {
  if grep -q "$2" "$1" 2>/dev/null; then
    echo "  [OK] $3"
  else
    echo "  [!!] $3"
  fi
}
check "src/js/core/config.js"             "maxHoldMinutes: 0"           "config: maxHold disabled"
check "src/js/core/market-feed.js"        "export class MarketFeed"     "feed: class exists"
check "src/js/core/market-feed.js"        "subscribe(fn)"               "feed: subscribe API"
check "src/js/core/market-feed.js"        "snapshot()"                  "feed: atomic snapshot"
check "src/js/app.js"                     "MarketFeed"                  "app: imports feed"
check "src/js/app.js"                     "window.__marketFeed"         "app: exposes feed globally"
check "src/js/app.js"                     "onFeed(payload)"             "app: subscribes to feed"
check "examples/pump-dump-example.js"     "feed.subscribe"              "example: subscribes to feed"

echo ""
echo "══════════ SYNTAX CHECK ══════════"
if command -v npm >/dev/null 2>&1; then
  npm run check 2>&1 | tail -8 || echo "  [!!] npm run check failed"
else
  echo "  (npm not installed)"
fi

echo ""
echo "══════════ API FOR YOUR PUMP-DUMP SYSTEM ══════════"
cat <<'API'

  In the browser console (or any module loaded on the same page):

    const feed = window.__marketFeed;

    // Latest snapshot
    feed.get('BTCUSDT')        // → full market object (candles, price, ...)
    feed.getPrice('BTCUSDT')   // → number
    feed.getSymbols()          // → ['BTCUSDT', 'ETHUSDT', ...]
    feed.isReady()             // → boolean

    // Live subscription (fires on every tick, ~5s)
    const unsub = feed.subscribe(({ data, errors, at, tick }) => {
      // data  : Map<symbol, market>
      // errors: Map<symbol, string>
      // at    : unix ms
      // tick  : counter
      for (const [symbol, market] of data) {
        // ... your logic
      }
    });

    // Later
    unsub();  // stop receiving updates

  ⚠️  Do NOT call fetch() or make your own HTTP calls for market data —
      the feed is already the single source of truth. Share it.

API

echo ""
echo "══════════ NEXT STEPS ══════════"
echo "  1. Restart server:  Ctrl+C  →  npm start"
echo "  2. Browser F12:"
echo "       localStorage.removeItem('scalp.lab.state.v3');"
echo "       caches.keys().then(k=>k.forEach(x=>caches.delete(x)));"
echo "       location.reload(true);"
echo "  3. In Settings tab → set maxHoldMinutes = 0"
echo "  4. (Optional) add this to index.html, just before </body>:"
echo "       <script type=\"module\" src=\"examples/pump-dump-example.js\"></script>"
echo ""
echo "  Test the feed from F12 console:"
echo "       __marketFeed.isReady()"
echo "       __marketFeed.getPrice('BTCUSDT')"
echo ""