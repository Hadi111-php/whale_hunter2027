#!/data/data/com.termux/files/usr/bin/bash
echo "=============================================="
echo "  Patch: Post-Exit Tracker + Filtered Export"
echo "=============================================="
echo ""

if [ ! -f "src/js/core/config.js" ]; then
  echo "[!!] Run inside ~/futures-pwa"
  exit 1
fi

BACKUP="backup_export_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP/src/js/services" "$BACKUP/src/js/ui"
for f in src/js/services/paper-broker.js src/js/app.js src/js/ui/view.js index.html; do
  [ -f "$f" ] && cp "$f" "$BACKUP/$f"
done
echo "[OK] Backup -> $BACKUP"
echo ""

python3 << 'PYEOF'
import os, re

def readf(p):
    with open(p, 'r', encoding='utf-8') as f: return f.read()

def writef(p, s):
    with open(p, 'w', encoding='utf-8') as f: f.write(s)

def apply(name, path, marker, old, new):
    if not os.path.exists(path):
        print(f"  [!] MISSING: {path}"); return
    src = readf(path)
    if marker in src:
        print(f"  [-] {name}: already patched")
        return
    if old not in src:
        print(f"  [!] {name}: ANCHOR NOT FOUND"); return
    src = src.replace(old, new, 1)
    writef(path, src)
    print(f"  [OK] {name}")

# ==========================================================
# 1) paper-broker.js — postExitTrackers in state
# ==========================================================
print("\n=== paper-broker.js ===")

apply(
    "state: postExitTrackers field",
    "src/js/services/paper-broker.js",
    "FIX_POST_EXIT_STATE",
    """      feesPaid: 0,
      day: new Date().toDateString(),
      dayStartEquity: equity
    };""",
    """      feesPaid: 0,
      day: new Date().toDateString(),
      dayStartEquity: equity,
      postExitTrackers: [] // FIX_POST_EXIT_STATE
    };"""
)

# ---------------------------------------------------------
# 2) paper-broker.js — create tracker on close()
# ---------------------------------------------------------
apply(
    "close(): tracker creation",
    "src/js/services/paper-broker.js",
    "FIX_POST_EXIT_CREATE",
    """    this.state.paperTrades = this.state.paperTrades.slice(0, 350);
    this.save();""",
    """    this.state.paperTrades = this.state.paperTrades.slice(0, 350);

    // FIX_POST_EXIT_CREATE: create tracker to monitor post-exit price
    if (!Array.isArray(this.state.postExitTrackers)) this.state.postExitTrackers = [];
    this.state.postExitTrackers.unshift({
      symbol: position.symbol,
      side: position.side,
      entry: Number(position.entry),
      exitPrice: exit,
      exitAt: Date.now(),
      reason,
      score: position.score,
      riskProfile: position.riskProfile || this.s.value.riskProfile || 'medium',
      checkpoints: []
    });
    this.state.postExitTrackers = this.state.postExitTrackers.slice(0, 500);

    this.save();"""
)

# ---------------------------------------------------------
# 3) paper-broker.js — new methods after updateStops
# ---------------------------------------------------------
apply(
    "methods: recordPostExit / exportFiltered / getPostExitStats",
    "src/js/services/paper-broker.js",
    "FIX_POST_EXIT_METHODS",
    """      if (exit !== null) this.close(position, exit, reason);
    }
  }
}""",
    """      if (exit !== null) this.close(position, exit, reason);
    }

    // FIX_POST_EXIT_METHODS: update trackers after exit
    this.recordPostExit(marketMap);
  }

  // FIX_POST_EXIT_METHODS
  recordPostExit(marketMap) {
    if (!Array.isArray(this.state.postExitTrackers)) return;
    const now = Date.now();
    const CHECKPOINTS = [5, 15, 60, 240]; // minutes
    let dirty = false;
    for (const tracker of this.state.postExitTrackers) {
      const market = marketMap && marketMap.get ? marketMap.get(tracker.symbol) : null;
      if (!market) continue;
      const price = Number(market.price);
      if (!Number.isFinite(price) || price <= 0) continue;
      const ageMin = (now - tracker.exitAt) / 60000;
      for (const cp of CHECKPOINTS) {
        if (ageMin < cp) continue;
        if (tracker.checkpoints.some(c => c.minutes === cp)) continue;
        const raw = (price - tracker.exitPrice) / tracker.exitPrice * 100;
        const missedPct = tracker.side === 'LONG' ? raw : -raw;
        tracker.checkpoints.push({
          minutes: cp,
          price: Number(price.toFixed(8)),
          rawPct: Number(raw.toFixed(4)),
          missedPct: Number(missedPct.toFixed(4)),
          favorableForHolding: missedPct > 0
        });
        dirty = true;
      }
    }
    if (dirty) this.save();
  }

  getPostExitStats(minutes = 15) {
    if (!Array.isArray(this.state.postExitTrackers)) return null;
    const relevant = [];
    for (const t of this.state.postExitTrackers) {
      const cp = (t.checkpoints || []).find(c => c.minutes === minutes);
      if (cp) relevant.push({ tracker: t, cp });
    }
    if (!relevant.length) return null;
    let premature = 0, good = 0, totalMissed = 0;
    for (const { cp } of relevant) {
      if (cp.favorableForHolding) premature++; else good++;
      totalMissed += cp.missedPct;
    }
    return {
      minutes,
      total: relevant.length,
      premature,
      good,
      prematurePct: (premature / relevant.length) * 100,
      avgMissedPct: totalMissed / relevant.length
    };
  }

  exportFiltered(filters = {}) {
    const { symbol, fromDate, toDate, limit, side, minScore } = filters || {};
    const fromTs = fromDate ? new Date(fromDate).getTime() : 0;
    const toTs = toDate ? new Date(toDate).getTime() + 86400000 : Infinity;
    const maxCount = Math.max(1, Number(limit) || 5000);
    const symUp = symbol ? String(symbol).toUpperCase() : null;

    const filterFn = (item) => {
      if (!item) return false;
      const itemTs = Number(item.time || item.ts || item.exitAt || 0);
      if (itemTs < fromTs || itemTs > toTs) return false;
      if (symUp && String(item.symbol || '').toUpperCase() !== symUp) return false;
      if (side && item.side !== side) return false;
      if (minScore && Number(item.score || 0) < Number(minScore)) return false;
      return true;
    };

    return {
      exportedAt: new Date().toISOString(),
      filters: { symbol: symUp || 'ALL', fromDate: fromDate || 'all', toDate: toDate || 'all', limit: maxCount, side: side || 'ALL' },
      summary: {
        tradesCount: (this.state.paperTrades || []).filter(filterFn).length,
        signalsCount: (this.state.signalLedger || []).filter(filterFn).length,
        trackersCount: (this.state.postExitTrackers || []).filter(filterFn).length
      },
      paperTrades: (this.state.paperTrades || []).filter(filterFn).slice(0, maxCount),
      signalLedger: (this.state.signalLedger || []).filter(filterFn).slice(0, maxCount),
      postExitTrackers: (this.state.postExitTrackers || []).filter(filterFn).slice(0, maxCount)
    };
  }
}"""
)

# ==========================================================
# 4) app.js — call recordPostExit on scan
# ==========================================================
print("\n=== app.js ===")

apply(
    "scan(): post-exit record",
    "src/js/app.js",
    "FIX_POST_EXIT_SCAN",
    """      this.paper.updateStops(this.marketData, this.signals);""",
    """      this.paper.updateStops(this.marketData, this.signals);

      // FIX_POST_EXIT_SCAN: keep trackers updated
      try { this.paper.recordPostExit(this.marketData); } catch (e) { /* silent */ }"""
)

PYEOF

# ==========================================================
# 5) view.js — patch (Python because of anchors in JS)
# ==========================================================
python3 << 'PYEOF'
import os

def readf(p):
    with open(p, 'r', encoding='utf-8') as f: return f.read()

def writef(p, s):
    with open(p, 'w', encoding='utf-8') as f: f.write(s)

def apply(name, path, marker, old, new):
    if not os.path.exists(path):
        print(f"  [!] MISSING: {path}"); return
    src = readf(path)
    if marker in src:
        print(f"  [-] {name}: already patched")
        return
    if old not in src:
        print(f"  [!] {name}: ANCHOR NOT FOUND"); return
    src = src.replace(old, new, 1)
    writef(path, src)
    print(f"  [OK] {name}")

print("\n=== view.js ===")

# Add export handlers + post-exit stats renderer
apply(
    "view: export handlers + postExitStats",
    "src/js/ui/view.js",
    "FIX_EXPORT_HANDLERS",
    """    $('#closeAllPaperBtn').onclick = () => this.app.closeAllPaper();""",
    """    // FIX_EXPORT_HANDLERS: filtered JSON/CSV export
    if ($('#exportJsonBtn')) {
      $('#exportJsonBtn').onclick = () => this.doExportFiltered('json');
    }
    if ($('#exportCsvBtn')) {
      $('#exportCsvBtn').onclick = () => this.doExportFiltered('csv');
    }

    $('#closeAllPaperBtn').onclick = () => this.app.closeAllPaper();"""
)

apply(
    "view: methods (renderPostExitStats, doExportFiltered, buildCsv)",
    "src/js/ui/view.js",
    "FIX_EXPORT_METHODS",
    """    this.renderTables();
    this.renderNetFishing();
  }
}""",
    """    this.renderTables();
    this.renderNetFishing();
    this.renderPostExitStats();
  }

  // FIX_EXPORT_METHODS
  renderPostExitStats() {
    const stats15 = this.app.paper.getPostExitStats(15);
    const el = $('#postExitStats');
    const missedEl = $('#postExitMissedPct');
    if (el) {
      if (stats15 && stats15.total > 0) {
        el.textContent = `${stats15.prematurePct.toFixed(0)}% (${stats15.premature}/${stats15.total})`;
        el.style.color = stats15.prematurePct > 50 ? '#ef4444' : '#10b981';
      } else { el.textContent = '--'; }
    }
    if (missedEl) {
      if (stats15 && stats15.total > 0) {
        missedEl.textContent = `${stats15.avgMissedPct.toFixed(3)}%`;
        missedEl.style.color = stats15.avgMissedPct > 0 ? '#ef4444' : '#10b981';
      } else { missedEl.textContent = '--'; }
    }
  }

  doExportFiltered(format) {
    const symbol = (prompt('نماد (خالی=همه ارزها):', '') || '').trim();
    const fromDate = (prompt('از تاریخ (YYYY-MM-DD، خالی=همه):', '') || '').trim();
    const toDate = (prompt('تا تاریخ (YYYY-MM-DD، خالی=همه):', '') || '').trim();
    const limitStr = (prompt('حداکثر تعداد رکورد (پیش‌فرض 500):', '500') || '500').trim();
    const side = (prompt('جهت (LONG/SHORT، خالی=همه):', '') || '').trim().toUpperCase();

    const data = this.app.paper.exportFiltered({
      symbol: symbol || undefined,
      fromDate: fromDate || undefined,
      toDate: toDate || undefined,
      limit: Number(limitStr) || 500,
      side: side || undefined
    });

    let content, mime, ext;
    if (format === 'json') {
      content = JSON.stringify(data, null, 2);
      mime = 'application/json';
      ext = 'json';
    } else {
      content = this.buildCsv(data);
      mime = 'text/csv';
      ext = 'csv';
    }
    const blob = new Blob([content], { type: mime });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    const symTag = symbol ? '_' + symbol : '';
    const dateTag = '_' + new Date().toISOString().slice(0,10);
    a.download = `scalp_export_${format}${symTag}${dateTag}.${ext}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    alert(`✅ فایل ${format.toUpperCase()} دانلود شد\\nمعاملات: ${data.summary.tradesCount}\\nسیگنال‌ها: ${data.summary.signalsCount}\\nپیگیری‌ها: ${data.summary.trackersCount}`);
  }

  flattenForCsv(obj, prefix = '') {
    const out = {};
    for (const [k, v] of Object.entries(obj || {})) {
      const key = prefix ? `${prefix}.${k}` : k;
      if (v === null || v === undefined) { out[key] = ''; continue; }
      if (Array.isArray(v)) { out[key] = JSON.stringify(v); continue; }
      if (typeof v === 'object') { Object.assign(out, this.flattenForCsv(v, key)); continue; }
      out[key] = v;
    }
    return out;
  }

  buildCsv(data) {
    const sections = [];
    const escape = v => {
      const s = String(v ?? '').replace(/"/g, '""');
      return /[",\\n\\r]/.test(s) ? `"${s}"` : s;
    };
    const toTable = (rows, label) => {
      if (!rows || !rows.length) return '';
      const flat = rows.map(r => this.flattenForCsv(r));
      const cols = [...new Set(flat.flatMap(f => Object.keys(f)))];
      const lines = [`# ${label}`, cols.join(',')];
      for (const f of flat) lines.push(cols.map(c => escape(f[c])).join(','));
      return lines.join('\\n');
    };
    sections.push(toTable(data.paperTrades, 'PAPER TRADES'));
    sections.push(toTable(data.signalLedger, 'SIGNAL LEDGER'));
    sections.push(toTable(data.postExitTrackers, 'POST-EXIT TRACKERS'));
    return sections.filter(Boolean).join('\\n\\n');
  }
}"""
)

# Stats: display post-exit numbers in renderStats
apply(
    "view: renderStats adds post-exit",
    "src/js/ui/view.js",
    "FIX_EXPORT_STATS",
    """    $('#reportHold').textContent = report.averageHoldSec === null ? '--' : `${Math.round(report.averageHoldSec)}s`;
    $('#dashReportWinRate').textContent = report.count ? `${report.winRate.toFixed(1)}%` : '--';""",
    """    $('#reportHold').textContent = report.averageHoldSec === null ? '--' : `${Math.round(report.averageHoldSec)}s`;

    // FIX_EXPORT_STATS: update post-exit stats
    this.renderPostExitStats();

    $('#dashReportWinRate').textContent = report.count ? `${report.winRate.toFixed(1)}%` : '--';"""
)

PYEOF

# ==========================================================
# 6) index.html — buttons + stats card
# ==========================================================
python3 << 'PYEOF'
import os
p = 'index.html'
if not os.path.exists(p):
    print("[!] index.html missing"); exit()
with open(p, 'r', encoding='utf-8') as f: src = f.read()
marker = 'FIX_EXPORT_UI'
if marker in src:
    print("  [-] index.html: already patched")
else:
    # add export buttons
    old_btns = '''          <button id="exportTradesJsonBtn" class="btn" style="background:#38bdf8; color:#040a13; font-weight:bold;">📥 دانلود / کپی JSON تاریخچه معاملات</button>'''
    new_btns = '''          <button id="exportTradesJsonBtn" class="btn" style="background:#38bdf8; color:#040a13; font-weight:bold;">📥 دانلود / کپی JSON تاریخچه معاملات</button>
          <!-- FIX_EXPORT_UI -->
          <button id="exportJsonBtn" class="btn" style="background:#8b5cf6; color:#fff; font-weight:bold;">📦 Export JSON (فیلتردار)</button>
          <button id="exportCsvBtn" class="btn" style="background:#f59e0b; color:#000; font-weight:bold;">📊 Export CSV (فیلتردار)</button>'''
    ok1 = old_btns in src
    if ok1:
        src = src.replace(old_btns, new_btns, 1)
        print("  [OK] index.html: export buttons")
    else:
        print("  [!] index.html: buttons anchor not found")

    # add stats cards
    old_stats = '''            <div><span>میانگین Hold</span><b id="reportHold">--</b></div>
          </div>'''
    new_stats = '''            <div><span>میانگین Hold</span><b id="reportHold">--</b></div>
            <div><span>خروج زودهنگام (15m)</span><b id="postExitStats">--</b></div>
            <div><span>میانگین سود از دست رفته %</span><b id="postExitMissedPct">--</b></div>
          </div>'''
    if old_stats in src:
        src = src.replace(old_stats, new_stats, 1)
        print("  [OK] index.html: post-exit stats cards")
    else:
        print("  [!] index.html: stats anchor not found")

    with open(p, 'w', encoding='utf-8') as f: f.write(src)
PYEOF

echo ""
echo "══════════ VERIFICATION ══════════"
check() {
  if grep -q "$2" "$1" 2>/dev/null; then echo "  [OK] $3"; else echo "  [!!] $3"; fi
}
check "src/js/services/paper-broker.js" "FIX_POST_EXIT_STATE"    "broker: state field"
check "src/js/services/paper-broker.js" "FIX_POST_EXIT_CREATE"   "broker: tracker on close"
check "src/js/services/paper-broker.js" "FIX_POST_EXIT_METHODS"  "broker: methods"
check "src/js/services/paper-broker.js" "getPostExitStats"       "broker: getPostExitStats"
check "src/js/services/paper-broker.js" "exportFiltered"         "broker: exportFiltered"
check "src/js/app.js"                   "FIX_POST_EXIT_SCAN"     "app: scan hook"
check "src/js/ui/view.js"               "FIX_EXPORT_HANDLERS"    "view: handlers"
check "src/js/ui/view.js"               "FIX_EXPORT_METHODS"     "view: methods"
check "src/js/ui/view.js"               "doExportFiltered"       "view: doExportFiltered"
check "src/js/ui/view.js"               "buildCsv"               "view: buildCsv"
check "index.html"                      "FIX_EXPORT_UI"          "html: buttons"
check "index.html"                      "postExitStats"          "html: stats card"

echo ""
echo "══════════ SYNTAX CHECK ══════════"
npm run check 2>&1 | tail -5

echo ""
echo "══════════ READY ══════════"
echo "Next:"
echo "  1. npm start"
echo "  2. browser: http://localhost:8789"
echo "  3. tab پورتفوی مجازی -> 'Export JSON' یا 'Export CSV'"
echo "  4. filter dialog: symbol / fromDate / toDate / limit / side"
