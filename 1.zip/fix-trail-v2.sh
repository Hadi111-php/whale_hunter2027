#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  Futures Scalp Lab — Trailing-First Exit Engine  v2
#  Author: Architect Edition
#  Goal:  Exit ONLY on real reversal or trail hit (never on spikes)
# ============================================================

set -e
echo "=================================================="
echo "  Trailing-First Exit Engine  v2"
echo "=================================================="
echo ""

if [ ! -f "src/js/core/config.js" ] || [ ! -f "src/js/services/paper-broker.js" ]; then
  echo "[!!] Run inside project root (~/futures-pwa)"
  echo "     Current dir: $(pwd)"
  exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "[!!] python3 missing. Install:"
  echo "     pkg install python -y"
  exit 1
fi

BACKUP="backup_trail_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP/src/js/core" "$BACKUP/src/js/services"
for f in src/js/core/config.js src/js/services/paper-broker.js src/js/services/strategy.js; do
  [ -f "$f" ] && cp "$f" "$BACKUP/$f"
done
echo "[OK] Backup -> $BACKUP"
echo ""

python3 << 'PYEOF'
# -*- coding: utf-8 -*-
import os, io, sys

def readf(p):
    with io.open(p, 'r', encoding='utf-8') as f:
        return f.read()

def writef(p, s):
    with io.open(p, 'w', encoding='utf-8') as f:
        f.write(s)

def replace_once(name, path, old, new, must=True):
    if not os.path.exists(path):
        print(u"  [!] MISSING: %s" % path)
        return False
    src = readf(path)
    if old not in src:
        if must:
            print(u"  [!] %s: ANCHOR NOT FOUND" % name)
        else:
            print(u"  [-] %s: anchor absent (skip)" % name)
        return False
    src = src.replace(old, new, 1)
    writef(path, src)
    print(u"  [OK] %s" % name)
    return True

# ==============================================================
# 1) config.js — add trailing parameters
# ==============================================================
print(u"\n=== config.js ===")

replace_once(
    "add trail params",
    "src/js/core/config.js",
    u"  scanIntervalSec: 5,",
    u"""  // === TRAILING ENGINE v2 ===
  // Activate trail when profit reaches this R-multiple (0.5 = half of risk)
  trailActivationR: 0.5,
  // Trail distance = ATR * this multiplier (bigger = looser = less whipsaw)
  trailAtrMult: 1.8,
  // Lock breakeven+fees when profit reaches this R-multiple
  lockBreakevenAtR: 0.3,
  // Reversal requires volume spike above this
  reversalVolumeX: 1.5,
  // Reversal RSI confirmation thresholds
  reversalRsiLong: 70,
  reversalRsiShort: 30,
  // Min hold seconds before ANY reversal exit considered (0 = off)
  minHoldSec: 0,
  // === END TRAILING ===

  scanIntervalSec: 5,"""
)

# ==============================================================
# 2) paper-broker.js — add emaState map + save initialStop on open
# ==============================================================
print(u"\n=== paper-broker.js ===")

# 2a) constructor: emaState map
replace_once(
    "constructor: emaState",
    "src/js/services/paper-broker.js",
    u"""    const saved = readJson(STORAGE_KEYS.state, null);
    this.state = this.normalise(saved || this.initial());
    this.migrateDay();
  }""",
    u"""    const saved = readJson(STORAGE_KEYS.state, null);
    this.state = this.normalise(saved || this.initial());
    this.migrateDay();
    // Trailing engine v2: track previous EMA state per symbol for real cross detection
    this.emaState = new Map();
  }"""
)

# 2b) on open: save initialStop + flags
replace_once(
    "open(): save initialStop + trail flags",
    "src/js/services/paper-broker.js",
    u"""      stop: signal.stop,
      take: signal.take,
      openFee,
      openedAt: Date.now(),
      reason,
      score: signal.score,
      riskProfile,
      signalId: signal.signalId,
      source: signal.source,
      candleTs: signal.candleTs,
      auditSnapshot: signal.auditSnapshot || null
    });""",
    u"""      stop: signal.stop,
      initialStop: signal.stop,        // NEVER moved (hard SL floor)
      take: signal.take,
      openFee,
      openedAt: Date.now(),
      reason,
      score: signal.score,
      riskProfile,
      signalId: signal.signalId,
      source: signal.source,
      candleTs: signal.candleTs,
      auditSnapshot: signal.auditSnapshot || null,
      breakevenLocked: false,          // trail engine v2
      trailActive: false               // trail engine v2
    });"""
)

print(u"\n=== updateStops replacement ===")

# 2c) Replace the entire updateStops method with clean trailing logic
old_update = u"""  updateStops(marketMap, signalsMap) {
    const now = Date.now();
    const maxHoldMs = Math.max(0, Number(this.s.value.maxHoldMinutes) || 0) * 60_000;

    for (const position of [...this.state.paperPositions]) {
      const market = marketMap.get(position.symbol);
      const signal = signalsMap ? signalsMap.get(position.symbol) : null;
      if (!market) continue;

      const mark = Number(market.price);
      if (!Number.isFinite(mark) || mark <= 0) continue;
      const isLong = position.side === 'LONG';
      const entry = Number(position.entry);
      let exit = null;
      let reason = '';

      // Do not use the whole current candle's high/low to manage a position
      // opened mid-candle: those extremes may have happened before entry.
      // This scanner only has snapshots, so exits are evaluated against live mark.
      position.highWater = Math.max(Number(position.highWater || entry), mark);
      position.lowWater = Math.min(Number(position.lowWater || entry), mark);

      if (isLong && mark <= Number(position.stop)) {
        exit = Number(position.stop);
        reason = 'SL_HARD_STOP';
      } else if (!isLong && mark >= Number(position.stop)) {
        exit = Number(position.stop);
        reason = 'SL_HARD_STOP';
      }

      if (!exit && Number(position.take) > 0) {
        if (isLong && mark >= Number(position.take)) {
          exit = Number(position.take);
          reason = 'TAKE_PROFIT';
        } else if (!isLong && mark <= Number(position.take)) {
          exit = Number(position.take);
          reason = 'TAKE_PROFIT';
        }
      }

      if (!exit && maxHoldMs > 0 && now - Number(position.openedAt || now) >= maxHoldMs) {
        exit = mark;
        reason = 'MAX_HOLD_TIME';
      }

      const gross = this.grossPnl(position, mark);
      // FIX: use round-trip fee, not just 1.5x open fee
      const roundTripFee = Number(position.openFee || 0) + this.closeFee(position, mark);
      const isInProfit = gross > roundTripFee * 2.5;
      if (!exit && isInProfit) {
        const breakevenStop = isLong ? entry * 1.002 : entry * 0.998;
        if (isLong && Number(position.stop) < breakevenStop) {
          position.stop = breakevenStop;
        } else if (!isLong && Number(position.stop) > breakevenStop) {
          position.stop = breakevenStop;
        }

        const atr = (signal && Number(signal.atr) > 0) ? Number(signal.atr) : mark * 0.005;
        const trailDistance = atr * 1.25;
        if (isLong) {
          position.stop = Math.max(Number(position.stop), position.highWater - trailDistance);
          if (mark <= Number(position.stop)) {
            exit = mark;
            reason = 'PROFIT_TRAIL_REVERSED';
          }
        } else {
          position.stop = Math.min(Number(position.stop), position.lowWater + trailDistance);
          if (mark >= Number(position.stop)) {
            exit = mark;
            reason = 'PROFIT_TRAIL_REVERSED';
          }
        }

        if (!exit && signal) {
          if (isLong) {
            const rsiReversal = Number(signal.rsi) > 68 && Number(signal.movePct) < -0.15;
            const emaBearCross = Number(signal.emaFast) > 0 && Number(signal.emaSlow) > 0
              && Number(signal.emaFast) < Number(signal.emaSlow) && Number(signal.volX) > 1.3;
            if (rsiReversal || emaBearCross) {
              exit = mark;
              reason = rsiReversal ? 'REVERSAL_RSI_OVERBOUGHT' : 'REVERSAL_EMA_CROSS';
            }
          } else {
            const rsiReversal = Number(signal.rsi) < 32 && Number(signal.movePct) > 0.15;
            const emaBullCross = Number(signal.emaFast) > 0 && Number(signal.emaSlow) > 0
              && Number(signal.emaFast) > Number(signal.emaSlow) && Number(signal.volX) > 1.3;
            if (rsiReversal || emaBullCross) {
              exit = mark;
              reason = rsiReversal ? 'REVERSAL_RSI_OVERSOLD' : 'REVERSAL_EMA_CROSS';
            }
          }
        }
      }

      if (exit !== null) this.close(position, exit, reason);
    }

    // FIX_POST_EXIT_METHODS: update trackers after exit
    this.recordPostExit(marketMap);
  }"""

new_update = u"""  updateStops(marketMap, signalsMap) {
    const now = Date.now();
    const maxHoldMs = Math.max(0, Number(this.s.value.maxHoldMinutes) || 0) * 60_000;
    const minHoldMs = Math.max(0, Number(this.s.value.minHoldSec) || 0) * 1000;

    const trailActivationR = Number(this.s.value.trailActivationR ?? 0.5);
    const trailAtrMult      = Number(this.s.value.trailAtrMult ?? 1.8);
    const lockBreakevenAtR  = Number(this.s.value.lockBreakevenAtR ?? 0.3);
    const revVolX           = Number(this.s.value.reversalVolumeX ?? 1.5);
    const revRsiLong        = Number(this.s.value.reversalRsiLong ?? 70);
    const revRsiShort       = Number(this.s.value.reversalRsiShort ?? 30);

    for (const position of [...this.state.paperPositions]) {
      const market = marketMap.get(position.symbol);
      const signal = signalsMap ? signalsMap.get(position.symbol) : null;
      if (!market) continue;

      const mark = Number(market.price);
      if (!Number.isFinite(mark) || mark <= 0) continue;

      const isLong = position.side === 'LONG';
      const entry  = Number(position.entry);
      const hardStop = Number(position.initialStop || position.stop);
      const risk = Math.abs(entry - hardStop) || entry * 0.004;
      const rMultiple = isLong ? (mark - entry) / risk : (entry - mark) / risk;
      const heldMs = now - Number(position.openedAt || now);
      const holdSatisfied = heldMs >= minHoldMs;

      let exit = null;
      let reason = '';

      // Water marks for trailing
      position.highWater = Math.max(Number(position.highWater || entry), mark);
      position.lowWater  = Math.min(Number(position.lowWater  || entry), mark);

      // (1) HARD SL — the ONLY stop that is allowed below breakeven.
      if (isLong && mark <= hardStop) {
        exit = mark; reason = 'SL_HARD_STOP';
      } else if (!isLong && mark >= hardStop) {
        exit = mark; reason = 'SL_HARD_STOP';
      }

      // (2) Lock breakeven + fees once we reach lockBreakevenAtR
      const roundTripFee = Number(position.openFee || 0) + this.closeFee(position, mark);
      const feeInPrice = Number(position.qty) > 0 ? roundTripFee / Number(position.qty) : 0;
      const breakevenPlusFees = isLong
        ? entry + feeInPrice * 1.5
        : entry - feeInPrice * 1.5;

      if (!exit && rMultiple >= lockBreakevenAtR) {
        position.breakevenLocked = true;
        if (isLong && Number(position.stop) < breakevenPlusFees) {
          position.stop = breakevenPlusFees;
        } else if (!isLong && Number(position.stop) > breakevenPlusFees) {
          position.stop = breakevenPlusFees;
        }
      }

      // (3) TRAILING — activates at trailActivationR, follows high/low water
      if (!exit && rMultiple >= trailActivationR) {
        const atr = (signal && Number(signal.atr) > 0) ? Number(signal.atr) : mark * 0.005;
        const trailDistance = atr * trailAtrMult;

        if (isLong) {
          const newStop = position.highWater - trailDistance;
          if (newStop > Number(position.stop)) {
            position.stop = newStop;
            position.trailActive = true;
          }
          if (mark <= Number(position.stop)) {
            exit = mark;
            reason = position.breakevenLocked ? 'TRAIL_LOCKED_PROFIT' : 'TRAIL_STOP';
          }
        } else {
          const newStop = position.lowWater + trailDistance;
          if (newStop < Number(position.stop)) {
            position.stop = newStop;
            position.trailActive = true;
          }
          if (mark >= Number(position.stop)) {
            exit = mark;
            reason = position.breakevenLocked ? 'TRAIL_LOCKED_PROFIT' : 'TRAIL_STOP';
          }
        }
      }

      // (4) REAL REVERSAL — cross transition + volume + RSI confirmation
      //     Requires: holdSatisfied + in profit (rMultiple > 0)
      if (!exit && signal && holdSatisfied && rMultiple > 0) {
        const fast = Number(signal.emaFast);
        const slow = Number(signal.emaSlow);
        if (fast > 0 && slow > 0) {
          const nowFastAboveSlow = fast > slow;
          const prev = this.emaState.get(position.symbol) || {};
          const bearishCross = prev.fastAboveSlow === true  && nowFastAboveSlow === false;
          const bullishCross = prev.fastAboveSlow === false && nowFastAboveSlow === true;
          this.emaState.set(position.symbol, { fastAboveSlow: nowFastAboveSlow });

          const volX = Number(signal.volX) || 0;
          const rsi  = Number(signal.rsi)  || 50;

          if (isLong  && bearishCross && volX >= revVolX && rsi >= revRsiLong) {
            exit = mark; reason = 'REVERSAL_EMA_CROSS_CONFIRMED';
          }
          if (!isLong && bullishCross && volX >= revVolX && rsi <= revRsiShort) {
            exit = mark; reason = 'REVERSAL_EMA_CROSS_CONFIRMED';
          }
        }
      }

      // (5) MAX HOLD — only if user configured it (>0)
      if (!exit && maxHoldMs > 0 && heldMs >= maxHoldMs) {
        exit = mark; reason = 'MAX_HOLD_TIME';
      }

      if (exit !== null) this.close(position, exit, reason);
    }

    // Update post-exit trackers (existing)
    this.recordPostExit(marketMap);
  }"""

# Try direct replace first
src = readf("src/js/services/paper-broker.js")
if old_update in src:
    src = src.replace(old_update, new_update, 1)
    writef("src/js/services/paper-broker.js", src)
    print(u"  [OK] updateStops replaced (exact)")
else:
    print(u"  [!] updateStops exact anchor missing; will try regex-free slice")
    # Fallback: find by start marker and end at 'recordPostExit(marketMap);' + closing brace
    start_marker = u"  updateStops(marketMap, signalsMap) {"
    end_marker = u"    // FIX_POST_EXIT_METHODS: update trackers after exit\n    this.recordPostExit(marketMap);\n  }"
    i = src.find(start_marker)
    j = src.find(end_marker)
    if i >= 0 and j >= 0:
        j_end = j + len(end_marker)
        src = src[:i] + new_update + src[j_end:]
        writef("src/js/services/paper-broker.js", src)
        print(u"  [OK] updateStops replaced (via slice)")
    else:
        print(u"  [!!] Could not locate updateStops. Manual edit needed.")

# ==============================================================
# 3) strategy.js — change default exit path sanity (nothing critical, skip)
# ==============================================================
print(u"\n=== strategy.js ===")
print(u"  (no change — signal engine untouched)")
print(u"\n[u2714] Patcher done.")
PYEOF

echo ""
echo "══════════ VERIFICATION ══════════"
check() {
  if grep -q "$2" "$1" 2>/dev/null; then
    echo "  [OK] $3"
  else
    echo "  [!!] $3"
  fi
}
check "src/js/core/config.js"             "trailActivationR"          "config: trailActivationR"
check "src/js/core/config.js"             "trailAtrMult"              "config: trailAtrMult"
check "src/js/core/config.js"             "lockBreakevenAtR"          "config: lockBreakevenAtR"
check "src/js/services/paper-broker.js"   "this.emaState = new Map()" "broker: emaState map"
check "src/js/services/paper-broker.js"   "initialStop: signal.stop"  "broker: initialStop saved"
check "src/js/services/paper-broker.js"   "REVERSAL_EMA_CROSS_CONFIRMED" "broker: real cross exit"
check "src/js/services/paper-broker.js"   "TRAIL_LOCKED_PROFIT"       "broker: trail-locked exit"
check "src/js/services/paper-broker.js"   "breakevenPlusFees"         "broker: BE+fees lock"

echo ""
echo "══════════ SYNTAX CHECK ══════════"
if command -v npm >/dev/null 2>&1; then
  npm run check 2>&1 | tail -6 || echo "  [!!] npm run check failed"
else
  echo "  (npm not installed)"
fi

echo ""
echo "══════════ NEXT STEPS ══════════"
echo "  1. Restart server:  Ctrl+C  →  npm start"
echo "  2. Browser: clear PWA cache"
echo "       F12 console:"
echo "         localStorage.removeItem('scalp.lab.state.v3');"
echo "         location.reload();"
echo "  3. Settings → confirm:"
echo "       timeframe    = 15"
echo "       cooldownSec  = your value (300 ok)"
echo "       maxHoldMin   = 0  (or 240 for 4h)"
echo "  4. Let it run for 30+ min, then export Ledger"
echo ""
echo "New params (editable via localStorage):"
echo "  trailActivationR   = 0.5   (activate trail at 0.5R)"
echo "  trailAtrMult       = 1.8   (trail distance = ATR * 1.8)"
echo "  lockBreakevenAtR   = 0.3   (lock BE+fees at 0.3R)"
echo "  reversalVolumeX    = 1.5   (min volume for reversal)"
echo "  minHoldSec         = 0     (0 = off, any hold ok)"
echo ""