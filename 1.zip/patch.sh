#!/data/data/com.termux/files/usr/bin/bash

G='\033[0;32m'; Y='\033[1;33m'; R='\033[0;31m'; N='\033[0m'

echo -e "${Y}🔧 Futures Scalp Lab — Patcher (15m Fix + Fee + Snapshot)${N}\n"

# --- چک پوشه پروژه ---
if [ ! -f "src/js/core/config.js" ]; then
  echo -e "${R}✗ این اسکریپت باید داخل پوشه پروژه اجرا بشه!${N}"
  echo "  الان کجایی: $(pwd)"
  exit 1
fi

# --- بکاپ ---
BACKUP="backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP"
for f in src/js/core/config.js src/js/services/strategy.js src/js/services/paper-broker.js src/js/services/settings-store.js src/js/ui/view.js; do
  [ -f "$f" ] && cp "$f" "$BACKUP/$(basename $f)"
done
echo -e "${G}✅ Backup → $BACKUP${N}\n"

# --- اجرای پچ با Node ---
cat > /tmp/_patch.mjs << 'PATCHEOF'
import { readFileSync, writeFileSync, existsSync } from 'fs';

function patch(file, replacements) {
  if (!existsSync(file)) { console.log(`  ⚠️  missing: ${file}`); return; }
  let src = readFileSync(file, 'utf8');
  let ok = 0, total = replacements.length;
  for (const [from, to] of replacements) {
    if (!src.includes(from)) {
      console.log(`  ${'\x1b[33m'}⚠${'\x1b[0m'}  anchor not found in ${file}: "${from.slice(0,70).replace(/\n/g,'\\n')}..."`);
      continue;
    }
    src = src.split(from).join(to);
    ok++;
  }
  writeFileSync(file, src);
  console.log(`  ${ok === total ? '\x1b[32m✔\x1b[0m' : '\x1b[33m◐\x1b[0m'} ${file} → ${ok}/${total}`);
}

// ═══════════════════ config.js ═══════════════════
patch('src/js/core/config.js', [
  [
    `timeframe: '60', // پیش‌فرض ۱ ساعته طلایی (۱h) برای حذف نویزها`,
    `timeframe: '15', // FIX: پیش‌فرض ۱۵ دقیقه (ایجنت اشتباهاً ۱m گذاشته بود)`
  ],
  [
    `  medium: Object.freeze({
    minScore: 72,
    minMovePct: 0.18,
    volumeSpikeX: 1.65,
    atrStopMult: 1.25,
    takeProfitR: 1.35,
    cooldownSec: 150,
    maxHoldMinutes: 20,
    orderMargin: 40,
    leverage: 5,
    dailyLossLimitPct: 3,
    maxOpenPositions: 3
  }),`,
    `  medium: Object.freeze({
    minScore: 82,
    minMovePct: 0.35,
    volumeSpikeX: 2.2,
    atrStopMult: 2.0,
    takeProfitR: 1.8,
    cooldownSec: 300,
    maxHoldMinutes: 60,
    orderMargin: 40,
    leverage: 5,
    dailyLossLimitPct: 3,
    maxOpenPositions: 3
  }),`
  ],
  [
    `  high: Object.freeze({
    minScore: 65,
    minMovePct: 0.12,
    volumeSpikeX: 1.35,
    atrStopMult: 1.0,
    takeProfitR: 1.1,
    cooldownSec: 60,
    maxHoldMinutes: 30,
    orderMargin: 80,
    leverage: 10,
    dailyLossLimitPct: 5,
    maxOpenPositions: 5
  })`,
    `  high: Object.freeze({
    minScore: 75,
    minMovePct: 0.25,
    volumeSpikeX: 1.8,
    atrStopMult: 1.6,
    takeProfitR: 1.5,
    cooldownSec: 180,
    maxHoldMinutes: 45,
    orderMargin: 60,
    leverage: 7,
    dailyLossLimitPct: 4,
    maxOpenPositions: 4
  })`
  ]
]);

// ═══════════════════ settings-store.js — force 15m migration ═══════════════════
patch('src/js/services/settings-store.js', [
  [
    `  constructor() {
    this.value = { ...clone(DEFAULT_SETTINGS), ...readJson(STORAGE_KEYS.settings, {}) };
  }`,
    `  constructor() {
    this.value = { ...clone(DEFAULT_SETTINGS), ...readJson(STORAGE_KEYS.settings, {}) };
    // FIX: اگر ایجنت قبلاً ۱m ذخیره کرده، مجبور کن به ۱۵m برگرده
    if (!this.value.timeframe || Number(this.value.timeframe) < 5) {
      this.value.timeframe = '15';
      writeJson(STORAGE_KEYS.settings, this.value);
      console.log('[SettingsStore] Force-migrated timeframe → 15m');
    }
  }`
  ]
]);

// ═══════════════════ strategy.js ═══════════════════
patch('src/js/services/strategy.js', [
  // ۱. جریمه حجم ضعیف
  [
    `    if (volumeX >= Number(s.volumeSpikeX)) {
      longScore += 22;
      shortScore += 22;
      reasons.push(\`حجم \${volumeX.toFixed(2)}x\`);
    }`,
    `    if (volumeX >= Number(s.volumeSpikeX)) {
      longScore += 22;
      shortScore += 22;
      reasons.push(\`حجم \${volumeX.toFixed(2)}x\`);
    }
    // FIX: جریمه سنگین برای حجم ضعیف (قبلاً سیگنال روی volX=0.15 صادر می‌شد)
    if (volumeX < 0.8) {
      longScore -= 40;
      shortScore -= 40;
      reasons.push(\`حجم بسیار ضعیف (\${volumeX.toFixed(2)}x)\`);
    } else if (volumeX < Number(s.volumeSpikeX) * 0.8) {
      longScore -= 18;
      shortScore -= 18;
      reasons.push(\`حجم زیر آستانه (\${volumeX.toFixed(2)}x)\`);
    }`
  ],
  // ۲. حداقل فاصله استاپ ۰.۴٪ (قبلاً ۰.۱۵٪ — خیلی تنگ برای ۱m)
  [
    `const stopDistance = Math.max(atr * Number(s.atrStopMult), price * 0.0015);`,
    `const stopDistance = Math.max(atr * Number(s.atrStopMult), price * 0.004);`
  ],
  // ۳. Audit snapshot کامل قبل از return اصلی
  [
    `    const risk = stopDistance * qty + roundTripFee;
    const reward = stopDistance * Number(s.takeProfitR) * qty - roundTripFee;
    const candleTs = Number(last.ts || 0);

    return {
      symbol: market.symbol,
      source: market.source,
      price,
      side,`,
    `    const risk = stopDistance * qty + roundTripFee;
    const reward = stopDistance * Number(s.takeProfitR) * qty - roundTripFee;
    const candleTs = Number(last.ts || 0);

    // FIX: snapshot کامل داده لحظه سیگنال برای تحلیل بعدی برد/باخت
    const auditSnapshot = {
      ts: Date.now(),
      isoTime: new Date().toISOString(),
      symbol: market.symbol,
      source: market.source,
      side,
      score,
      price,
      lastCandle: last ? {
        ts: last.ts, open: last.open, high: last.high,
        low: last.low, close: last.close, volume: last.volume
      } : null,
      previousCandle: previous ? {
        ts: previous.ts, open: previous.open, high: previous.high,
        low: previous.low, close: previous.close, volume: previous.volume
      } : null,
      indicators: {
        movePct, oneCandlePct, volX: volumeX,
        atr, atrPct, rsi: rsiVal, emaFast, emaSlow,
        averageVolume, bodyPct,
        breakoutUp, breakoutDown, trendUp, trendDown,
        rangeHigh: rangeHighs.length ? Math.max(...rangeHighs) : null,
        rangeLow: rangeLows.length ? Math.min(...rangeLows) : null
      },
      scoring: { longScore, shortScore, reasons: [...reasons] },
      plan: {
        entry, stop, take, qty, notional,
        feeOpen, feeClose, fee: roundTripFee, risk, reward,
        riskRewardRatio: risk > 0 ? reward / risk : null
      },
      candleTs,
      settingsSnapshot: {
        timeframe: s.timeframe,
        riskProfile: s.riskProfile,
        minScore: s.minScore,
        minMovePct: s.minMovePct,
        volumeSpikeX: s.volumeSpikeX,
        atrStopMult: s.atrStopMult,
        takeProfitR: s.takeProfitR,
        orderMargin: s.orderMargin,
        leverage: s.leverage
      }
    };

    return {
      symbol: market.symbol,
      source: market.source,
      price,
      side,
      auditSnapshot,`
  ]
]);

// ═══════════════════ paper-broker.js ═══════════════════
patch('src/js/services/paper-broker.js', [
  // ۱. فیکس trail stop با کارمزد رفت و برگشت
  [
    `      const gross = this.grossPnl(position, mark);
      const isInProfit = gross > (Number(position.openFee || 0) * 1.5);`,
    `      const gross = this.grossPnl(position, mark);
      // FIX: کارمزد رفت و برگشت واقعی (قبلاً فقط ۱.۵× کارمزد ورود بود)
      const roundTripFee = Number(position.openFee || 0) + this.closeFee(position, mark);
      const isInProfit = gross > roundTripFee * 2.5;`
  ],
  // ۲. ذخیره snapshot کامل سیگنال هنگام باز کردن پوزیشن
  [
    `      signalId: signal.signalId,
      source: signal.source,
      candleTs: signal.candleTs
    });`,
    `      signalId: signal.signalId,
      source: signal.source,
      candleTs: signal.candleTs,
      // FIX: snapshot کامل داده لحظه ورود
      auditSnapshot: signal.auditSnapshot || {
        ts: Date.now(),
        isoTime: new Date().toISOString(),
        symbol: signal.symbol,
        side: signal.side,
        score: signal.score,
        price: signal.price,
        movePct: signal.movePct,
        oneCandlePct: signal.oneCandlePct,
        volX: signal.volX,
        atr: signal.atr,
        atrPct: signal.atrPct,
        rsi: signal.rsi,
        emaFast: signal.emaFast,
        emaSlow: signal.emaSlow,
        entry: signal.entry,
        stop: signal.stop,
        take: signal.take,
        notional: signal.notional,
        feeOpen: signal.feeOpen,
        feeClose: signal.feeClose,
        why: signal.why,
        source: signal.source
      }
    });`
  ],
  // ۳. ضمیمه snapshot هنگام بستن پوزیشن
  [
    `      riskProfile: position.riskProfile || this.s.value.riskProfile || 'legacy',
      source: position.source,
      durationSec: Math.max(0, Math.round((Date.now() - Number(position.openedAt)) / 1000))
    });`,
    `      riskProfile: position.riskProfile || this.s.value.riskProfile || 'legacy',
      source: position.source,
      durationSec: Math.max(0, Math.round((Date.now() - Number(position.openedAt)) / 1000)),
      // FIX: snapshot ورود + مسیر حرکت قیمت برای post-mortem
      auditSnapshot: position.auditSnapshot || null,
      entrySnapshot: {
        entry: position.entry,
        stopInitial: position.stop,
        take: position.take,
        score: position.score,
        openedAt: position.openedAt,
        highWater: position.highWater,
        lowWater: position.lowWater
      }
    });`
  ]
]);

console.log('\n\x1b[32m✅ Patcher done.\x1b[0m');
PATCHEOF

node /tmp/_patch.mjs
rm /tmp/_patch.mjs

# --- صحت‌سنجی ---
echo -e "\n${Y}🔍 Verification:${N}"
check() {
  if grep -q "$2" "$1" 2>/dev/null; then
    echo -e "  ${G}✔${N} $1"
  else
    echo -e "  ${R}✗${N} $1  → FAILED"
  fi
}
check "src/js/core/config.js"              "timeframe: '15'"
check "src/js/services/settings-store.js"  "Force-migrated timeframe"
check "src/js/services/strategy.js"        "حجم بسیار ضعیف"
check "src/js/services/strategy.js"        "auditSnapshot"
check "src/js/services/paper-broker.js"    "roundTripFee \* 2.5"
check "src/js/services/paper-broker.js"    "entrySnapshot"

echo -e "\n${Y}🧪 اجرای چک سینتکس (npm run check):${N}"
if command -v npm >/dev/null 2>&1; then
  npm run check 2>&1 | tail -5 || echo -e "${R}⚠ npm run check خطا داد — احتمالاً یکی از پچ‌ها match نشده${N}"
else
  echo "  (npm نصب نیست، رد شو)"
fi

echo -e "\n${G}✅ همه پچ‌ها اعمال شدن!${N}"
echo ""
echo -e "${Y}━━━ مرحله بعد (مهم!) ━━━${N}"
echo "  1. برو داخل مرورگر → localhost:8787"
echo "  2. کش PWA رو پاک کن:"
echo "     • Chrome: Settings → Site settings → localhost:8787 → Clear & reset"
echo "     • یا تو کنسول (F12) بزن: localStorage.clear(); location.reload()"
echo "  3. در تب Settings چک کن: timeframe = 15m"
echo "  4. یه اسکن بزن، بعد از ~۱۰ دقیقه output جدید بگیر"
echo ""
