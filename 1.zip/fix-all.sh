#!/data/data/com.termux/files/usr/bin/bash
echo "======================================"
echo "  Futures Scalp Lab — Master Fix v3"
echo "======================================"
echo ""

if [ ! -f "src/js/core/config.js" ]; then
  echo "[!!] Run inside project root"
  exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "[!!] pkg install python -y"
  exit 1
fi

BACKUP="backup_fixall_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP/src/js/core" "$BACKUP/src/js/services" "$BACKUP/src/js/ui"
for f in src/js/core/config.js src/js/services/settings-store.js src/js/services/strategy.js src/js/services/paper-broker.js src/js/services/logger.js src/js/app.js src/js/ui/view.js; do
  [ -f "$f" ] && cp "$f" "$BACKUP/$f"
done
echo "[OK] Backup → $BACKUP"
echo ""

python3 << 'PYEOF'
import os, re

def readf(p):
    with open(p, 'r', encoding='utf-8') as f: return f.read()

def writef(p, s):
    with open(p, 'w', encoding='utf-8') as f: f.write(s)

def apply(name, path, transforms):
    if not os.path.exists(path):
        print(f"  [!!] MISSING: {path}"); return
    src = readf(path); ok = 0; total = len(transforms)
    for label, fn in transforms:
        new = fn(src)
        if new == src:
            print(f"  [--] skip ({label}) — already applied or anchor missing")
        else:
            src = new; ok += 1
    writef(path, src)
    print(f"  [OK] {name}: {ok}/{total} transforms applied")

# ═══════════════════════════════════════════════════════
# 1. config.js — force 15m, new medium/high profiles
# ═══════════════════════════════════════════════════════
def cfg_timeframe(s):
    return re.sub(r"timeframe:\s*'[^']*'", "timeframe: '15'", s, count=1)

def cfg_medium(s):
    pattern = r"medium: Object\.freeze\(\{[\s\S]*?\n  \}\)"
    new = """medium: Object.freeze({
    minScore: 82,
    minMovePct: 0.35,
    volumeSpikeX: 2.2,
    atrStopMult: 2.0,
    takeProfitR: 1.8,
    cooldownSec: 900,
    maxHoldMinutes: 60,
    orderMargin: 40,
    leverage: 5,
    dailyLossLimitPct: 3,
    maxOpenPositions: 2
  })"""
    return re.sub(pattern, new, s, count=1)

def cfg_high(s):
    pattern = r"high: Object\.freeze\(\{[\s\S]*?\n  \}\)"
    new = """high: Object.freeze({
    minScore: 75,
    minMovePct: 0.25,
    volumeSpikeX: 1.8,
    atrStopMult: 1.6,
    takeProfitR: 1.5,
    cooldownSec: 600,
    maxHoldMinutes: 45,
    orderMargin: 60,
    leverage: 7,
    dailyLossLimitPct: 4,
    maxOpenPositions: 2
  })"""
    return re.sub(pattern, new, s, count=1)

apply("config.js", "src/js/core/config.js", [
    ("timeframe → 15", cfg_timeframe),
    ("medium profile", cfg_medium),
    ("high profile", cfg_high),
])

# ═══════════════════════════════════════════════════════
# 2. settings-store.js — force-migrate stored timeframe
# ═══════════════════════════════════════════════════════
def ss_migrate(s):
    if "FIX_FORCE_15M" in s: return s
    old = """  constructor() {
    this.value = { ...clone(DEFAULT_SETTINGS), ...readJson(STORAGE_KEYS.settings, {}) };
  }"""
    new = """  constructor() {
    this.value = { ...clone(DEFAULT_SETTINGS), ...readJson(STORAGE_KEYS.settings, {}) };
    // FIX_FORCE_15M: اگر ایجنت قبلاً ۱m ذخیره کرده، اجباراً ۱۵m کن
    const tf = Number(this.value.timeframe);
    if (!this.value.timeframe || tf < 5 || this.value.timeframe === '1') {
      this.value.timeframe = '15';
      this.value.cooldownSec = Math.max(900, Number(this.value.cooldownSec) || 0);
      this.value.maxOpenPositions = Math.min(2, Number(this.value.maxOpenPositions) || 3);
      writeJson(STORAGE_KEYS.settings, this.value);
      console.log('[SettingsStore] FIX_FORCE_15M → timeframe=15m, cooldown=900s, maxPos=2');
    }
  }"""
    return s.replace(old, new, 1)

apply("settings-store.js", "src/js/services/settings-store.js", [
    ("force migrate", ss_migrate),
])

# ═══════════════════════════════════════════════════════
# 3. strategy.js — wider stop, volume penalty, full audit snapshot
# ═══════════════════════════════════════════════════════
def st_stop(s):
    return re.sub(r"price \* 0\.0015", "price * 0.004", s)

def st_vol_penalty(s):
    if "FIX_WEAK_VOL" in s: return s
    anchor = """    if (volumeX >= Number(s.volumeSpikeX)) {
      longScore += 22;
      shortScore += 22;
      reasons.push(`حجم ${volumeX.toFixed(2)}x`);
    }"""
    add = anchor + """
    // FIX_WEAK_VOL: جریمه حجم ضعیف
    if (volumeX < 0.8) {
      longScore -= 40; shortScore -= 40;
      reasons.push(`حجم بسیار ضعیف (${volumeX.toFixed(2)}x)`);
    } else if (volumeX < Number(s.volumeSpikeX) * 0.8) {
      longScore -= 18; shortScore -= 18;
      reasons.push(`حجم زیر آستانه (${volumeX.toFixed(2)}x)`);
    }"""
    return s.replace(anchor, add, 1)

def st_snapshot(s):
    if "FIX_AUDIT_SNAPSHOT" in s: return s
    anchor = """    const risk = stopDistance * qty + roundTripFee;
    const reward = stopDistance * Number(s.takeProfitR) * qty - roundTripFee;
    const candleTs = Number(last.ts || 0);

    return {
      symbol: market.symbol,
      source: market.source,
      price,
      side,"""
    add = """    const risk = stopDistance * qty + roundTripFee;
    const reward = stopDistance * Number(s.takeProfitR) * qty - roundTripFee;
    const candleTs = Number(last.ts || 0);

    // FIX_AUDIT_SNAPSHOT: ثبت کامل داده لحظه سیگنال
    const auditSnapshot = {
      ts: Date.now(),
      isoTime: new Date().toISOString(),
      symbol: market.symbol,
      source: market.source,
      side, score, price,
      lastCandle: last ? { ts:last.ts, open:last.open, high:last.high, low:last.low, close:last.close, volume:last.volume } : null,
      previousCandle: previous ? { ts:previous.ts, open:previous.open, high:previous.high, low:previous.low, close:previous.close, volume:previous.volume } : null,
      recentCandles: candles.slice(-20).map(c => ({ ts:c.ts, o:c.open, h:c.high, l:c.low, c:c.close, v:c.volume })),
      indicators: {
        movePct, oneCandlePct, volX: volumeX,
        atr, atrPct, rsi: rsiVal, emaFast, emaSlow,
        averageVolume, bodyPct,
        breakoutUp, breakoutDown, trendUp, trendDown,
        rangeHigh: rangeHighs.length ? Math.max(...rangeHighs) : null,
        rangeLow: rangeLows.length ? Math.min(...rangeLows) : null
      },
      scoring: { longScore, shortScore, reasons: [...reasons] },
      plan: { entry, stop, take, qty, notional, feeOpen, feeClose, fee: roundTripFee, risk, reward,
              riskRewardRatio: risk > 0 ? reward/risk : null },
      settingsSnapshot: {
        timeframe: s.timeframe, riskProfile: s.riskProfile,
        minScore: s.minScore, minMovePct: s.minMovePct,
        volumeSpikeX: s.volumeSpikeX, atrStopMult: s.atrStopMult,
        takeProfitR: s.takeProfitR, orderMargin: s.orderMargin, leverage: s.leverage
      }
    };

    return {
      symbol: market.symbol,
      source: market.source,
      price,
      side,
      auditSnapshot,"""
    return s.replace(anchor, add, 1)

apply("strategy.js", "src/js/services/strategy.js", [
    ("min stop 0.4%", st_stop),
    ("weak vol penalty", st_vol_penalty),
    ("audit snapshot", st_snapshot),
])

# ═══════════════════════════════════════════════════════
# 4. paper-broker.js — fee fix, same-dir limit, snapshot preservation, signal ledger
# ═══════════════════════════════════════════════════════
def pb_fee(s):
    old = """      const gross = this.grossPnl(position, mark);
      const isInProfit = gross > (Number(position.openFee || 0) * 1.5);"""
    new = """      const gross = this.grossPnl(position, mark);
      // FIX_RTFEE: کارمزد رفت و برگشت واقعی، نه فقط ۱.۵× ورود
      const roundTripFee = Number(position.openFee || 0) + this.closeFee(position, mark);
      const isInProfit = gross > roundTripFee * 2.5;"""
    return s.replace(old, new, 1)

def pb_samedir(s):
    """افزودن چک همجهت به canOpen و open"""
    if "FIX_SAMEDIR" in s: return s
    old = """  canOpen(signal) {
    const s = this.s.value;
    if (!signal || signal.side === 'WAIT' || this.dailyLossExceeded()) return false;
    if (this.state.paperPositions.length >= Number(s.maxOpenPositions)) return false;
    if (this.state.paperPositions.some(position => position.symbol === signal.symbol)) return false;
    const cooldown = Number(s.cooldownSec) * 1000;
    return Date.now() - Number(this.state.lastCooldown[signal.symbol] || 0) > cooldown;
  }"""
    new = """  canOpen(signal) {
    const s = this.s.value;
    if (!signal || signal.side === 'WAIT' || this.dailyLossExceeded()) return false;
    if (this.state.paperPositions.length >= Number(s.maxOpenPositions)) return false;
    if (this.state.paperPositions.some(position => position.symbol === signal.symbol)) return false;
    // FIX_SAMEDIR: حداکثر ۲ پوزیشن همجهت — جلوگیری از SL همزمان
    const sameDir = this.state.paperPositions.filter(p => p.side === signal.side).length;
    if (sameDir >= 2) return false;
    const cooldown = Number(s.cooldownSec) * 1000;
    return Date.now() - Number(this.state.lastCooldown[signal.symbol] || 0) > cooldown;
  }"""
    return s.replace(old, new, 1)

def pb_open_snapshot(s):
    old = """      signalId: signal.signalId,
      source: signal.source,
      candleTs: signal.candleTs
    });"""
    new = """      signalId: signal.signalId,
      source: signal.source,
      candleTs: signal.candleTs,
      auditSnapshot: signal.auditSnapshot || null
    });"""
    return s.replace(old, new, 1)

def pb_close_snapshot(s):
    old = """      riskProfile: position.riskProfile || this.s.value.riskProfile || 'legacy',
      source: position.source,
      durationSec: Math.max(0, Math.round((Date.now() - Number(position.openedAt)) / 1000))
    });"""
    new = """      riskProfile: position.riskProfile || this.s.value.riskProfile || 'legacy',
      source: position.source,
      durationSec: Math.max(0, Math.round((Date.now() - Number(position.openedAt)) / 1000)),
      auditSnapshot: position.auditSnapshot || null,
      entrySnapshot: {
        entry: position.entry,
        stopInitial: position.stop,
        take: position.take,
        score: position.score,
        openedAt: position.openedAt,
        highWater: position.highWater,
        lowWater: position.lowWater,
        reasonOpen: position.reason
      }
    });"""
    return s.replace(old, new, 1)

def pb_log_signal(s):
    """افزودن متد برای ثبت همه سیگنالها (حتی WAIT)"""
    if "FIX_LEDGER" in s: return s
    anchor = """  open(signal, reason = 'auto', force = false) {"""
    add = """  // FIX_LEDGER: ثبت همه سیگنالها (حتی WAIT) برای تحلیل بعدی
  logSignal(signal) {
    if (!signal) return;
    if (!Array.isArray(this.state.signalLedger)) this.state.signalLedger = [];
    this.state.signalLedger.unshift({
      ts: Date.now(),
      isoTime: new Date().toISOString(),
      symbol: signal.symbol,
      side: signal.side,
      score: signal.score,
      price: signal.price,
      source: signal.source,
      why: signal.why,
      indicators: signal.auditSnapshot?.indicators || {
        movePct: signal.movePct, volX: signal.volX, atr: signal.atr, atrPct: signal.atrPct,
        rsi: signal.rsi, emaFast: signal.emaFast, emaSlow: signal.emaSlow
      },
      plan: signal.side !== 'WAIT' ? {
        entry: signal.entry, stop: signal.stop, take: signal.take,
        notional: signal.notional, fee: signal.fee, risk: signal.risk, reward: signal.reward
      } : null,
      fullSnapshot: signal.auditSnapshot || null
    });
    this.state.signalLedger = this.state.signalLedger.slice(0, 800);
    this.save();
  }

  open(signal, reason = 'auto', force = false) {"""
    return s.replace(anchor, add, 1)

apply("paper-broker.js", "src/js/services/paper-broker.js", [
    ("round-trip fee", pb_fee),
    ("same-direction limit", pb_samedir),
    ("open snapshot", pb_open_snapshot),
    ("close snapshot", pb_close_snapshot),
    ("signal ledger", pb_log_signal),
])

# ═══════════════════════════════════════════════════════
# 5. app.js — hook signal ledger into scan loop
# ═══════════════════════════════════════════════════════
def app_ledger(s):
    if "FIX_LEDGER_HOOK" in s: return s
    old = """        const market = result.value;
        const signal = this.strategy.analyze(market);
        this.marketData.set(symbol, market);
        this.signals.set(symbol, signal);
        this.prices.set(symbol, market.price);"""
    new = """        const market = result.value;
        const signal = this.strategy.analyze(market);
        this.marketData.set(symbol, market);
        this.signals.set(symbol, signal);
        this.prices.set(symbol, market.price);
        // FIX_LEDGER_HOOK: ثبت هر سیگنال (حتی WAIT) برای تحلیل بعدی
        try { this.paper.logSignal(signal); } catch (e) { /* silent */ }"""
    return s.replace(old, new, 1)

apply("app.js", "src/js/app.js", [
    ("ledger hook", app_ledger),
])

# ═══════════════════════════════════════════════════════
# 6. view.js — add signal ledger export button
# ═══════════════════════════════════════════════════════
def view_export(s):
    if "FIX_EXPORT_LEDGER" in s: return s
    old = """    $('#closeAllPaperBtn').onclick = () => this.app.closeAllPaper();"""
    new = """    // FIX_EXPORT_LEDGER: دانلود Signal Ledger (همه سیگنالها حتی WAIT)
    const exportLedgerBtn = document.getElementById('exportLedgerBtn');
    if (exportLedgerBtn) {
      exportLedgerBtn.onclick = () => {
        const ledger = this.app.paper.state.signalLedger || [];
        const payload = {
          exportedAt: new Date().toISOString(),
          count: ledger.length,
          signalLedger: ledger,
          summary: {
            total: ledger.length,
            longSignals: ledger.filter(s => s.side === 'LONG').length,
            shortSignals: ledger.filter(s => s.side === 'SHORT').length,
            waitSignals: ledger.filter(s => s.side === 'WAIT').length
          }
        };
        const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `signal_ledger_${Date.now()}.json`;
        a.click();
        alert(`📊 ${ledger.length} سیگنال دانلود شد`);
      };
    }

    $('#closeAllPaperBtn').onclick = () => this.app.closeAllPaper();"""
    return s.replace(old, new, 1)

apply("view.js", "src/js/ui/view.js", [
    ("export ledger btn", view_export),
])
PYEOF

# ═══════════════════════════════════════════════════════
# 7. Add export button to index.html
# ═══════════════════════════════════════════════════════
if grep -q "exportLedgerBtn" index.html 2>/dev/null; then
  echo "[--] index.html: exportLedgerBtn already exists"
else
  python3 << 'HTMLFIX'
import re
p = 'index.html'
with open(p, 'r', encoding='utf-8') as f: s = f.read()
old = '<button id="exportTradesJsonBtn"'
new = '<button id="exportLedgerBtn" class="btn" style="background:#8b5cf6; color:#fff; font-weight:bold;">📊 دانلود همه سیگنال‌ها (Ledger)</button>\n          <button id="exportTradesJsonBtn"'
if 'exportLedgerBtn' in s:
    print("[--] index.html: already patched")
elif old in s:
    s = s.replace(old, new, 1)
    with open(p, 'w', encoding='utf-8') as f: f.write(s)
    print("[OK] index.html: export button added")
else:
    print("[!!] index.html: anchor not found")
HTMLFIX
fi

echo ""
echo "══════════ VERIFICATION ══════════"
check() {
  if grep -q "$2" "$1" 2>/dev/null; then echo "  [OK] $3"; else echo "  [!!] $3"; fi
}
check "src/js/core/config.js"             "timeframe: '15'"           "timeframe=15"
check "src/js/core/config.js"             "cooldownSec: 900"          "cooldown=900"
check "src/js/core/config.js"             "maxOpenPositions: 2"       "maxPos=2"
check "src/js/services/settings-store.js" "FIX_FORCE_15M"             "force migrate"
check "src/js/services/strategy.js"       "FIX_WEAK_VOL"              "weak vol penalty"
check "src/js/services/strategy.js"       "FIX_AUDIT_SNAPSHOT"        "audit snapshot"
check "src/js/services/paper-broker.js"   "FIX_RTFEE"                 "round-trip fee"
check "src/js/services/paper-broker.js"   "FIX_SAMEDIR"               "same-dir limit"
check "src/js/services/paper-broker.js"   "FIX_LEDGER"                "signal ledger"
check "src/js/app.js"                     "FIX_LEDGER_HOOK"           "ledger hook"
check "src/js/ui/view.js"                 "FIX_EXPORT_LEDGER"         "export button"
check "index.html"                        "exportLedgerBtn"           "html button"

echo ""
echo "══════════ SYNTAX CHECK ══════════"
npm run check 2>&1 | tail -5

echo ""
echo "══════════ READY ══════════"
echo "Next:"
echo "  1. npm start"
echo "  2. In browser console (F12):"
echo "     localStorage.clear();"
echo "     caches.keys().then(k=>k.forEach(x=>caches.delete(x)));"
echo "     location.reload(true);"
echo "  3. Settings → check timeframe = 15, cooldown = 900, maxPos = 2"
echo "  4. Paper tab → verify 'Download all signals (Ledger)' button exists"
echo "  5. Let it run for 2-4 hours → click the purple button"
