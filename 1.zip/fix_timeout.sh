#!/data/data/com.termux/files/usr/bin/bash
echo "=============================================="
echo "  Patch A: Timeout Fix (Network Resilience)"
echo "=============================================="
echo ""

if [ ! -f "server.js" ] || [ ! -f "src/js/services/market-client.js" ]; then
  echo "[!!] Run inside ~/futures-pwa"
  exit 1
fi

BACKUP="backup_timeout_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP/src/js/services"
cp server.js "$BACKUP/"
cp src/js/services/market-client.js "$BACKUP/src/js/services/"
echo "[OK] Backup -> $BACKUP"
echo ""

python3 << 'PYEOF'
import os, re

def readf(p):
    with open(p, 'r', encoding='utf-8') as f: return f.read()

def writef(p, s):
    with open(p, 'w', encoding='utf-8') as f: f.write(s)

def count_occurrences(path, pattern):
    src = readf(path)
    return len(re.findall(pattern, src))

# ==========================================================
# 1) server.js — Bybit timeout 3000 -> 8000
# ==========================================================
print("=== server.js ===")

p = 'server.js'
src = readf(p)
changes = 0

# Bybit proxy timeout
before = src
src = src.replace('AbortSignal.timeout(3000)', 'AbortSignal.timeout(8000)', 1)
if src != before:
    changes += 1
    print("  [OK] Bybit proxy timeout: 3000 -> 8000")
else:
    print("  [!] Bybit 3000 anchor not found")

# OKX timeout
before = src
src = src.replace('AbortSignal.timeout(3500)', 'AbortSignal.timeout(6000)')
if src != before:
    n = count_occurrences(p, r'6000')
    print(f"  [OK] OKX/Tier-2 timeout: 3500 -> 6000")
else:
    print("  [!] 3500 anchor not found")

# CoinGecko timeout
before = src
src = src.replace('AbortSignal.timeout(4000)', 'AbortSignal.timeout(6000)')
if src != before:
    print("  [OK] CoinGecko timeout: 4000 -> 6000")
else:
    print("  [!] 4000 anchor not found")

writef(p, src)

# ==========================================================
# 2) market-client.js — browser timeout 9000 -> 25000
# ==========================================================
print("\n=== market-client.js ===")

p = 'src/js/services/market-client.js'
src = readf(p)

before = src
src = src.replace(
    'const timeout = setTimeout(() => controller.abort(), 9000);',
    'const timeout = setTimeout(() => controller.abort(), 25000);'
)
if src != before:
    print("  [OK] Browser fetch timeout: 9000 -> 25000")
else:
    print("  [!] 9000 anchor not found — trying alternate")
    src = src.replace('controller.abort(), 9000', 'controller.abort(), 25000')

# Also try to bump server-side timeout if it exists in market-client
src = src.replace('AbortSignal.timeout(3000)', 'AbortSignal.timeout(8000)')

writef(p, src)

print("\n✅ Patcher done.")
PYEOF

echo ""
echo "══════════ VERIFICATION ══════════"

check() {
  if grep -q "$2" "$1" 2>/dev/null; then echo "  [OK] $3"; else echo "  [!!] $3"; fi
}

check "server.js" "AbortSignal.timeout(8000)" "server: Bybit 8s timeout"
check "server.js" "AbortSignal.timeout(6000)" "server: OKX/CG 6s timeout"
check "src/js/services/market-client.js" "controller.abort(), 25000" "client: browser 25s timeout"

echo ""
echo "══════════ SYNTAX CHECK ══════════"
npm run check 2>&1 | tail -5

echo ""
echo "══════════ READY ══════════"
echo "Next:"
echo "  1. Ctrl+C server → npm start"
echo "  2. Wait 15-30 minutes"
echo "  3. Check log — DATA ERROR should be zero"
