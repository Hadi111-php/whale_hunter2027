#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  run-mobile.sh — کپی شل‌ها از Downloads + اجرا روی 8800
# ============================================================

set -e
G='\033[0;32m'; Y='\033[1;33m'; R='\033[0;31m'; B='\033[0;34m'; N='\033[0m'
say(){ echo -e "${B}▶${N} $1"; }
ok(){  echo -e "${G}✔${N} $1"; }
warn(){echo -e "${Y}⚠${N} $1"; }
err(){ echo -e "${R}✘${N} $1"; }

# ---------- 0) چک محیط ----------
if [ ! -f "package.json" ]; then
  err "اینجا روت پروژه نیست. برو داخل پوشه پروژه:"
  echo "    cd ~/futures-pwa"
  exit 1
fi

# ---------- 1) دسترسی به حافظه ----------
if [ ! -d "/sdcard/Download" ]; then
  say "دسترسی به حافظه لازم است..."
  termux-setup-storage
  sleep 2
fi

SRC="/sdcard/Download"
ok "پروژه: $(pwd)"
ok "منبع: $SRC"
echo ""

# ---------- 2) پیدا کردن و کپی فایل‌های .sh ----------
say "جستجوی فایل‌های .sh در Downloads…"

FOUND=0
for f in fix-trail-v2.sh refactor-v3.sh patch-v4.sh run-all-termux.sh; do
  if [ -f "$SRC/$f" ]; then
    if [ -f "./$f" ]; then
      # چک کن تفاوت دارند؟
      if ! cmp -s "$SRC/$f" "./$f"; then
        cp "$SRC/$f" "./$f"
        ok "به‌روزرسانی: $f"
      else
        ok "بدون تغییر: $f"
      fi
    else
      cp "$SRC/$f" "./$f"
      ok "کپی جدید: $f"
    fi
    FOUND=$((FOUND+1))
  else
    warn "پیدا نشد در Downloads: $f"
  fi
done
echo ""
ok "$FOUND فایل پردازش شد"

# ---------- 3) اجرایی کردن ----------
chmod +x *.sh 2>/dev/null || true
ok "همه‌ی .sh اجرایی شدند"
echo ""

# ---------- 4) بکاپ پیش از پچ ----------
BK="backup_mobile_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BK"
for f in src/js/core/config.js src/js/services/paper-broker.js \
         src/js/services/logger.js src/js/app.js src/js/ui/view.js index.html; do
  [ -f "$f" ] && cp "$f" "$BK/$(basename $f)" 2>/dev/null || true
done
ok "بکاپ → $BK"
echo ""

# ---------- 5) اجرای پچ‌ها (فقط اگه اعمال نشده) ----------
has() { grep -q "$1" "$2" 2>/dev/null; }

if has "REVERSAL_EMA_CROSS_CONFIRMED" "src/js/services/paper-broker.js"; then
  ok "trail-v2 قبلاً اعمال شده — skip"
else
  say "اجرای trail-v2…"
  bash fix-trail-v2.sh && ok "trail-v2 تمام" || warn "trail-v2 با خطا"
fi
echo ""

if has "MarketFeed" "src/js/app.js"; then
  ok "refactor-v3 قبلاً اعمال شده — skip"
else
  say "اجرای refactor-v3…"
  bash refactor-v3.sh && ok "refactor-v3 تمام" || warn "refactor-v3 با خطا"
fi
echo ""

if has "trailActivationR" "src/js/core/config.js"; then
  ok "patch-v4 قبلاً اعمال شده — skip"
else
  say "اجرای patch-v4…"
  bash patch-v4.sh && ok "patch-v4 تمام" || warn "patch-v4 با خطا"
fi
echo ""

# ---------- 6) اعتبارسنجی ----------
say "═══ اعتبارسنجی ═══"
check(){ has "$2" "$1" && ok "$3" || err "$3"; }
check "src/js/core/config.js"           "trailActivationR"             "config: پارامترهای خروج"
check "src/js/core/config.js"           "maxHoldMinutes: 0"            "config: maxHold خاموش"
check "src/js/services/paper-broker.js" "REVERSAL_EMA_CROSS_CONFIRMED" "broker: کراس واقعی"
check "src/js/services/paper-broker.js" "TRAIL_LOCKED_PROFIT"          "broker: trail-locked"
check "src/js/app.js"                   "window.__marketFeed"          "app: feed عمومی"
check "src/js/core/market-feed.js"      "export class MarketFeed"      "feed: ماژول"
check "src/js/services/logger.js"       "exportSignalLog"              "logger: export"
check "index.html"                      "trailActivationR"             "html: fieldset"
check "index.html"                      "exportSignalsFullBtn"         "html: دکمه Rich"
echo ""

# ---------- 7) سینتکس چک ----------
say "═══ npm run check ═══"
npm run check 2>&1 | tail -4 || warn "check با هشدار"
echo ""

# ---------- 8) اجرا روی پورت 8800 ----------
echo -e "${G}═══════════════════════════════════════════════${N}"
echo -e "${G}  اجرا روی پورت 8800${N}"
echo -e "${G}═══════════════════════════════════════════════${N}"
echo "  آدرس:  http://localhost:8800"
echo "  متوقف کردن: Ctrl+C"
echo -e "${G}═══════════════════════════════════════════════${N}"
echo ""

PORT=8800 exec npm start
