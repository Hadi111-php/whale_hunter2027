// examples/pump-dump-example.js
// ============================================================
//  EXAMPLE — How to hook into the shared MarketFeed
// ============================================================
//  The scalp app exposes its feed on window.__marketFeed.
//  Your pump-dump system can subscribe here WITHOUT fetching
//  market data on its own — zero extra network traffic.
//
//  To load:  <script type="module" src="examples/pump-dump-example.js"></script>
// ============================================================

(function attachPumpDump() {

  function bootstrap() {
    const feed = window.__marketFeed;
    if (!feed) {
      // scalp app hasn't booted yet — retry shortly
      setTimeout(bootstrap, 500);
      return;
    }

    // Local rolling window per symbol
    const HISTORY_LEN = 20;
    const history = new Map(); // symbol -> [ { ts, price, movePct, volX } ]

    const unsubscribe = feed.subscribe(({ data, errors, at }) => {
      for (const [symbol, market] of data) {
        const candles = market.candles || [];
        if (candles.length < 4) continue;

        const last = candles[candles.length - 1];
        const back4 = candles[candles.length - 4];
        const movePct = ((last.close - back4.close) / back4.close) * 100;

        const recentVols = candles.slice(-28, -1).map(c => c.volume);
        const avgVol = recentVols.length
          ? recentVols.reduce((a, b) => a + b, 0) / recentVols.length
          : last.volume;
        const volX = last.volume / (avgVol || last.volume || 1);

        const row = { ts: at, price: market.price, movePct, volX };

        if (!history.has(symbol)) history.set(symbol, []);
        const arr = history.get(symbol);
        arr.push(row);
        if (arr.length > HISTORY_LEN) arr.shift();

        // ---- Your pump/dump heuristic goes here ----
        if (movePct > 2.5 && volX > 2.5) {
          console.log(`[PUMP] ${symbol} ${movePct.toFixed(2)}% vol=${volX.toFixed(2)}x @ ${market.price}`);
          // TODO: trigger your pump-dump logic
        }
        if (movePct < -2.5 && volX > 2.5) {
          console.log(`[DUMP] ${symbol} ${movePct.toFixed(2)}% vol=${volX.toFixed(2)}x @ ${market.price}`);
          // TODO: trigger your dump logic
        }
      }
    });

    // Expose for debugging / cleanup
    window.__pumpDump = { unsubscribe, history };
    console.log('[pump-dump] subscribed to shared MarketFeed');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootstrap);
  } else {
    bootstrap();
  }
})();
