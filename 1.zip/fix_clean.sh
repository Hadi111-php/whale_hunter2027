#!/data/data/com.termux/files/usr/bin/bash
echo "=============================================="
echo "  FIX: Remove duplicate FIX_WEAK_VOL block"
echo "=============================================="
echo ""

if [ ! -f "src/js/services/strategy.js" ]; then
  echo "[!!] Run inside ~/futures-pwa"
  exit 1
fi

BACKUP="backup_clean_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP/src/js/core" "$BACKUP/src/js/services"
cp src/js/services/strategy.js "$BACKUP/src/js/services/"
cp src/js/core/config.js "$BACKUP/src/js/core/"
cp src/js/services/settings-store.js "$BACKUP/src/js/services/"
echo "[OK] Backup -> $BACKUP"
echo ""

python3 << 'PYEOF'
import os, re

def readf(p):
    with open(p, 'r', encoding='utf-8') as f: return f.read()

def writef(p, s):
    with open(p, 'w', encoding='utf-8') as f: f.write(s)

# ==========================================================
# 1) strategy.js — remove duplicate block
# ==========================================================
print("=== strategy.js ===")

p = 'src/js/services/strategy.js'
src = readf(p)

# بلوک تکراری انگلیسی که از fix5.sh اومده رو حذف کن
# این دقیقاً متن خط ۲۵۸ تا ۲۶۵ اسکرین‌شاتت هست
duplicate_block = """    // FIX: penalty for weak volume (was emitting score=100 on volX=0.15)
    if (volumeX < 0.8) {
      longScore -= 40;
      shortScore -= 40;
      reasons.push(`حجم بسیار ضعیف (${volumeX.toFixed(2)}x)`);
    } else if (volumeX < Number(s.volumeSpikeX) * 0.8) {
      longScore -= 18;
      shortScore -= 18;
      reasons.push(`حجم زیر آستانه (${volumeX.toFixed(2)}x)`);
    }
"""

# حالت اول: با ۴ فاصله و دقیقاً همین متن
if duplicate_block in src:
    src = src.replace(duplicate_block, "", 1)
    print("  [OK] Duplicate block removed (exact match)")
else:
    # حالت دوم: با regex آزادتر
    pattern = re.compile(
        r"\n\s*// FIX: penalty for weak volume \(was emitting score=100 on volX=0\.15\)\s*"
        r"\n\s*if \(volumeX < 0\.8\) \{.*?reasons\.push\(`حجم زیر آستانه.*?\}`\);\s*\n\s*\}\s*\n",
        re.DOTALL
    )
    new_src, n = pattern.subn("\n", src, count=1)
    if n > 0:
        src = new_src
        print(f"  [OK] Duplicate block removed (regex, {n} match)")
    else:
        print("  [!] Duplicate block not found — manual check needed")

# جریمه باقی‌مونده رو نرم کن: -40 → -8، -18 → -3
src = src.replace(
    "longScore -= 40; shortScore -= 40;\n      reasons.push(`حجم بسیار ضعیف",
    "longScore -= 8; shortScore -= 8;\n      reasons.push(`حجم بسیار ضعیف"
)
src = src.replace(
    "longScore -= 18; shortScore -= 18;\n      reasons.push(`حجم زیر آستانه",
    "longScore -= 3; shortScore -= 3;\n      reasons.push(`حجم زیر آستانه"
)

writef(p, src)

# چک نهایی
src2 = readf(p)
count_vol_penalty = src2.count("FIX_WEAK_VOL")
count_reason_weak = src2.count("حجم بسیار ضعیف")
count_rsi_extreme = src2.count("FIX_RSI_EXTREME")
print(f"  Post-check: FIX_WEAK_VOL={count_vol_penalty}, حجم بسیار ضعیف={count_reason_weak}, FIX_RSI_EXTREME={count_rsi_extreme}")

# ==========================================================
# 2) config.js — soften minScore 82/85 -> 60
# ==========================================================
print("\n=== config.js ===")

p = 'src/js/core/config.js'
src = readf(p)

# DEFAULT_SETTINGS
src = src.replace("minScore: 85,", "minScore: 60,", 1)
# RISK_PROFILES low
src = src.replace("minScore: 82,", "minScore: 60,", 1)
# RISK_PROFILES medium
src = src.replace("minScore: 82,", "minScore: 60,", 1)

writef(p, src)
print("  [OK] minScore 85/82/82 -> 60/60/60")

# ==========================================================
# 3) settings-store.js — force-migrate old stored minScore
# ==========================================================
print("\n=== settings-store.js ===")

p = 'src/js/services/settings-store.js'
src = readf(p)

if "FIX_CLEAN_MIGRATE" not in src:
    anchor = "    writeJson(STORAGE_KEYS.settings, this.value);\n    console.log('[SettingsStore] FIX_SOFTEN done"
    if anchor in src:
        new_block = """    // FIX_CLEAN_MIGRATE: force-migrate hard minScore (82/85) to 60
    if (Number(this.value.minScore) >= 75) {
      this.value.minScore = 60;
      console.log('[SettingsStore] FIX_CLEAN_MIGRATE: minScore -> 60');
    }

    writeJson(STORAGE_KEYS.settings, this.value);
    console.log('[SettingsStore] FIX_SOFTEN done"""
        src = src.replace(anchor, new_block, 1)
        writef(p, src)
        print("  [OK] Force migrate block added")
    else:
        # try simpler: add migration at end of constructor
        pattern = re.compile(r"(\n\s*writeJson\(STORAGE_KEYS\.settings, this\.value\);\s*\n\s*console\.log\('\[SettingsStore\] FIX_FORCE_15M)")
        if pattern.search(src):
            src = pattern.sub(
                "\n    // FIX_CLEAN_MIGRATE\n    if (Number(this.value.minScore) >= 75) { this.value.minScore = 60; }\n\\1",
                src, count=1
            )
            writef(p, src)
            print("  [OK] Force migrate (via regex)")
        else:
            print("  [!] settings-store anchor not found — will rely on browser localStorage.clear()")
else:
    print("  [-] already patched")

print("\n✅ Done.")
PYEOF

echo ""
echo "══════════ VERIFICATION ══════════"

check() {
  if grep -q "$2" "$1" 2>/dev/null; then echo "  [OK] $3"; else echo "  [!!] $3"; fi
}

check "src/js/services/strategy.js" "FIX_RSI_EXTREME" "strategy: RSI penalty KEPT ✓"
check "src/js/services/strategy.js" "FIX_DATA_QUALITY" "strategy: data quality KEPT ✓"
check "src/js/services/paper-broker.js" "FIX_DEDUP" "broker: dedup KEPT ✓"

echo ""
echo "--- check counts ---"
echo "FIX_WEAK_VOL count (should be 1):"
grep -c "FIX_WEAK_VOL" src/js/services/strategy.js

echo "حجم بسیار ضعیف count (should be 1):"
grep -c "حجم بسیار ضعیف" src/js/services/strategy.js

echo ""
echo "--- minScore values ---"
grep "minScore:" src/js/core/config.js | head -3

echo ""
echo "══════════ SYNTAX CHECK ══════════"
npm run check 2>&1 | tail -3

echo ""
echo "══════════ DONE ══════════"
