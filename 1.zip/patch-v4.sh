#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  patch-v4.sh — Full Parametric Exit Engine + Rich Signal Log
# ============================================================
set -e
echo "=================================================="
echo "  Patch v4 — Parametric + Rich Logging"
echo "=================================================="
echo ""

if [ ! -f "src/js/core/config.js" ]; then
  echo "[!!] Run inside project root."
  exit 1
fi

BACKUP="backup_v4_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP"
for f in src/js/core/config.js src/js/services/paper-broker.js src/js/services/logger.js \
         src/js/ui/view.js index.html; do
  [ -f "$f" ] && cp "$f" "$BACKUP/$(basename $f)"
done
echo "[OK] Backup -> $BACKUP"
echo ""

python3 << 'PYEOF'
# -*- coding: utf-8 -*-
import os, io

def readf(p):
    with io.open(p, 'r', encoding='utf-8') as f: return f.read()

def writef(p, s):
    with io.open(p, 'w', encoding='utf-8') as f: f.write(s)

def replace_once(name, path, old, new, must=True):
    if not os.path.exists(path):
        print(u"  [!] MISSING: %s" % path); return False
    src = readf(path)
    if old not in src:
        if must: print(u"  [!] %s: anchor not found" % name)
        return False
    src = src.replace(old, new, 1)
    writef(path, src)
    print(u"  [OK] %s" % name)
    return True

# =========================================================
# 1) config.js — expose ALL exit-engine params
# =========================================================
print(u"\n=== config.js ===")

cfg = readf("src/js/core/config.js")

# Ensure all params are present. Insert block after existing DEFAULT_SETTINGS keys.
marker = u"  // Paper account. Fee values are editable taker-fee percentages."
trail_block = u"""  // === EXIT ENGINE (all editable from dashboard) ===
  trailActivationR: 0.5,
  trailAtrMult: 1.8,
  lockBreakevenAtR: 0.3,
  reversalVolumeX: 1.5,
  reversalRsiLong: 70,
  reversalRsiShort: 30,
  minHoldSec: 0,
  maxHoldMinutes: 0,
  // === END EXIT ENGINE ===

  // Paper account. Fee values are editable taker-fee percentages."""

if u"trailActivationR" not in cfg:
    cfg = cfg.replace(marker, trail_block, 1)
    writef("src/js/core/config.js", cfg)
    print(u"  [OK] inserted exit-engine params")
else:
    print(u"  [-] exit-engine params already present")

# =========================================================
# 2) logger.js — add .signal() with full param dump
# =========================================================
print(u"\n=== logger.js ===")

logger_new = u"""import { readJson, writeJson } from '../core/utils.js';
import { STORAGE_KEYS } from '../core/config.js';

export class Logger {
  constructor() {
    this.lines = readJson(STORAGE_KEYS.logs, []);
    this.signalLog = [];
    this.listeners = new Set();
  }

  onChange(fn) { this.listeners.add(fn); fn(this.lines); }

  emit() {
    writeJson(STORAGE_KEYS.logs, this.lines);
    this.listeners.forEach(fn => fn(this.lines));
  }

  info(msg, obj) {
    const line = `[${new Date().toLocaleString()}] ${msg}${obj ? ' ' + JSON.stringify(obj) : ''}`;
    this.lines.unshift(line);
    this.lines = this.lines.slice(0, 700);
    this.emit();
  }

  // Rich signal log — every parameter, ready for JSON export
  signal(sig) {
    if (!sig) return;
    const entry = {
      ts: Date.now(),
      iso: new Date().toISOString(),
      symbol: sig.symbol,
      source: sig.source,
      side: sig.side,
      score: sig.score,
      price: sig.price,
      // raw indicators
      movePct: sig.movePct,
      oneCandlePct: sig.oneCandlePct,
      volX: sig.volX,
      atr: sig.atr,
      atrPct: sig.atrPct,
      rsi: sig.rsi,
      emaFast: sig.emaFast,
      emaSlow: sig.emaSlow,
      bodyPct: sig.auditSnapshot?.indicators?.bodyPct ?? null,
      breakoutUp: sig.auditSnapshot?.indicators?.breakoutUp ?? null,
      breakoutDown: sig.auditSnapshot?.indicators?.breakoutDown ?? null,
      trendUp: sig.auditSnapshot?.indicators?.trendUp ?? null,
      trendDown: sig.auditSnapshot?.indicators?.trendDown ?? null,
      // plan
      entry: sig.entry,
      stop: sig.stop,
      take: sig.take,
      qty: sig.qty,
      notional: sig.notional,
      feeOpen: sig.feeOpen,
      feeClose: sig.feeClose,
      feeRoundTrip: sig.fee,
      risk: sig.risk,
      reward: sig.reward,
      // why + scoring
      why: sig.why,
      longScore: sig.auditSnapshot?.scoring?.longScore ?? null,
      shortScore: sig.auditSnapshot?.scoring?.shortScore ?? null,
      reasons: sig.auditSnapshot?.scoring?.reasons ?? [],
      // settings snapshot at signal time
      settingsSnapshot: sig.auditSnapshot?.settingsSnapshot ?? null,
      // last candles
      lastCandle: sig.auditSnapshot?.lastCandle ?? null,
      prevCandle: sig.auditSnapshot?.previousCandle ?? null,
    };
    this.signalLog.unshift(entry);
    this.signalLog = this.signalLog.slice(0, 1000);
    return entry;
  }

  exportSignalLog() {
    return {
      exportedAt: new Date().toISOString(),
      count: this.signalLog.length,
      signals: this.signalLog,
    };
  }

  clear() {
    this.lines = [];
    this.signalLog = [];
    this.emit();
  }
}
"""
writef("src/js/services/logger.js", logger_new)
print(u"  [OK] rewrote logger.js with .signal() + exportSignalLog()")

# =========================================================
# 3) paper-broker.js — feed logger.signal() on every analyze
# =========================================================
print(u"\n=== paper-broker.js ===")

# hook into logSignal — add logger.signal() call
old_ls = u"""  // FIX_LEDGER: ثبت همه سیگنالها (حتی WAIT) برای تحلیل بعدی
  logSignal(signal) {
    if (!signal) return;"""
new_ls = u"""  // FIX_LEDGER: ثبت همه سیگنالها (حتی WAIT) برای تحلیل بعدی
  logSignal(signal) {
    if (!signal) return;
    // Rich log — full parameter snapshot for JSON export
    try { this.log.signal(signal); } catch (e) { /* silent */ }"""
replace_once("broker: rich signal log", "src/js/services/paper-broker.js", old_ls, new_ls)

# =========================================================
# 4) index.html — new "Exit Engine" fieldset + richer market card
# =========================================================
print(u"\n=== index.html ===")

html = readf("index.html")

# 4a) New fieldset before "ریسک و کارمزد Paper"
anchor_html = u"""          <fieldset>
            <legend>ریسک و کارمزد Paper</legend>"""

exit_fieldset = u"""          <fieldset style="grid-column: 1 / -1; background: rgba(56, 189, 248, 0.06); border: 1px solid #38bdf8;">
            <legend style="color:#38bdf8; font-weight:bold;">🎯 موتور خروج (Trailing Exit Engine)</legend>
            <p class="muted small-note" style="margin-bottom:8px;">
              سود از قیمت تبعیت می‌کند و فقط با تغییر روند واقعی یا برخورد Trail بسته می‌شود. تمام پارامترها لحظه‌ای اعمال می‌شوند.
            </p>
            <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:10px;">
              <label>فعال‌سازی Trail از چند R؟
                <input name="trailActivationR" type="number" step="0.1" min="0" />
                <small class="muted">0.5 = نصف ریسک اولیه</small>
              </label>
              <label>فاصله Trail (× ATR)
                <input name="trailAtrMult" type="number" step="0.1" min="0.5" />
                <small class="muted">1.8 = فاصله‌ی متعادل</small>
              </label>
              <label>قفل Break-Even از چند R؟
                <input name="lockBreakevenAtR" type="number" step="0.1" min="0" />
                <small class="muted">0.3 = ورود+کارمزد</small>
              </label>
              <label>آستانه حجم برای Reversal (×)
                <input name="reversalVolumeX" type="number" step="0.1" min="1" />
              </label>
              <label>RSI اشباع فروش برای LONG
                <input name="reversalRsiLong" type="number" step="1" min="60" max="100" />
              </label>
              <label>RSI اشباع خرید برای SHORT
                <input name="reversalRsiShort" type="number" step="1" min="0" max="40" />
              </label>
              <label>حداقل زمان نگهداری (ثانیه)
                <input name="minHoldSec" type="number" step="5" min="0" />
                <small class="muted">0 = غیرفعال</small>
              </label>
              <label>حداکثر زمان نگهداری (دقیقه)
                <input name="maxHoldMinutes" type="number" step="5" min="0" />
                <small class="muted">0 = غیرفعال (توصیه‌شده)</small>
              </label>
            </div>
          </fieldset>

          <fieldset>
            <legend>ریسک و کارمزد Paper</legend>"""

if u"trailActivationR" not in html:
    html = html.replace(anchor_html, exit_fieldset, 1)
    print(u"  [OK] inserted Exit Engine fieldset")
else:
    print(u"  [-] Exit Engine fieldset already present")

# 4b) richer market card — add audit details block
old_card = u"""      <p class="why muted"></p>
      <div class="trade-plan"></div>
      <button class="paperNow small">ورود مجازی</button>"""
new_card = u"""      <p class="why muted"></p>
      <div class="trade-plan"></div>
      <details class="audit-details" style="margin-top:6px;">
        <summary style="cursor:pointer; color:#38bdf8; font-size:11px;">📋 پارامترهای کامل سیگنال</summary>
        <pre class="audit-pre" style="direction:ltr; text-align:left; white-space:pre-wrap; max-height:260px; overflow:auto; background:#06111f; border:1px solid #213a5b; padding:8px; border-radius:8px; font-size:10px; color:#bcd0e6; margin-top:6px;">--</pre>
      </details>
      <button class="paperNow small">ورود مجازی</button>"""

if u"audit-details" not in html:
    html = html.replace(old_card, new_card, 1)
    print(u"  [OK] enriched market card template")
else:
    print(u"  [-] card already enriched")

# 4c) add export-signals button in Paper tab toolbar
old_btn = u"""<button id="exportLedgerBtn" class="btn" style="background:#8b5cf6; color:#fff; font-weight:bold;">📊 دانلود همه سیگنال‌ها (Ledger)</button>"""
new_btn = u"""<button id="exportLedgerBtn" class="btn" style="background:#8b5cf6; color:#fff; font-weight:bold;">📊 دانلود Ledger</button>
          <button id="exportSignalsFullBtn" class="btn" style="background:#22c55e; color:#04110c; font-weight:bold;">🧪 دانلود همه سیگنال‌ها (Rich)</button>"""

if u"exportSignalsFullBtn" not in html:
    html = html.replace(old_btn, new_btn, 1)
    print(u"  [OK] added rich-signal export button")
else:
    print(u"  [-] rich-signal export button already present")

writef("index.html", html)

# =========================================================
# 5) view.js — populate audit details + rich export handler
# =========================================================
print(u"\n=== view.js ===")

v = readf("src/js/ui/view.js")

# 5a) in renderMarkets, populate .audit-pre with full JSON
old_mk = u"""      button.disabled = signal.side === 'WAIT';
      button.onclick = () => {
        if (this.app.paper.open(signal, 'manual', true)) this.renderAll();
      };
      grid.appendChild(node);"""

new_mk = u"""      button.disabled = signal.side === 'WAIT';
      button.onclick = () => {
        if (this.app.paper.open(signal, 'manual', true)) this.renderAll();
      };

      // Populate full-parameter audit block
      if ($('.audit-pre', node) && signal.auditSnapshot) {
        const a = signal.auditSnapshot;
        const i = a.indicators || {};
        const p = a.plan || {};
        const sc = a.scoring || {};
        const st = a.settingsSnapshot || {};
        const lines = [
          `Symbol     : ${signal.symbol}`,
          `Source     : ${signal.source}`,
          `Side/Score : ${signal.side}  (${signal.score})`,
          `Price      : ${signal.price}`,
          `--- Indicators ---`,
          `movePct    : ${fmt(i.movePct, 3)}%`,
          `oneCandle% : ${fmt(i.oneCandlePct, 3)}%`,
          `volX       : ${fmt(i.volX, 2)}x`,
          `ATR / ATR% : ${fmt(i.atr, 6)} / ${fmt(i.atrPct, 3)}%`,
          `RSI        : ${fmt(i.rsi, 1)}`,
          `EMA fast/sl: ${fmt(i.emaFast, 6)} / ${fmt(i.emaSlow, 6)}`,
          `bodyPct    : ${fmt(i.bodyPct, 3)}%`,
          `breakout   : up=${i.breakoutUp}  down=${i.breakoutDown}`,
          `trend      : up=${i.trendUp}  down=${i.trendDown}`,
          `range H/L  : ${i.rangeHigh} / ${i.rangeLow}`,
          `--- Scoring ---`,
          `longScore  : ${sc.longScore}`,
          `shortScore : ${sc.shortScore}`,
          `reasons    : ${(sc.reasons || []).join(' | ')}`,
          `--- Plan ---`,
          `entry/stop : ${fmt(p.entry, 6)} / ${fmt(p.stop, 6)}`,
          `take       : ${fmt(p.take, 6)}`,
          `qty/notion : ${fmt(p.qty, 6)} / ${fmt(p.notional, 2)}`,
          `fee (rt)   : ${fmt(p.fee, 4)}`,
          `risk/reward: ${fmt(p.risk, 3)} / ${fmt(p.reward, 3)}`,
          `R/R ratio  : ${fmt(p.riskRewardRatio, 3)}`,
          `--- Settings @ signal ---`,
          `timeframe  : ${st.timeframe}m`,
          `profile    : ${st.riskProfile}`,
          `minScore   : ${st.minScore}`,
          `minMove%   : ${st.minMovePct}`,
          `volSpikeX  : ${st.volumeSpikeX}`,
          `atrStopMul : ${st.atrStopMult}`,
          `takeProfitR: ${st.takeProfitR}`,
          `margin/lev : ${st.orderMargin} / ${st.leverage}x`,
        ];
        $('.audit-pre', node).textContent = lines.join('\\n');
      }

      grid.appendChild(node);"""

if u"Populate full-parameter audit block" not in v:
    v = v.replace(old_mk, new_mk, 1)
    print(u"  [OK] audit-pre populated in renderMarkets")
else:
    print(u"  [-] audit-pre already populated")

# 5b) add export button handler
old_export = u"""    // FIX_EXPORT_HANDLERS: filtered JSON/CSV export"""
new_export = u"""    // v4: rich signal export
    const exportRichBtn = document.getElementById('exportSignalsFullBtn');
    if (exportRichBtn) {
      exportRichBtn.onclick = () => {
        const data = this.app.logger.exportSignalLog();
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `signals_rich_${Date.now()}.json`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 2000);
        alert(`✅ ${data.count} سیگنال کامل دانلود شد`);
      };
    }

    // FIX_EXPORT_HANDLERS: filtered JSON/CSV export"""

if u"exportRichBtn" not in v:
    v = v.replace(old_export, new_export, 1)
    print(u"  [OK] rich signal export handler added")
else:
    print(u"  [-] rich handler already present")

writef("src/js/ui/view.js", v)

print(u"\n[v] Patch v4 done.")
PYEOF

echo ""
echo "══════════ VERIFICATION ══════════"
check() {
  if grep -q "$2" "$1" 2>/dev/null; then echo "  [OK] $3"; else echo "  [!!] $3"; fi
}
check "src/js/core/config.js"           "trailActivationR"           "config: exit params"
check "src/js/core/config.js"           "maxHoldMinutes: 0"          "config: maxHold=0"
check "src/js/services/logger.js"       "signal(sig)"                "logger: .signal()"
check "src/js/services/logger.js"       "exportSignalLog"            "logger: exportSignalLog"
check "src/js/services/paper-broker.js" "this.log.signal(signal)"    "broker: hooks logger"
check "index.html"                      "trailActivationR"           "html: exit fieldset"
check "index.html"                      "audit-details"              "html: card details"
check "index.html"                      "exportSignalsFullBtn"       "html: rich export btn"
check "src/js/ui/view.js"               "audit-pre"                  "view: audit-pre populated"
check "src/js/ui/view.js"               "exportRichBtn"              "view: rich export handler"

echo ""
echo "══════════ SYNTAX CHECK ══════════"
npm run check 2>&1 | tail -5 || echo "  [!!] npm run check failed"

echo ""
echo "══════════ NEXT STEPS ══════════"
echo "  1. Ctrl+C  →  bash boot.sh   (or npm start)"
echo "  2. F12 → clear cache:"
echo "       localStorage.clear(); location.reload(true);"
echo "  3. Settings tab → EXIT ENGINE fieldset:"
echo "       maxHoldMinutes   = 0   (off — trailing handles it)"
echo "       trailActivationR = 0.5"
echo "       trailAtrMult     = 1.8"
echo "       lockBreakevenAtR = 0.3"
echo "  4. Market cards now have '📋 پارامترهای کامل سیگنال' collapsible"
echo "  5. Paper tab → '🧪 دانلود همه سیگنال‌ها (Rich)' → JSON کامل"
echo ""