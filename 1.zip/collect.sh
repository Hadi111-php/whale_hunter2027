#!/data/data/com.termux/files/usr/bin/bash

OUT="output.txt"

# پاک کردن فایل قبلی
> "$OUT"

# پسوندهایی که میخوای خونده بشن (اگه خواستی اضافه/کم کن)
EXTS=("sh" "bash" "py" "js" "ts" "jsx" "tsx" "c" "cpp" "h" "hpp" "java" "kt" "go" "rs" "php" "rb" "html" "css" "scss" "json" "yml" "yaml" "toml" "xml" "md" "txt" "env" "ini" "conf" "sql" "lua" "dart" "swift" "vue" "svelte" "gitignore" "dockerfile")

# ساخت شرط -name برای find
FIND_ARGS=()
for ext in "${EXTS[@]}"; do
    FIND_ARGS+=(-o -iname "*.${ext}")
done
# حذف -o اول
FIND_ARGS=("${FIND_ARGS[@]:1}")

# پیدا کردن و نوشتن در فایل
find . -type f \( "${FIND_ARGS[@]}" \) \
  ! -path "./$OUT" \
  ! -path "./.git/*" \
  ! -path "./node_modules/*" \
  | sort | while read -r file; do
    {
      echo "=================================================="
      echo "FILE: $file"
      echo "=================================================="
      cat "$file"
      echo ""
      echo ""
    } >> "$OUT"
done

echo "✅ تمام شد → $OUT"
echo "📦 حجم فایل: $(du -h "$OUT" | cut -f1)"
