import { useEffect, useState, useCallback } from 'react';
import { getServerTime, getFuturesTickers, getOpenInterest, getFundingRate } from '../lib/binanceApi';
import { checkAllExchangeStatus, EXCHANGES } from '../lib/exchangeApi';
import { isBackendAvailable } from '../lib/backendApi';
import { authService } from '../lib/auth';
import { useBrainStore } from '../brain/brainStore';
import { useAppStore } from '../store/appStore';
import {
  Server, Wifi, WifiOff, Database, Brain, Cpu,
  CheckCircle, AlertTriangle, XCircle, Activity, BarChart3,
  Globe, Zap, Shield, TrendingUp, RefreshCw, Lock, User
} from 'lucide-react';

interface HealthCheck {
  name: string;
  nameFA: string;
  status: 'OK' | 'WARN' | 'ERROR';
  latency?: number;
  detail: string;
  icon: React.ReactNode;
}

export function SystemHealth() {
  const [checks, setChecks] = useState<HealthCheck[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastCheck, setLastCheck] = useState('');
  const brainStore = useBrainStore();
  const appStore = useAppStore();

  const runHealthCheck = useCallback(async () => {
    setLoading(true);
    const results: HealthCheck[] = [];

    // 1. Binance API
    try {
      const start = Date.now();
      const serverTime = await getServerTime();
      const latency = Date.now() - start;
      const timeDiff = Math.abs(Date.now() - serverTime.serverTime);
      results.push({
        name: 'Binance Futures API', nameFA: 'بایننس فیوچرز',
        status: latency < 500 ? 'OK' : latency < 2000 ? 'WARN' : 'ERROR',
        latency, detail: `Latency: ${latency}ms | Time diff: ${timeDiff}ms`,
        icon: <Wifi size={16} className="text-green-400" />,
      });
    } catch {
      results.push({
        name: 'Binance Futures API', nameFA: 'بایننس فیوچرز',
        status: 'ERROR', detail: 'Cannot connect',
        icon: <WifiOff size={16} className="text-red-400" />,
      });
    }

    // 2. Multi-Exchange Status
    try {
      const statuses = await checkAllExchangeStatus();
      const okCount = statuses.filter(s => s.status === 'OK').length;
      const totalCount = statuses.length;
      results.push({
        name: 'Multi-Exchange', nameFA: 'چند صرافی',
        status: okCount >= 3 ? 'OK' : okCount >= 1 ? 'WARN' : 'ERROR',
        detail: statuses.map(s => `${EXCHANGES[s.exchange]?.label}: ${s.status} (${s.latency}ms)`).join(' | '),
        icon: <Globe size={16} className="text-blue-400" />,
      });
    } catch {
      results.push({
        name: 'Multi-Exchange', nameFA: 'چند صرافی',
        status: 'WARN', detail: 'Failed to check exchanges',
        icon: <Globe size={16} className="text-yellow-400" />,
      });
    }

    // 3. Ticker data
    try {
      const start = Date.now();
      const tickers = await getFuturesTickers();
      const latency = Date.now() - start;
      const usdtPairs = tickers.filter(t => t.symbol.endsWith('USDT'));
      results.push({
        name: 'Ticker Data', nameFA: 'داده‌های تیکر',
        status: usdtPairs.length > 100 ? 'OK' : 'WARN',
        latency, detail: `${usdtPairs.length} USDT pairs | ${latency}ms`,
        icon: <BarChart3 size={16} className="text-cyan-400" />,
      });
    } catch {
      results.push({
        name: 'Ticker Data', nameFA: 'داده‌های تیکر',
        status: 'ERROR', detail: 'Failed',
        icon: <BarChart3 size={16} className="text-red-400" />,
      });
    }

    // 4. OI + Funding
    try {
      const [oi, fr] = await Promise.all([getOpenInterest('BTCUSDT'), getFundingRate('BTCUSDT')]);
      results.push({
        name: 'OI & Funding', nameFA: 'قراردادباز و فاندینگ',
        status: 'OK',
        detail: `BTC OI: ${parseFloat(oi.openInterest).toLocaleString()} | Funding: ${(parseFloat(fr.fundingRate) * 100).toFixed(4)}%`,
        icon: <Zap size={16} className="text-yellow-400" />,
      });
    } catch {
      results.push({
        name: 'OI & Funding', nameFA: 'قراردادباز و فاندینگ',
        status: 'WARN', detail: 'Limited access',
        icon: <Zap size={16} className="text-yellow-400" />,
      });
    }

    // 5. Brain Engine
    const brainOutputs = brainStore.outputs.size;
    const brainRunning = brainStore.scanInterval !== null;
    const learningCount = brainStore.symbolLearnings.size;
    results.push({
      name: 'Brain Engine', nameFA: 'موتور مغز',
      status: brainRunning ? 'OK' : brainOutputs > 0 ? 'WARN' : 'ERROR',
      detail: `${brainRunning ? 'Active' : 'Idle'} | ${brainOutputs} symbols | ${learningCount} learnings`,
      icon: <Brain size={16} className={brainRunning ? 'text-green-400' : 'text-yellow-400'} />,
    });

    // 6. Paper Trading
    const stats = brainStore.tradeStats;
    results.push({
      name: 'Paper Trading', nameFA: 'معاملات مجازی',
      status: 'OK',
      detail: `Open: ${stats.openTrades} | Closed: ${stats.totalTrades} | WR: ${stats.winRate.toFixed(0)}% | P&L: $${stats.totalPnl.toFixed(2)}`,
      icon: <TrendingUp size={16} className="text-cyan-400" />,
    });

    // 7. Feedback
    results.push({
      name: 'Feedback Loop', nameFA: 'بازخورد',
      status: brainStore.feedbackLog.length > 0 ? 'OK' : 'WARN',
      detail: `Total: ${brainStore.feedbackLog.length} | Pending: ${brainStore.feedbackLog.filter(f => f.result === 'PENDING').length}`,
      icon: <RefreshCw size={16} className="text-orange-400" />,
    });

    // 8. Adaptive Ratios
    const activeR = brainStore.activeRatios.filter(r => r.status === 'ACTIVE');
    results.push({
      name: 'Adaptive Ratios', nameFA: 'نسبت‌ها',
      status: activeR.length >= 4 ? 'OK' : 'WARN',
      detail: `Active: ${activeR.length} | Total weights: ${activeR.reduce((s, r) => s + r.weight, 0).toFixed(2)}`,
      icon: <Shield size={16} className="text-purple-400" />,
    });

    // 9. Storage
    const storageUsed = (() => {
      try {
        let total = 0;
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key) total += (localStorage.getItem(key) || '').length;
        }
        return total;
      } catch { return 0; }
    })();
    results.push({
      name: 'Local Storage', nameFA: 'ذخیره‌سازی',
      status: storageUsed < 4 * 1024 * 1024 ? 'OK' : 'WARN',
      detail: `Used: ${(storageUsed / 1024).toFixed(1)} KB | Watchlist: ${appStore.watchlist.length}`,
      icon: <Database size={16} className="text-blue-400" />,
    });

    // 10. Authentication
    const authState = authService.getState();
    results.push({
      name: 'Authentication', nameFA: 'احراز هویت',
      status: authState.isAuthenticated ? 'OK' : 'WARN',
      detail: authState.isAuthenticated ? `User: ${authState.user?.username} | Role: ${authState.user?.role} | Keys: ${authState.user?.apiKeys.length || 0}` : 'Not authenticated',
      icon: authState.isAuthenticated ? <Lock size={16} className="text-green-400" /> : <User size={16} className="text-yellow-400" />,
    });

    // 11. Backend Server
    try {
      const backendOk = await isBackendAvailable();
      results.push({
        name: 'Backend Server', nameFA: 'سرور بک‌اند',
        status: backendOk ? 'OK' : 'WARN',
        detail: backendOk ? 'Connected (FastAPI/Go)' : 'Not configured - Using direct exchange API (client-side)',
        icon: backendOk ? <Wifi size={16} className="text-green-400" /> : <WifiOff size={16} className="text-gray-400" />,
      });
    } catch {
      results.push({
        name: 'Backend Server', nameFA: 'سرور بک‌اند',
        status: 'WARN',
        detail: 'Not configured',
        icon: <WifiOff size={16} className="text-gray-400" />,
      });
    }

    // 12. Browser
    results.push({
      name: 'Environment', nameFA: 'محیط',
      status: 'OK',
      detail: `${navigator.userAgent.includes('Mobile') ? 'Mobile' : 'Desktop'} | Cores: ${navigator.hardwareConcurrency || 'N/A'} | Online: ${navigator.onLine}`,
      icon: <Activity size={16} className="text-cyan-400" />,
    });

    setChecks(results);
    setLoading(false);
    setLastCheck(new Date().toLocaleTimeString('fa-IR'));
  }, [brainStore, appStore]);

  useEffect(() => { runHealthCheck(); }, [runHealthCheck]);

  const okCount = checks.filter(c => c.status === 'OK').length;
  const warnCount = checks.filter(c => c.status === 'WARN').length;
  const errorCount = checks.filter(c => c.status === 'ERROR').length;
  const health = errorCount > 0 ? 'CRITICAL' : warnCount > 2 ? 'DEGRADED' : 'HEALTHY';

  return (
    <div className="space-y-6 max-w-4xl">
      <div className={`p-6 rounded-xl border ${health === 'HEALTHY' ? 'bg-green-500/5 border-green-500/20' : health === 'DEGRADED' ? 'bg-yellow-500/5 border-yellow-500/20' : 'bg-red-500/5 border-red-500/20'}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Server size={28} className={health === 'HEALTHY' ? 'text-green-400' : health === 'DEGRADED' ? 'text-yellow-400' : 'text-red-400'} />
            <div>
              <h2 className="text-lg font-bold">System Health</h2>
              <p className="text-sm text-gray-400">Whale Hunter 2027 - Multi-Exchange</p>
            </div>
          </div>
          <div className="text-right">
            <div className={`text-2xl font-bold ${health === 'HEALTHY' ? 'text-green-400' : health === 'DEGRADED' ? 'text-yellow-400' : 'text-red-400'}`}>{health}</div>
            <div className="text-xs text-gray-500">Last: {lastCheck}</div>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-3 mt-4">
          <div className="text-center p-2 bg-green-500/10 rounded-lg"><div className="text-xl font-bold text-green-400">{okCount}</div><div className="text-xs text-gray-500">OK</div></div>
          <div className="text-center p-2 bg-yellow-500/10 rounded-lg"><div className="text-xl font-bold text-yellow-400">{warnCount}</div><div className="text-xs text-gray-500">Warning</div></div>
          <div className="text-center p-2 bg-red-500/10 rounded-lg"><div className="text-xl font-bold text-red-400">{errorCount}</div><div className="text-xs text-gray-500">Error</div></div>
        </div>
      </div>

      <button onClick={runHealthCheck} disabled={loading}
        className="flex items-center gap-2 px-4 py-2 bg-cyan-500/20 text-cyan-400 rounded-lg border border-cyan-500/30 hover:bg-cyan-500/30 disabled:opacity-50">
        <Cpu size={16} className={loading ? 'animate-spin' : ''} /> {loading ? 'Checking...' : 'Run Health Check'}
      </button>

      <div className="space-y-2">
        {checks.map((c, i) => (
          <div key={i} className={`p-4 rounded-xl border flex items-center gap-4 ${c.status === 'OK' ? 'bg-gray-900 border-gray-800' : c.status === 'WARN' ? 'bg-yellow-500/5 border-yellow-500/10' : 'bg-red-500/5 border-red-500/10'}`}>
            <div className="flex-shrink-0">{c.icon}</div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">{c.name}</span>
                <span className="text-xs text-gray-600">{c.nameFA}</span>
              </div>
              <p className="text-xs text-gray-400 mt-0.5">{c.detail}</p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              {c.latency !== undefined && (
                <span className={`text-xs ${c.latency < 500 ? 'text-green-400' : c.latency < 2000 ? 'text-yellow-400' : 'text-red-400'}`}>{c.latency}ms</span>
              )}
              {c.status === 'OK' && <CheckCircle size={18} className="text-green-400" />}
              {c.status === 'WARN' && <AlertTriangle size={18} className="text-yellow-400" />}
              {c.status === 'ERROR' && <XCircle size={18} className="text-red-400" />}
            </div>
          </div>
        ))}
      </div>

      {/* Architecture */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
        <div className="flex items-center gap-2 mb-4"><Cpu size={18} className="text-cyan-400" /><h3 className="font-medium">Architecture</h3></div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <h4 className="text-sm text-gray-400 mb-2">🏗 Current Stack</h4>
            <div className="space-y-1 text-xs text-gray-500">
              <div className="flex justify-between p-1.5 bg-gray-800/50 rounded"><span>Frontend</span><span className="text-gray-300">React 19 + TypeScript</span></div>
              <div className="flex justify-between p-1.5 bg-gray-800/50 rounded"><span>Brain</span><span className="text-purple-400">Adaptive Ratio Engine</span></div>
              <div className="flex justify-between p-1.5 bg-gray-800/50 rounded"><span>Exchanges</span><span className="text-green-400">Binance, Bybit, OKX, Bitget, Kraken</span></div>
              <div className="flex justify-between p-1.5 bg-gray-800/50 rounded"><span>Learning</span><span className="text-cyan-400">12h + 30d + Per-Symbol</span></div>
              <div className="flex justify-between p-1.5 bg-gray-800/50 rounded"><span>Storage</span><span className="text-gray-300">localStorage (→ PostgreSQL + Redis)</span></div>
            </div>
          </div>
          <div>
            <h4 className="text-sm text-gray-400 mb-2">📱 Backend Stack (Ready)</h4>
            <div className="space-y-1 text-xs text-gray-500">
              <div className="flex justify-between p-1.5 bg-gray-800/50 rounded"><span>Backend API</span><span className="text-cyan-400">FastAPI (Python)</span></div>
              <div className="flex justify-between p-1.5 bg-gray-800/50 rounded"><span>Database</span><span className="text-cyan-400">PostgreSQL + Redis</span></div>
              <div className="flex justify-between p-1.5 bg-gray-800/50 rounded"><span>WebSocket</span><span className="text-cyan-400">Binance/Bybit Stream</span></div>
              <div className="flex justify-between p-1.5 bg-gray-800/50 rounded"><span>Auth</span><span className="text-yellow-400">JWT (Backend Ready)</span></div>
              <div className="flex justify-between p-1.5 bg-gray-800/50 rounded"><span>Mobile</span><span className="text-cyan-400">React Native</span></div>
              <div className="flex justify-between p-1.5 bg-gray-800/50 rounded"><span>ML Layer</span><span className="text-cyan-400">scikit-learn / numpy</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
