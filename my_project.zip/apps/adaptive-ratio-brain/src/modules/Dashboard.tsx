import { useEffect, useState, useCallback } from 'react';
import { getFuturesTickers, getKlines, getGlobalMarketData, type FuturesTicker } from '../lib/binanceApi';
import { useAppStore } from '../store/appStore';
import { useBrainStore } from '../brain/brainStore';
import { authService } from '../lib/auth';
import { XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, Activity, BarChart3, Eye, Brain, Zap } from 'lucide-react';

function formatNumber(n: number): string {
  if (n >= 1e12) return (n / 1e12).toFixed(2) + 'T';
  if (n >= 1e9) return (n / 1e9).toFixed(2) + 'B';
  if (n >= 1e6) return (n / 1e6).toFixed(2) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'K';
  return n.toFixed(2);
}

export function Dashboard() {
  const { watchlist, setSelectedSymbol, setPage } = useAppStore();
  const brainStore = useBrainStore();
  const user = authService.getState().user;
  const [tickers, setTickers] = useState<FuturesTicker[]>([]);
  const [globalData, setGlobalData] = useState<{ total_market_cap: number; total_volume: number; btc_dominance: number; active_cryptocurrencies: number } | null>(null);
  const [btcChart, setBtcChart] = useState<{ time: string; price: number }[]>([]);
  const [loading, setLoading] = useState(true);
  const [topGainers, setTopGainers] = useState<FuturesTicker[]>([]);
  const [topLosers, setTopLosers] = useState<FuturesTicker[]>([]);

  const loadData = useCallback(async () => {
    try {
      const [tickerData, global, klines] = await Promise.all([
        getFuturesTickers(),
        getGlobalMarketData(),
        getKlines('BTCUSDT', '1h', 48),
      ]);

      const usdtTickers = tickerData.filter(t => t.symbol.endsWith('USDT'));
      setTickers(usdtTickers);
      setGlobalData(global);

      const sorted = [...usdtTickers].sort((a, b) => parseFloat(b.priceChangePercent) - parseFloat(a.priceChangePercent));
      setTopGainers(sorted.slice(0, 5));
      setTopLosers(sorted.slice(-5).reverse());

      setBtcChart(klines.map(k => ({
        time: new Date(k.openTime).toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit' }),
        price: parseFloat(k.close),
      })));

      setLoading(false);
    } catch (err) {
      console.error('Dashboard load error:', err);
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 15000);
    return () => clearInterval(interval);
  }, [loadData]);

  const watchlistTickers = tickers.filter(t => watchlist.includes(t.symbol));

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-400">Loading real-time data from Binance Futures...</p>
        </div>
      </div>
    );
  }

  const brainOutputs = Array.from(brainStore.outputs.values());
  const brainActiveSignals = brainOutputs.filter(o => o.currentSignal !== 'HOLD').length;
  const brainStats = brainStore.tradeStats;

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      {user && (
        <div className="bg-gradient-to-r from-cyan-500/10 to-purple-500/10 rounded-xl border border-cyan-500/20 p-4 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold">Welcome, {user.username}! 👋</h2>
            <p className="text-sm text-gray-400 mt-1">Whale Hunter 2027 - Multi-Exchange Futures Platform</p>
          </div>
          <div className="hidden sm:flex items-center gap-3">
            <div className="text-right">
              <div className="flex items-center gap-1">
                <Brain size={14} className="text-purple-400" />
                <span className="text-xs text-gray-400">{brainActiveSignals} Active Signals</span>
              </div>
              <div className="flex items-center gap-1">
                <Zap size={14} className="text-yellow-400" />
                <span className="text-xs text-gray-400">{brainStats.openTrades} Open Trades</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Global Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <StatCard icon={<DollarSign className="text-yellow-400" />} label="Market Cap" value={globalData ? `$${formatNumber(globalData.total_market_cap)}` : '...'} />
        <StatCard icon={<Activity className="text-cyan-400" />} label="24h Volume" value={globalData ? `$${formatNumber(globalData.total_volume)}` : '...'} />
        <StatCard icon={<BarChart3 className="text-orange-400" />} label="BTC Dom" value={globalData ? `${globalData.btc_dominance.toFixed(1)}%` : '...'} />
        <StatCard icon={<Eye className="text-purple-400" />} label="Futures" value={`${tickers.length}`} />
        <StatCard icon={<Brain className="text-purple-400" />} label="Brain WR" value={`${brainStats.winRate.toFixed(0)}%`} />
        <StatCard icon={<Zap className={brainStats.totalPnl >= 0 ? 'text-green-400' : 'text-red-400'} />} label="Brain P&L" value={`${brainStats.totalPnl >= 0 ? '+' : ''}$${brainStats.totalPnl.toFixed(0)}`} />
      </div>

      {/* BTC Chart */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
        <h3 className="text-sm font-medium text-gray-400 mb-3">BTC/USDT Futures - 48h (1H)</h3>
        <ResponsiveContainer width="100%" height={250}>
          <AreaChart data={btcChart}>
            <defs>
              <linearGradient id="btcGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#06b6d4" stopOpacity={0.3} />
                <stop offset="100%" stopColor="#06b6d4" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="time" tick={{ fill: '#6b7280', fontSize: 10 }} axisLine={false} tickLine={false} />
            <YAxis domain={['auto', 'auto']} tick={{ fill: '#6b7280', fontSize: 10 }} axisLine={false} tickLine={false} width={70} tickFormatter={v => `$${formatNumber(v)}`} />
            <Tooltip
              contentStyle={{ background: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }}
              labelStyle={{ color: '#9ca3af' }}
              formatter={(value: unknown) => [`$${Number(value).toLocaleString()}`, 'Price']}
            />
            <Area type="monotone" dataKey="price" stroke="#06b6d4" fill="url(#btcGrad)" strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Watchlist + Gainers/Losers */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Watchlist */}
        <div className="lg:col-span-1 bg-gray-900 rounded-xl border border-gray-800 p-4">
          <h3 className="text-sm font-medium text-gray-400 mb-3">📋 Watchlist</h3>
          <div className="space-y-2">
            {watchlistTickers.map(t => {
              const change = parseFloat(t.priceChangePercent);
              return (
                <button
                  key={t.symbol}
                  onClick={() => { setSelectedSymbol(t.symbol); setPage('market'); }}
                  className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-gray-800 transition"
                >
                  <span className="text-sm font-medium">{t.symbol.replace('USDT', '')}</span>
                  <div className="text-right">
                    <div className="text-sm">${parseFloat(t.lastPrice).toLocaleString()}</div>
                    <div className={`text-xs ${change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {change >= 0 ? '+' : ''}{change.toFixed(2)}%
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Top Gainers */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
          <h3 className="text-sm font-medium text-green-400 mb-3 flex items-center gap-2">
            <TrendingUp size={16} /> Top Gainers (24h)
          </h3>
          <div className="space-y-2">
            {topGainers.map(t => (
              <button
                key={t.symbol}
                onClick={() => { setSelectedSymbol(t.symbol); setPage('market'); }}
                className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-gray-800 transition"
              >
                <span className="text-sm">{t.symbol.replace('USDT', '')}</span>
                <div className="text-right">
                  <div className="text-xs text-gray-400">${parseFloat(t.lastPrice).toLocaleString()}</div>
                  <div className="text-sm text-green-400 font-medium">+{parseFloat(t.priceChangePercent).toFixed(2)}%</div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Top Losers */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
          <h3 className="text-sm font-medium text-red-400 mb-3 flex items-center gap-2">
            <TrendingDown size={16} /> Top Losers (24h)
          </h3>
          <div className="space-y-2">
            {topLosers.map(t => (
              <button
                key={t.symbol}
                onClick={() => { setSelectedSymbol(t.symbol); setPage('market'); }}
                className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-gray-800 transition"
              >
                <span className="text-sm">{t.symbol.replace('USDT', '')}</span>
                <div className="text-right">
                  <div className="text-xs text-gray-400">${parseFloat(t.lastPrice).toLocaleString()}</div>
                  <div className="text-sm text-red-400 font-medium">{parseFloat(t.priceChangePercent).toFixed(2)}%</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="bg-gray-900 rounded-xl border border-gray-800 p-4 flex items-center gap-3">
      <div className="p-2 bg-gray-800 rounded-lg">{icon}</div>
      <div>
        <p className="text-xs text-gray-500">{label}</p>
        <p className="text-lg font-bold">{value}</p>
      </div>
    </div>
  );
}
