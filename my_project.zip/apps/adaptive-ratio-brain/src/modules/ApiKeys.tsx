import { useState } from 'react';
import { authService, type ExchangeApiKey } from '../lib/auth';
import { EXCHANGES } from '../lib/exchangeApi';
import { Key, Plus, Trash2, Eye, EyeOff, Shield, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';

export function ApiKeys() {
  const user = authService.getState().user;
  const [showForm, setShowForm] = useState(false);
  const [exchange, setExchange] = useState('binance');
  const [apiKey, setApiKey] = useState('');
  const [secretKey, setSecretKey] = useState('');
  const [passphrase, setPassphrase] = useState('');
  const [label, setLabel] = useState('');
  const [permissions, setPermissions] = useState<('read' | 'trade')[]>(['read']);
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({});
  const [saved, setSaved] = useState(false);

  const apiKeys = user?.apiKeys || [];

  const handleAdd = () => {
    if (!apiKey || !secretKey || !label) return;

    const key: ExchangeApiKey = {
      exchange,
      apiKey,
      secretKey,
      passphrase: exchange === 'okx' ? passphrase : undefined,
      label,
      permissions: permissions as ('read' | 'trade' | 'withdraw')[],
      enabled: true,
      addedAt: Date.now(),
    };

    authService.addApiKey(key);
    setShowForm(false);
    setApiKey('');
    setSecretKey('');
    setPassphrase('');
    setLabel('');
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleRemove = (ex: string) => {
    if (confirm(`Remove ${ex} API key?`)) {
      authService.removeApiKey(ex);
    }
  };

  const toggleSecret = (ex: string) => {
    setShowSecrets(prev => ({ ...prev, [ex]: !prev[ex] }));
  };

  const maskKey = (key: string) => {
    if (key.length <= 8) return '••••••••';
    return key.slice(0, 4) + '••••••••' + key.slice(-4);
  };

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Header */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
        <div className="flex items-center gap-2 mb-2">
          <Key size={20} className="text-yellow-400" />
          <h2 className="text-lg font-bold">API Keys Management</h2>
        </div>
        <p className="text-sm text-gray-400">
          مدیریت کلیدهای API صرافی‌ها • برای Auto Trade واقعی نیاز به API Key دارید
        </p>
        <div className="mt-3 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
          <div className="flex items-center gap-2 text-yellow-400 text-sm">
            <AlertTriangle size={14} />
            <span>هرگز دسترسی Withdraw را فعال نکنید • فقط Read و Trade کافی است</span>
          </div>
        </div>
      </div>

      {/* Existing Keys */}
      <div className="space-y-3">
        {apiKeys.map(k => (
          <div key={k.exchange} className="bg-gray-900 rounded-xl border border-gray-800 p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold"
                  style={{ backgroundColor: EXCHANGES[k.exchange as keyof typeof EXCHANGES]?.color + '20', color: EXCHANGES[k.exchange as keyof typeof EXCHANGES]?.color }}>
                  {k.exchange.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <span className="font-medium capitalize">{k.exchange}</span>
                  <span className="text-xs text-gray-500 ml-2">({k.label})</span>
                </div>
                {k.enabled ? (
                  <CheckCircle size={14} className="text-green-400" />
                ) : (
                  <XCircle size={14} className="text-red-400" />
                )}
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => toggleSecret(k.exchange)} className="p-1.5 bg-gray-800 rounded hover:bg-gray-700">
                  {showSecrets[k.exchange] ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
                <button onClick={() => handleRemove(k.exchange)} className="p-1.5 bg-red-500/20 text-red-400 rounded hover:bg-red-500/30">
                  <Trash2 size={14} />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="p-2 bg-gray-800/50 rounded">
                <span className="text-gray-500">API Key: </span>
                <span className="text-gray-300 font-mono">
                  {showSecrets[k.exchange] ? k.apiKey : maskKey(k.apiKey)}
                </span>
              </div>
              <div className="p-2 bg-gray-800/50 rounded">
                <span className="text-gray-500">Secret: </span>
                <span className="text-gray-300 font-mono">
                  {showSecrets[k.exchange] ? k.secretKey : maskKey(k.secretKey)}
                </span>
              </div>
            </div>

            <div className="flex gap-1 mt-2">
              {k.permissions.map(p => (
                <span key={p} className={`text-xs px-2 py-0.5 rounded ${
                  p === 'read' ? 'bg-blue-500/20 text-blue-400' :
                  p === 'trade' ? 'bg-green-500/20 text-green-400' :
                  'bg-red-500/20 text-red-400'
                }`}>
                  {p}
                </span>
              ))}
              <span className="text-xs text-gray-600 ml-auto">
                Added: {new Date(k.addedAt).toLocaleDateString()}
              </span>
            </div>
          </div>
        ))}

        {apiKeys.length === 0 && !showForm && (
          <div className="text-center py-12 bg-gray-900 rounded-xl border border-gray-800">
            <Key size={40} className="mx-auto text-gray-600 mb-4" />
            <p className="text-gray-400">No API keys configured</p>
            <p className="text-gray-500 text-sm mt-1">Paper trading works without API keys</p>
          </div>
        )}
      </div>

      {/* Add Button */}
      <button
        onClick={() => setShowForm(!showForm)}
        className="flex items-center gap-2 px-4 py-2 bg-yellow-500/20 text-yellow-400 rounded-lg border border-yellow-500/30 hover:bg-yellow-500/30"
      >
        {showForm ? '✕ Cancel' : <><Plus size={16} /> Add API Key</>}
      </button>

      {saved && (
        <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-lg text-green-400 text-sm flex items-center gap-2">
          <CheckCircle size={16} /> API key saved successfully!
        </div>
      )}

      {/* Add Form */}
      {showForm && (
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-5 space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Shield size={18} className="text-yellow-400" />
            <h3 className="font-medium">Add New API Key</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-gray-500">Exchange</label>
              <select value={exchange} onChange={e => setExchange(e.target.value)}
                className="w-full mt-1 px-3 py-2.5 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none">
                {Object.values(EXCHANGES).map(ex => (
                  <option key={ex.name} value={ex.name}>{ex.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs text-gray-500">Label / Name</label>
              <input value={label} onChange={e => setLabel(e.target.value)} placeholder="e.g. Main Account"
                className="w-full mt-1 px-3 py-2.5 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none focus:border-yellow-500" />
            </div>
            <div className="sm:col-span-2">
              <label className="text-xs text-gray-500">API Key</label>
              <input value={apiKey} onChange={e => setApiKey(e.target.value)} placeholder="Your API key"
                className="w-full mt-1 px-3 py-2.5 bg-gray-800 rounded-lg border border-gray-700 text-sm font-mono outline-none focus:border-yellow-500" />
            </div>
            <div className="sm:col-span-2">
              <label className="text-xs text-gray-500">Secret Key</label>
              <input value={secretKey} onChange={e => setSecretKey(e.target.value)} placeholder="Your secret key" type="password"
                className="w-full mt-1 px-3 py-2.5 bg-gray-800 rounded-lg border border-gray-700 text-sm font-mono outline-none focus:border-yellow-500" />
            </div>
            {exchange === 'okx' && (
              <div className="sm:col-span-2">
                <label className="text-xs text-gray-500">Passphrase (OKX only)</label>
                <input value={passphrase} onChange={e => setPassphrase(e.target.value)} placeholder="OKX passphrase" type="password"
                  className="w-full mt-1 px-3 py-2.5 bg-gray-800 rounded-lg border border-gray-700 text-sm font-mono outline-none focus:border-yellow-500" />
              </div>
            )}
            <div className="sm:col-span-2">
              <label className="text-xs text-gray-500">Permissions</label>
              <div className="flex gap-2 mt-1">
                {(['read', 'trade'] as const).map(p => (
                  <button key={p} onClick={() => {
                    setPermissions(prev => prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]);
                  }}
                    className={`px-4 py-2 rounded-lg text-xs font-medium border ${
                      permissions.includes(p)
                        ? p === 'read' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' : 'bg-green-500/20 text-green-400 border-green-500/30'
                        : 'bg-gray-800 text-gray-500 border-gray-700'
                    }`}>
                    {p === 'read' ? '👁 Read' : '💹 Trade'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button onClick={handleAdd} disabled={!apiKey || !secretKey || !label}
            className="w-full py-2.5 bg-yellow-600 hover:bg-yellow-500 rounded-lg font-medium text-sm disabled:opacity-50">
            Save API Key
          </button>
        </div>
      )}

      {/* Exchange Status */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
        <h3 className="text-sm text-gray-400 mb-3">Exchange Connection Status</h3>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {Object.values(EXCHANGES).map(ex => {
            const hasKey = apiKeys.some(k => k.exchange === ex.name);
            return (
              <div key={ex.name} className="text-center p-3 bg-gray-800/50 rounded-lg">
                <div className="text-xs font-medium capitalize" style={{ color: ex.color }}>{ex.label}</div>
                <div className={`text-xs mt-1 ${hasKey ? 'text-green-400' : 'text-gray-600'}`}>
                  {hasKey ? '🔑 Connected' : '📊 Public Only'}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
