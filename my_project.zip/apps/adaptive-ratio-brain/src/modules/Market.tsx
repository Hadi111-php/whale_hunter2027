import { useEffect, useState, useCallback } from 'react';
import { getKlines, getFuturesTicker, getOrderBook, getFundingRate, getOpenInterest, type FuturesTicker, type OrderBookEntry } from '../lib/binanceApi';
import { calcRSI, calcMACD, calcBollingerBands, calcEMA } from '../lib/indicators';
import { useAppStore } from '../store/appStore';
import { ResponsiveContainer, ComposedChart, Bar, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Search, Star, StarOff } from 'lucide-react';

export function Market() {
  const { selectedSymbol, setSelectedSymbol, watchlist, addToWatchlist, removeFromWatchlist } = useAppStore();
  const [ticker, setTicker] = useState<FuturesTicker | null>(null);
  const [chartData, setChartData] = useState<{ time: string; open: number; close: number; high: number; low: number; volume: number; ema9: number; ema21: number; bbUpper: number; bbLower: number }[]>([]);
  const [orderBook, setOrderBook] = useState<{ bids: OrderBookEntry[]; asks: OrderBookEntry[] }>({ bids: [], asks: [] });
  const [fundingRate, setFundingRate] = useState<string>('');
  const [openInterest, setOpenInterest] = useState<string>('');
  const [rsiValue, setRsiValue] = useState<number>(0);
  const [macdData, setMacdData] = useState<{ macd: number; signal: number; hist: number }>({ macd: 0, signal: 0, hist: 0 });
  const [timeframe, setTimeframe] = useState('1h');
  const [searchInput, setSearchInput] = useState('');
  const [loading, setLoading] = useState(true);

  const loadMarketData = useCallback(async () => {
    try {
      const [tickerData, klines, ob, fr, oi] = await Promise.all([
        getFuturesTicker(selectedSymbol),
        getKlines(selectedSymbol, timeframe, 100),
        getOrderBook(selectedSymbol, 15),
        getFundingRate(selectedSymbol),
        getOpenInterest(selectedSymbol),
      ]);

      setTicker(tickerData);
      setOrderBook(ob);
      setFundingRate(fr.fundingRate);
      setOpenInterest(oi.openInterest);

      const closes = klines.map(k => parseFloat(k.close));
      const highs = klines.map(k => parseFloat(k.high));
      const lows = klines.map(k => parseFloat(k.low));

      const rsi = calcRSI(closes);
      const macd = calcMACD(closes);
      const bb = calcBollingerBands(closes);
      const ema9 = calcEMA(closes, 9);
      const ema21 = calcEMA(closes, 21);

      setRsiValue(rsi[rsi.length - 1] || 0);
      setMacdData({
        macd: macd.macd[macd.macd.length - 1],
        signal: macd.signal[macd.signal.length - 1],
        hist: macd.histogram[macd.histogram.length - 1],
      });

      setChartData(klines.map((k, i) => ({
        time: new Date(k.openTime).toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit' }),
        open: parseFloat(k.open),
        close: parseFloat(k.close),
        high: highs[i],
        low: lows[i],
        volume: parseFloat(k.volume),
        ema9: ema9[i],
        ema21: ema21[i],
        bbUpper: bb.upper[i],
        bbLower: bb.lower[i],
      })));

      setLoading(false);
    } catch (err) {
      console.error('Market load error:', err);
      setLoading(false);
    }
  }, [selectedSymbol, timeframe]);

  useEffect(() => {
    setLoading(true);
    loadMarketData();
    const interval = setInterval(loadMarketData, 10000);
    return () => clearInterval(interval);
  }, [loadMarketData]);

  const handleSearch = () => {
    const sym = searchInput.trim().toUpperCase();
    if (sym && !sym.endsWith('USDT')) {
      setSelectedSymbol(sym + 'USDT');
    } else if (sym) {
      setSelectedSymbol(sym);
    }
    setSearchInput('');
  };

  const inWatchlist = watchlist.includes(selectedSymbol);
  const change = ticker ? parseFloat(ticker.priceChangePercent) : 0;

  return (
    <div className="space-y-4">
      {/* Symbol selector */}
      <div className="flex flex-wrap gap-3 items-center">
        <div className="flex items-center gap-2 bg-gray-900 border border-gray-700 rounded-lg px-3 py-2">
          <Search size={16} className="text-gray-400" />
          <input
            value={searchInput}
            onChange={e => setSearchInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSearch()}
            placeholder="Search symbol..."
            className="bg-transparent text-sm outline-none w-32"
          />
        </div>
        <div className="flex gap-1 flex-wrap">
          {['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'XRPUSDT', 'DOGEUSDT'].map(s => (
            <button
              key={s}
              onClick={() => setSelectedSymbol(s)}
              className={`px-3 py-1 rounded text-xs ${selectedSymbol === s ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30' : 'bg-gray-800 text-gray-400 hover:text-white'}`}
            >
              {s.replace('USDT', '')}
            </button>
          ))}
        </div>
        <button
          onClick={() => inWatchlist ? removeFromWatchlist(selectedSymbol) : addToWatchlist(selectedSymbol)}
          className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700"
        >
          {inWatchlist ? <Star size={16} className="text-yellow-400 fill-yellow-400" /> : <StarOff size={16} className="text-gray-500" />}
        </button>
      </div>

      {/* Ticker info */}
      {ticker && (
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          <InfoBox label="Symbol" value={selectedSymbol} />
          <InfoBox label="Price" value={`$${parseFloat(ticker.lastPrice).toLocaleString()}`} color={change >= 0 ? 'text-green-400' : 'text-red-400'} />
          <InfoBox label="24h Change" value={`${change >= 0 ? '+' : ''}${change.toFixed(2)}%`} color={change >= 0 ? 'text-green-400' : 'text-red-400'} />
          <InfoBox label="24h Volume" value={`$${(parseFloat(ticker.quoteVolume) / 1e6).toFixed(1)}M`} />
          <InfoBox label="Funding Rate" value={`${(parseFloat(fundingRate) * 100).toFixed(4)}%`} color={parseFloat(fundingRate) >= 0 ? 'text-green-400' : 'text-red-400'} />
          <InfoBox label="Open Interest" value={`${(parseFloat(openInterest)).toLocaleString()}`} />
          <InfoBox label="RSI(14)" value={rsiValue.toFixed(1)} color={rsiValue > 70 ? 'text-red-400' : rsiValue < 30 ? 'text-green-400' : 'text-gray-300'} />
        </div>
      )}

      {/* Timeframe selector */}
      <div className="flex gap-1">
        {['5m', '15m', '1h', '4h', '1d'].map(tf => (
          <button
            key={tf}
            onClick={() => setTimeframe(tf)}
            className={`px-3 py-1 rounded text-xs ${timeframe === tf ? 'bg-cyan-500/20 text-cyan-400' : 'bg-gray-800 text-gray-400'}`}
          >
            {tf}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="w-8 h-8 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Main Chart */}
          <div className="lg:col-span-2 bg-gray-900 rounded-xl border border-gray-800 p-4">
            <h3 className="text-sm text-gray-400 mb-2">{selectedSymbol} - {timeframe} Chart with EMA & Bollinger</h3>
            <ResponsiveContainer width="100%" height={350}>
              <ComposedChart data={chartData}>
                <CartesianGrid stroke="#1f2937" />
                <XAxis dataKey="time" tick={{ fill: '#6b7280', fontSize: 9 }} axisLine={false} interval={Math.floor(chartData.length / 8)} />
                <YAxis domain={['auto', 'auto']} tick={{ fill: '#6b7280', fontSize: 10 }} axisLine={false} width={70} />
                <Tooltip contentStyle={{ background: '#1f2937', border: '1px solid #374151', borderRadius: '8px', fontSize: '12px' }} />
                <Bar dataKey="volume" fill="#374151" yAxisId="right" opacity={0.3} />
                <Line type="monotone" dataKey="close" stroke="#06b6d4" dot={false} strokeWidth={2} />
                <Line type="monotone" dataKey="ema9" stroke="#f59e0b" dot={false} strokeWidth={1} strokeDasharray="3 3" />
                <Line type="monotone" dataKey="ema21" stroke="#ef4444" dot={false} strokeWidth={1} strokeDasharray="3 3" />
                <Line type="monotone" dataKey="bbUpper" stroke="#8b5cf6" dot={false} strokeWidth={1} opacity={0.5} />
                <Line type="monotone" dataKey="bbLower" stroke="#8b5cf6" dot={false} strokeWidth={1} opacity={0.5} />
                <YAxis yAxisId="right" orientation="right" hide />
              </ComposedChart>
            </ResponsiveContainer>
            <div className="flex gap-4 mt-2 text-xs">
              <span className="text-cyan-400">— Price</span>
              <span className="text-yellow-400">--- EMA9</span>
              <span className="text-red-400">--- EMA21</span>
              <span className="text-purple-400">— BB</span>
            </div>
          </div>

          {/* Order Book */}
          <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
            <h3 className="text-sm text-gray-400 mb-3">Order Book</h3>
            <div className="space-y-1 mb-3">
              <div className="flex justify-between text-xs text-gray-500 px-1">
                <span>Price</span><span>Qty</span>
              </div>
              {orderBook.asks.slice().reverse().map((a, i) => (
                <div key={`a${i}`} className="flex justify-between text-xs px-1 py-0.5 bg-red-500/5 rounded">
                  <span className="text-red-400">{parseFloat(a.price).toLocaleString()}</span>
                  <span className="text-gray-400">{parseFloat(a.qty).toFixed(3)}</span>
                </div>
              ))}
              {ticker && (
                <div className="text-center py-1 font-bold text-lg">
                  <span className={change >= 0 ? 'text-green-400' : 'text-red-400'}>
                    ${parseFloat(ticker.lastPrice).toLocaleString()}
                  </span>
                </div>
              )}
              {orderBook.bids.map((b, i) => (
                <div key={`b${i}`} className="flex justify-between text-xs px-1 py-0.5 bg-green-500/5 rounded">
                  <span className="text-green-400">{parseFloat(b.price).toLocaleString()}</span>
                  <span className="text-gray-400">{parseFloat(b.qty).toFixed(3)}</span>
                </div>
              ))}
            </div>

            {/* MACD Info */}
            <div className="border-t border-gray-800 pt-3 mt-3">
              <h4 className="text-xs text-gray-500 mb-2">MACD</h4>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div><span className="text-gray-500">MACD: </span><span className={macdData.macd >= 0 ? 'text-green-400' : 'text-red-400'}>{macdData.macd.toFixed(2)}</span></div>
                <div><span className="text-gray-500">Signal: </span><span>{macdData.signal.toFixed(2)}</span></div>
                <div><span className="text-gray-500">Hist: </span><span className={macdData.hist >= 0 ? 'text-green-400' : 'text-red-400'}>{macdData.hist.toFixed(2)}</span></div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function InfoBox({ label, value, color = 'text-white' }: { label: string; value: string; color?: string }) {
  return (
    <div className="bg-gray-900 rounded-lg border border-gray-800 p-3">
      <p className="text-xs text-gray-500">{label}</p>
      <p className={`text-sm font-semibold ${color}`}>{value}</p>
    </div>
  );
}
