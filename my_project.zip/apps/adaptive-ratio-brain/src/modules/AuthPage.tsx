import { useState } from 'react';
import { authService } from '../lib/auth';
import { Lock, User, Mail, Eye, EyeOff, LogIn, UserPlus, Brain } from 'lucide-react';

interface AuthPageProps {
  onAuth: () => void;
}

export function AuthPage({ onAuth }: AuthPageProps) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (mode === 'login') {
        const result = await authService.login(username, password);
        if (result.success) {
          onAuth();
        } else {
          setError(result.error || 'Login failed');
        }
      } else {
        if (!email.includes('@')) {
          setError('Invalid email address');
          setLoading(false);
          return;
        }
        const result = await authService.register(username, email, password);
        if (result.success) {
          onAuth();
        } else {
          setError(result.error || 'Registration failed');
        }
      }
    } catch (err) {
      setError('An error occurred');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-950 flex items-center justify-center p-4">
      {/* Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl"></div>
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="text-5xl">🐋</div>
            <Brain size={40} className="text-purple-400" />
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 bg-clip-text text-transparent">
            Whale Hunter 2027
          </h1>
          <p className="text-gray-500 mt-2 text-sm">
            Multi-Exchange Adaptive Brain Futures Platform
          </p>
          <div className="flex justify-center gap-3 mt-3">
            {['Binance', 'Bybit', 'OKX', 'Bitget', 'Kraken'].map(ex => (
              <span key={ex} className="text-xs text-gray-600 px-2 py-0.5 bg-gray-800/50 rounded">{ex}</span>
            ))}
          </div>
        </div>

        {/* Auth Card */}
        <div className="bg-gray-900 rounded-2xl border border-gray-800 p-6 shadow-2xl">
          {/* Tab Switch */}
          <div className="flex bg-gray-800 rounded-lg p-1 mb-6">
            <button
              onClick={() => { setMode('login'); setError(''); }}
              className={`flex-1 py-2.5 rounded-md text-sm font-medium transition ${
                mode === 'login' ? 'bg-cyan-500/20 text-cyan-400' : 'text-gray-400 hover:text-gray-300'
              }`}
            >
              <LogIn size={14} className="inline mr-2" />
              Login
            </button>
            <button
              onClick={() => { setMode('register'); setError(''); }}
              className={`flex-1 py-2.5 rounded-md text-sm font-medium transition ${
                mode === 'register' ? 'bg-purple-500/20 text-purple-400' : 'text-gray-400 hover:text-gray-300'
              }`}
            >
              <UserPlus size={14} className="inline mr-2" />
              Register
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Username */}
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Username</label>
              <div className="relative">
                <User size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  placeholder="Enter username"
                  required
                  autoComplete="username"
                  className="w-full pl-10 pr-4 py-3 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none focus:border-cyan-500 transition"
                />
              </div>
            </div>

            {/* Email (register only) */}
            {mode === 'register' && (
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Email</label>
                <div className="relative">
                  <Mail size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    type="email"
                    required
                    autoComplete="email"
                    className="w-full pl-10 pr-4 py-3 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none focus:border-cyan-500 transition"
                  />
                </div>
              </div>
            )}

            {/* Password */}
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Password</label>
              <div className="relative">
                <Lock size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  type={showPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                  className="w-full pl-10 pr-12 py-3 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none focus:border-cyan-500 transition"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm">
                {error}
              </div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className={`w-full py-3 rounded-lg font-medium text-sm transition disabled:opacity-50 ${
                mode === 'login'
                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500'
                  : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500'
              }`}
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Processing...
                </span>
              ) : mode === 'login' ? (
                <span className="flex items-center justify-center gap-2">
                  <LogIn size={16} /> Sign In
                </span>
              ) : (
                <span className="flex items-center justify-center gap-2">
                  <UserPlus size={16} /> Create Account
                </span>
              )}
            </button>
          </form>

          {/* Demo credentials */}
          <div className="mt-4 pt-4 border-t border-gray-800">
            <p className="text-xs text-gray-600 text-center">
              First registration becomes admin. Demo mode uses localStorage.
            </p>
          </div>
        </div>

        {/* Features list */}
        <div className="mt-6 grid grid-cols-2 gap-2">
          {[
            { icon: '🧠', text: 'Adaptive Brain' },
            { icon: '📊', text: 'Multi-Exchange' },
            { icon: '🪤', text: 'Trap Detection' },
            { icon: '📈', text: 'Paper Trading' },
            { icon: '🔄', text: 'Feedback Loop' },
            { icon: '🎯', text: 'Signal Scanner' },
          ].map(f => (
            <div key={f.text} className="flex items-center gap-2 text-xs text-gray-500 bg-gray-900/50 rounded-lg px-3 py-2">
              <span>{f.icon}</span>
              <span>{f.text}</span>
            </div>
          ))}
        </div>

        <p className="text-center text-xs text-gray-700 mt-4">
          v2027.2.0 • Whale Hunter Futures Platform
        </p>
      </div>
    </div>
  );
}
