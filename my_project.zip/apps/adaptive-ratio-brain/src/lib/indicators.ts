// Technical Indicators - Real calculations

export function calcSMA(data: number[], period: number): number[] {
  const result: number[] = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      result.push(NaN);
    } else {
      const slice = data.slice(i - period + 1, i + 1);
      result.push(slice.reduce((a, b) => a + b, 0) / period);
    }
  }
  return result;
}

export function calcEMA(data: number[], period: number): number[] {
  const k = 2 / (period + 1);
  const result: number[] = [data[0]];
  for (let i = 1; i < data.length; i++) {
    result.push(data[i] * k + result[i - 1] * (1 - k));
  }
  return result;
}

export function calcRSI(closes: number[], period: number = 14): number[] {
  const result: number[] = [];
  const gains: number[] = [];
  const losses: number[] = [];

  for (let i = 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    gains.push(diff > 0 ? diff : 0);
    losses.push(diff < 0 ? -diff : 0);
  }

  for (let i = 0; i < gains.length; i++) {
    if (i < period - 1) {
      result.push(NaN);
      continue;
    }
    if (i === period - 1) {
      const avgGain = gains.slice(0, period).reduce((a, b) => a + b, 0) / period;
      const avgLoss = losses.slice(0, period).reduce((a, b) => a + b, 0) / period;
      const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
      result.push(100 - 100 / (1 + rs));
    } else {
      const prevRSI = result[result.length - 1];
      const prevAvgGain = (100 / (100 - prevRSI) - 1) > 0
        ? gains.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0) / period
        : 0;
      const prevAvgLoss = losses.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0) / period;
      const rs = prevAvgLoss === 0 ? 100 : prevAvgGain / prevAvgLoss;
      result.push(100 - 100 / (1 + rs));
    }
  }

  return [NaN, ...result];
}

export function calcMACD(closes: number[], fast: number = 12, slow: number = 26, signal: number = 9): {
  macd: number[];
  signal: number[];
  histogram: number[];
} {
  const emaFast = calcEMA(closes, fast);
  const emaSlow = calcEMA(closes, slow);
  const macdLine = emaFast.map((v, i) => v - emaSlow[i]);
  const signalLine = calcEMA(macdLine, signal);
  const histogram = macdLine.map((v, i) => v - signalLine[i]);
  return { macd: macdLine, signal: signalLine, histogram };
}

export function calcBollingerBands(closes: number[], period: number = 20, stdDev: number = 2): {
  upper: number[];
  middle: number[];
  lower: number[];
} {
  const middle = calcSMA(closes, period);
  const upper: number[] = [];
  const lower: number[] = [];

  for (let i = 0; i < closes.length; i++) {
    if (i < period - 1) {
      upper.push(NaN);
      lower.push(NaN);
    } else {
      const slice = closes.slice(i - period + 1, i + 1);
      const mean = middle[i];
      const variance = slice.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / period;
      const std = Math.sqrt(variance);
      upper.push(mean + stdDev * std);
      lower.push(mean - stdDev * std);
    }
  }

  return { upper, middle, lower };
}

export function calcATR(highs: number[], lows: number[], closes: number[], period: number = 14): number[] {
  const tr: number[] = [highs[0] - lows[0]];
  for (let i = 1; i < highs.length; i++) {
    tr.push(Math.max(
      highs[i] - lows[i],
      Math.abs(highs[i] - closes[i - 1]),
      Math.abs(lows[i] - closes[i - 1])
    ));
  }
  return calcSMA(tr, period);
}

export function calcStochastic(highs: number[], lows: number[], closes: number[], period: number = 14): {
  k: number[];
  d: number[];
} {
  const kValues: number[] = [];
  for (let i = 0; i < closes.length; i++) {
    if (i < period - 1) {
      kValues.push(NaN);
    } else {
      const highSlice = highs.slice(i - period + 1, i + 1);
      const lowSlice = lows.slice(i - period + 1, i + 1);
      const hh = Math.max(...highSlice);
      const ll = Math.min(...lowSlice);
      kValues.push(hh === ll ? 50 : ((closes[i] - ll) / (hh - ll)) * 100);
    }
  }
  const dValues = calcSMA(kValues.filter(v => !isNaN(v)), 3);
  return { k: kValues, d: [...Array(kValues.length - dValues.length).fill(NaN), ...dValues] };
}

// Volume Profile calculation
export function calcVolumeProfile(highs: number[], lows: number[], volumes: number[], bins: number = 20): {
  price: number;
  volume: number;
}[] {
  const allMin = Math.min(...lows);
  const allMax = Math.max(...highs);
  const binSize = (allMax - allMin) / bins;
  const profile: { price: number; volume: number }[] = [];

  for (let b = 0; b < bins; b++) {
    const binLow = allMin + b * binSize;
    const binHigh = binLow + binSize;
    let totalVol = 0;
    for (let i = 0; i < highs.length; i++) {
      if (lows[i] <= binHigh && highs[i] >= binLow) {
        totalVol += volumes[i];
      }
    }
    profile.push({ price: (binLow + binHigh) / 2, volume: totalVol });
  }

  return profile;
}

// Signal generation based on multiple indicators
export type SignalStrength = 'STRONG_BUY' | 'BUY' | 'NEUTRAL' | 'SELL' | 'STRONG_SELL';

export function generateSignal(closes: number[], _highs: number[], _lows: number[], volumes: number[]): {
  signal: SignalStrength;
  score: number;
  reasons: string[];
} {
  const reasons: string[] = [];
  let score = 0;

  if (closes.length < 30) return { signal: 'NEUTRAL', score: 0, reasons: ['Not enough data'] };

  const rsi = calcRSI(closes);
  const lastRSI = rsi[rsi.length - 1];
  if (!isNaN(lastRSI)) {
    if (lastRSI < 30) { score += 2; reasons.push(`RSI Oversold: ${lastRSI.toFixed(1)}`); }
    else if (lastRSI < 40) { score += 1; reasons.push(`RSI Low: ${lastRSI.toFixed(1)}`); }
    else if (lastRSI > 70) { score -= 2; reasons.push(`RSI Overbought: ${lastRSI.toFixed(1)}`); }
    else if (lastRSI > 60) { score -= 1; reasons.push(`RSI High: ${lastRSI.toFixed(1)}`); }
  }

  const macd = calcMACD(closes);
  const lastMACD = macd.macd[macd.macd.length - 1];
  const lastSignal = macd.signal[macd.signal.length - 1];
  const prevMACD = macd.macd[macd.macd.length - 2];
  const prevSignalMACD = macd.signal[macd.signal.length - 2];
  if (prevMACD < prevSignalMACD && lastMACD > lastSignal) {
    score += 2; reasons.push('MACD Bullish Crossover');
  } else if (prevMACD > prevSignalMACD && lastMACD < lastSignal) {
    score -= 2; reasons.push('MACD Bearish Crossover');
  }

  const ema9 = calcEMA(closes, 9);
  const ema21 = calcEMA(closes, 21);
  const lastEma9 = ema9[ema9.length - 1];
  const lastEma21 = ema21[ema21.length - 1];
  if (lastEma9 > lastEma21) { score += 1; reasons.push('EMA9 > EMA21 (Bullish)'); }
  else { score -= 1; reasons.push('EMA9 < EMA21 (Bearish)'); }

  const bb = calcBollingerBands(closes);
  const lastClose = closes[closes.length - 1];
  const lastLower = bb.lower[bb.lower.length - 1];
  const lastUpper = bb.upper[bb.upper.length - 1];
  if (!isNaN(lastLower) && lastClose <= lastLower) { score += 1; reasons.push('Price at BB Lower Band'); }
  if (!isNaN(lastUpper) && lastClose >= lastUpper) { score -= 1; reasons.push('Price at BB Upper Band'); }

  // Volume analysis
  const avgVol = volumes.slice(-20).reduce((a, b) => a + b, 0) / 20;
  const lastVol = volumes[volumes.length - 1];
  if (lastVol > avgVol * 1.5) {
    reasons.push('High Volume Detected');
    if (score > 0) score += 1;
    else if (score < 0) score -= 1;
  }

  let signal: SignalStrength;
  if (score >= 4) signal = 'STRONG_BUY';
  else if (score >= 2) signal = 'BUY';
  else if (score <= -4) signal = 'STRONG_SELL';
  else if (score <= -2) signal = 'SELL';
  else signal = 'NEUTRAL';

  return { signal, score, reasons };
}
