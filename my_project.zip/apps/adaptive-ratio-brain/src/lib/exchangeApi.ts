// Multi-Exchange Futures API - Real Data
// Supports: Binance, Bybit, OKX, Bitget, Kraken
import { cache } from './cache';

// ============ TYPES ============
export interface ExchangeTicker {
  symbol: string;
  exchange: string;
  lastPrice: number;
  priceChangePercent: number;
  volume24h: number;
  quoteVolume24h: number;
  highPrice: number;
  lowPrice: number;
  openPrice: number;
  timestamp: number;
}

export interface ExchangeKline {
  openTime: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  closeTime: number;
  quoteVolume: number;
  trades: number;
}

export interface ExchangeOI {
  symbol: string;
  exchange: string;
  openInterest: number;
  timestamp: number;
}

export interface ExchangeFunding {
  symbol: string;
  exchange: string;
  fundingRate: number;
  nextFundingTime: number;
}

export interface ExchangeOrderBook {
  bids: { price: number; qty: number }[];
  asks: { price: number; qty: number }[];
  exchange: string;
  timestamp: number;
}

export type ExchangeName = 'binance' | 'bybit' | 'okx' | 'bitget' | 'kraken';

export interface ExchangeConfig {
  name: ExchangeName;
  label: string;
  enabled: boolean;
  futuresBaseUrl: string;
  color: string;
  symbolFormat: (symbol: string) => string;
}

// ============ EXCHANGE CONFIGS ============
export const EXCHANGES: Record<ExchangeName, ExchangeConfig> = {
  binance: {
    name: 'binance',
    label: 'Binance',
    enabled: true,
    futuresBaseUrl: 'https://fapi.binance.com',
    color: '#F0B90B',
    symbolFormat: (s) => s.toUpperCase(),
  },
  bybit: {
    name: 'bybit',
    label: 'Bybit',
    enabled: true,
    futuresBaseUrl: 'https://api.bybit.com',
    color: '#F7A600',
    symbolFormat: (s) => s.toUpperCase(),
  },
  okx: {
    name: 'okx',
    label: 'OKX',
    enabled: true,
    futuresBaseUrl: 'https://www.okx.com',
    color: '#000000',
    symbolFormat: (s) => {
      const base = s.replace('USDT', '');
      return `${base}-USDT-SWAP`;
    },
  },
  bitget: {
    name: 'bitget',
    label: 'Bitget',
    enabled: true,
    futuresBaseUrl: 'https://api.bitget.com',
    color: '#00C49F',
    symbolFormat: (s) => s.toUpperCase(),
  },
  kraken: {
    name: 'kraken',
    label: 'Kraken',
    enabled: true,
    futuresBaseUrl: 'https://futures.kraken.com',
    color: '#5741D9',
    symbolFormat: (s) => {
      const base = s.replace('USDT', '');
      return `PI_${base}USD`;
    },
  },
};

// ============ CACHED FETCH ============
async function cachedFetch<T>(key: string, url: string, ttlMs: number): Promise<T> {
  const cached = cache.get<T>(key);
  if (cached) return cached;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);

  try {
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeout);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    cache.set(key, data, ttlMs);
    return data as T;
  } catch (err) {
    clearTimeout(timeout);
    throw err;
  }
}

// ============ BINANCE ============
async function binanceTickers(): Promise<ExchangeTicker[]> {
  const data = await cachedFetch<any[]>(
    'binance_tickers',
    `${EXCHANGES.binance.futuresBaseUrl}/fapi/v1/ticker/24hr`,
    10000
  );
  return data
    .filter((t: any) => t.symbol.endsWith('USDT'))
    .map((t: any) => ({
      symbol: t.symbol,
      exchange: 'binance',
      lastPrice: parseFloat(t.lastPrice),
      priceChangePercent: parseFloat(t.priceChangePercent),
      volume24h: parseFloat(t.volume),
      quoteVolume24h: parseFloat(t.quoteVolume),
      highPrice: parseFloat(t.highPrice),
      lowPrice: parseFloat(t.lowPrice),
      openPrice: parseFloat(t.openPrice),
      timestamp: Date.now(),
    }));
}

async function binanceTicker(symbol: string): Promise<ExchangeTicker> {
  const t = await cachedFetch<any>(
    `binance_ticker_${symbol}`,
    `${EXCHANGES.binance.futuresBaseUrl}/fapi/v1/ticker/24hr?symbol=${symbol}`,
    5000
  );
  return {
    symbol: t.symbol,
    exchange: 'binance',
    lastPrice: parseFloat(t.lastPrice),
    priceChangePercent: parseFloat(t.priceChangePercent),
    volume24h: parseFloat(t.volume),
    quoteVolume24h: parseFloat(t.quoteVolume),
    highPrice: parseFloat(t.highPrice),
    lowPrice: parseFloat(t.lowPrice),
    openPrice: parseFloat(t.openPrice),
    timestamp: Date.now(),
  };
}

async function binanceKlines(symbol: string, interval: string, limit: number): Promise<ExchangeKline[]> {
  const raw = await cachedFetch<number[][]>(
    `binance_klines_${symbol}_${interval}_${limit}`,
    `${EXCHANGES.binance.futuresBaseUrl}/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`,
    15000
  );
  return raw.map(k => ({
    openTime: k[0],
    open: Number(k[1]),
    high: Number(k[2]),
    low: Number(k[3]),
    close: Number(k[4]),
    volume: Number(k[5]),
    closeTime: k[6],
    quoteVolume: Number(k[7]),
    trades: Number(k[8]),
  }));
}

async function binanceOI(symbol: string): Promise<ExchangeOI> {
  const data = await cachedFetch<any>(
    `binance_oi_${symbol}`,
    `${EXCHANGES.binance.futuresBaseUrl}/fapi/v1/openInterest?symbol=${symbol}`,
    15000
  );
  return {
    symbol,
    exchange: 'binance',
    openInterest: parseFloat(data.openInterest),
    timestamp: Date.now(),
  };
}

async function binanceFunding(symbol: string): Promise<ExchangeFunding> {
  const data = await cachedFetch<any>(
    `binance_funding_${symbol}`,
    `${EXCHANGES.binance.futuresBaseUrl}/fapi/v1/premiumIndex?symbol=${symbol}`,
    30000
  );
  return {
    symbol,
    exchange: 'binance',
    fundingRate: parseFloat(data.fundingRate),
    nextFundingTime: data.nextFundingTime,
  };
}

async function binanceOrderBook(symbol: string, limit = 20): Promise<ExchangeOrderBook> {
  const data = await cachedFetch<any>(
    `binance_ob_${symbol}_${limit}`,
    `${EXCHANGES.binance.futuresBaseUrl}/fapi/v1/depth?symbol=${symbol}&limit=${limit}`,
    3000
  );
  return {
    bids: data.bids.map((b: string[]) => ({ price: parseFloat(b[0]), qty: parseFloat(b[1]) })),
    asks: data.asks.map((a: string[]) => ({ price: parseFloat(a[0]), qty: parseFloat(a[1]) })),
    exchange: 'binance',
    timestamp: Date.now(),
  };
}

// ============ BYBIT ============
async function bybitTickers(): Promise<ExchangeTicker[]> {
  try {
    const data = await cachedFetch<any>(
      'bybit_tickers',
      `${EXCHANGES.bybit.futuresBaseUrl}/v5/market/tickers?category=linear`,
      10000
    );
    if (!data?.result?.list) return [];
    return data.result.list
      .filter((t: any) => t.symbol.endsWith('USDT'))
      .map((t: any) => ({
        symbol: t.symbol,
        exchange: 'bybit',
        lastPrice: parseFloat(t.lastPrice),
        priceChangePercent: parseFloat(t.price24hPcnt) * 100,
        volume24h: parseFloat(t.volume24h),
        quoteVolume24h: parseFloat(t.turnover24h),
        highPrice: parseFloat(t.highPrice24h),
        lowPrice: parseFloat(t.lowPrice24h),
        openPrice: parseFloat(t.prevPrice24h),
        timestamp: Date.now(),
      }));
  } catch {
    return [];
  }
}

async function bybitTicker(symbol: string): Promise<ExchangeTicker | null> {
  try {
    const data = await cachedFetch<any>(
      `bybit_ticker_${symbol}`,
      `${EXCHANGES.bybit.futuresBaseUrl}/v5/market/tickers?category=linear&symbol=${symbol}`,
      5000
    );
    if (!data?.result?.list?.[0]) return null;
    const t = data.result.list[0];
    return {
      symbol: t.symbol,
      exchange: 'bybit',
      lastPrice: parseFloat(t.lastPrice),
      priceChangePercent: parseFloat(t.price24hPcnt) * 100,
      volume24h: parseFloat(t.volume24h),
      quoteVolume24h: parseFloat(t.turnover24h),
      highPrice: parseFloat(t.highPrice24h),
      lowPrice: parseFloat(t.lowPrice24h),
      openPrice: parseFloat(t.prevPrice24h),
      timestamp: Date.now(),
    };
  } catch {
    return null;
  }
}

async function bybitKlines(symbol: string, interval: string, limit: number): Promise<ExchangeKline[]> {
  try {
    const intervalMap: Record<string, string> = {
      '1m': '1', '3m': '3', '5m': '5', '15m': '15', '30m': '30',
      '1h': '60', '2h': '120', '4h': '240', '1d': 'D', '1w': 'W',
    };
    const bybitInterval = intervalMap[interval] || '60';
    const data = await cachedFetch<any>(
      `bybit_klines_${symbol}_${interval}_${limit}`,
      `${EXCHANGES.bybit.futuresBaseUrl}/v5/market/kline?category=linear&symbol=${symbol}&interval=${bybitInterval}&limit=${limit}`,
      15000
    );
    if (!data?.result?.list) return [];
    return data.result.list
      .reverse()
      .map((k: string[]) => ({
        openTime: parseInt(k[0]),
        open: parseFloat(k[1]),
        high: parseFloat(k[2]),
        low: parseFloat(k[3]),
        close: parseFloat(k[4]),
        volume: parseFloat(k[5]),
        closeTime: parseInt(k[0]) + 60000,
        quoteVolume: parseFloat(k[6]),
        trades: 0,
      }));
  } catch {
    return [];
  }
}

async function bybitOI(symbol: string): Promise<ExchangeOI | null> {
  try {
    const data = await cachedFetch<any>(
      `bybit_oi_${symbol}`,
      `${EXCHANGES.bybit.futuresBaseUrl}/v5/market/open-interest?category=linear&symbol=${symbol}&intervalTime=5min&limit=1`,
      15000
    );
    if (!data?.result?.list?.[0]) return null;
    return {
      symbol,
      exchange: 'bybit',
      openInterest: parseFloat(data.result.list[0].openInterest),
      timestamp: Date.now(),
    };
  } catch {
    return null;
  }
}

async function bybitFunding(symbol: string): Promise<ExchangeFunding | null> {
  try {
    const data = await cachedFetch<any>(
      `bybit_funding_${symbol}`,
      `${EXCHANGES.bybit.futuresBaseUrl}/v5/market/tickers?category=linear&symbol=${symbol}`,
      30000
    );
    if (!data?.result?.list?.[0]) return null;
    const t = data.result.list[0];
    return {
      symbol,
      exchange: 'bybit',
      fundingRate: parseFloat(t.fundingRate || '0'),
      nextFundingTime: parseInt(t.nextFundingTime || '0'),
    };
  } catch {
    return null;
  }
}

// ============ OKX ============
async function okxTickers(): Promise<ExchangeTicker[]> {
  try {
    const data = await cachedFetch<any>(
      'okx_tickers',
      `${EXCHANGES.okx.futuresBaseUrl}/api/v5/market/tickers?instType=SWAP`,
      10000
    );
    if (!data?.data) return [];
    return data.data
      .filter((t: any) => t.instId.endsWith('-USDT-SWAP'))
      .map((t: any) => {
        const base = t.instId.replace('-USDT-SWAP', '');
        return {
          symbol: `${base}USDT`,
          exchange: 'okx',
          lastPrice: parseFloat(t.last),
          priceChangePercent: parseFloat(t.sodUtc8) > 0
            ? ((parseFloat(t.last) - parseFloat(t.sodUtc8)) / parseFloat(t.sodUtc8)) * 100
            : 0,
          volume24h: parseFloat(t.vol24h),
          quoteVolume24h: parseFloat(t.volCcy24h),
          highPrice: parseFloat(t.high24h),
          lowPrice: parseFloat(t.low24h),
          openPrice: parseFloat(t.sodUtc8),
          timestamp: Date.now(),
        };
      });
  } catch {
    return [];
  }
}

async function okxTicker(symbol: string): Promise<ExchangeTicker | null> {
  try {
    const instId = EXCHANGES.okx.symbolFormat(symbol);
    const data = await cachedFetch<any>(
      `okx_ticker_${symbol}`,
      `${EXCHANGES.okx.futuresBaseUrl}/api/v5/market/ticker?instId=${instId}`,
      5000
    );
    if (!data?.data?.[0]) return null;
    const t = data.data[0];
    return {
      symbol,
      exchange: 'okx',
      lastPrice: parseFloat(t.last),
      priceChangePercent: parseFloat(t.sodUtc8) > 0
        ? ((parseFloat(t.last) - parseFloat(t.sodUtc8)) / parseFloat(t.sodUtc8)) * 100
        : 0,
      volume24h: parseFloat(t.vol24h),
      quoteVolume24h: parseFloat(t.volCcy24h),
      highPrice: parseFloat(t.high24h),
      lowPrice: parseFloat(t.low24h),
      openPrice: parseFloat(t.sodUtc8),
      timestamp: Date.now(),
    };
  } catch {
    return null;
  }
}

async function okxOI(symbol: string): Promise<ExchangeOI | null> {
  try {
    const instId = EXCHANGES.okx.symbolFormat(symbol);
    const data = await cachedFetch<any>(
      `okx_oi_${symbol}`,
      `${EXCHANGES.okx.futuresBaseUrl}/api/v5/public/open-interest?instType=SWAP&instId=${instId}`,
      15000
    );
    if (!data?.data?.[0]) return null;
    return {
      symbol,
      exchange: 'okx',
      openInterest: parseFloat(data.data[0].oi),
      timestamp: Date.now(),
    };
  } catch {
    return null;
  }
}

async function okxFunding(symbol: string): Promise<ExchangeFunding | null> {
  try {
    const instId = EXCHANGES.okx.symbolFormat(symbol);
    const data = await cachedFetch<any>(
      `okx_funding_${symbol}`,
      `${EXCHANGES.okx.futuresBaseUrl}/api/v5/public/funding-rate?instId=${instId}`,
      30000
    );
    if (!data?.data?.[0]) return null;
    return {
      symbol,
      exchange: 'okx',
      fundingRate: parseFloat(data.data[0].fundingRate),
      nextFundingTime: parseInt(data.data[0].nextFundingTime || '0'),
    };
  } catch {
    return null;
  }
}

// ============ BITGET ============
async function bitgetTickers(): Promise<ExchangeTicker[]> {
  try {
    const data = await cachedFetch<any>(
      'bitget_tickers',
      `${EXCHANGES.bitget.futuresBaseUrl}/api/v2/mix/market/tickers?productType=USDT-FUTURES`,
      10000
    );
    if (!data?.data) return [];
    return data.data.map((t: any) => ({
      symbol: t.symbol.replace('USDT', '') + 'USDT',
      exchange: 'bitget',
      lastPrice: parseFloat(t.lastPr),
      priceChangePercent: parseFloat(t.change24h) * 100,
      volume24h: parseFloat(t.baseVolume),
      quoteVolume24h: parseFloat(t.quoteVolume),
      highPrice: parseFloat(t.high24h),
      lowPrice: parseFloat(t.low24h),
      openPrice: parseFloat(t.open24h || t.lastPr),
      timestamp: Date.now(),
    }));
  } catch {
    return [];
  }
}

async function bitgetOI(symbol: string): Promise<ExchangeOI | null> {
  try {
    const data = await cachedFetch<any>(
      `bitget_oi_${symbol}`,
      `${EXCHANGES.bitget.futuresBaseUrl}/api/v2/mix/market/open-interest?productType=USDT-FUTURES&symbol=${symbol}`,
      15000
    );
    if (!data?.data) return null;
    return {
      symbol,
      exchange: 'bitget',
      openInterest: parseFloat(data.data.size),
      timestamp: Date.now(),
    };
  } catch {
    return null;
  }
}

// ============ UNIFIED API ============

export async function getMultiExchangeTickers(exchanges?: ExchangeName[]): Promise<ExchangeTicker[]> {
  const enabled = exchanges || Object.values(EXCHANGES).filter(e => e.enabled).map(e => e.name);
  const results: ExchangeTicker[] = [];

  const promises: Promise<ExchangeTicker[]>[] = [];

  for (const ex of enabled) {
    switch (ex) {
      case 'binance':
        promises.push(binanceTickers().catch(() => []));
        break;
      case 'bybit':
        promises.push(bybitTickers().catch(() => []));
        break;
      case 'okx':
        promises.push(okxTickers().catch(() => []));
        break;
      case 'bitget':
        promises.push(bitgetTickers().catch(() => []));
        break;
      case 'kraken':
        // Kraken Futures has different API structure, skip for ticker
        promises.push(Promise.resolve([]));
        break;
    }
  }

  const allResults = await Promise.allSettled(promises);
  for (const r of allResults) {
    if (r.status === 'fulfilled') {
      results.push(...r.value);
    }
  }

  return results;
}

export async function getExchangeTicker(symbol: string, exchange: ExchangeName = 'binance'): Promise<ExchangeTicker | null> {
  switch (exchange) {
    case 'binance':
      return binanceTicker(symbol);
    case 'bybit':
      return bybitTicker(symbol);
    case 'okx':
      return okxTicker(symbol);
    default:
      return null;
  }
}

export async function getExchangeKlines(symbol: string, interval: string, limit: number, exchange: ExchangeName = 'binance'): Promise<ExchangeKline[]> {
  switch (exchange) {
    case 'binance':
      return binanceKlines(symbol, interval, limit);
    case 'bybit':
      return bybitKlines(symbol, interval, limit);
    default:
      return binanceKlines(symbol, interval, limit);
  }
}

export async function getExchangeOI(symbol: string, exchange: ExchangeName = 'binance'): Promise<ExchangeOI | null> {
  switch (exchange) {
    case 'binance':
      return binanceOI(symbol);
    case 'bybit':
      return bybitOI(symbol);
    case 'okx':
      return okxOI(symbol);
    case 'bitget':
      return bitgetOI(symbol);
    default:
      return null;
  }
}

export async function getExchangeFunding(symbol: string, exchange: ExchangeName = 'binance'): Promise<ExchangeFunding | null> {
  switch (exchange) {
    case 'binance':
      return binanceFunding(symbol);
    case 'bybit':
      return bybitFunding(symbol);
    case 'okx':
      return okxFunding(symbol);
    default:
      return null;
  }
}

export async function getExchangeOrderBook(symbol: string, limit = 20, exchange: ExchangeName = 'binance'): Promise<ExchangeOrderBook | null> {
  switch (exchange) {
    case 'binance':
      return binanceOrderBook(symbol, limit);
    default:
      return binanceOrderBook(symbol, limit);
  }
}

// ============ CROSS-EXCHANGE ANALYSIS ============

export interface CrossExchangeData {
  symbol: string;
  exchanges: {
    exchange: ExchangeName;
    price: number;
    oi: number;
    funding: number;
    volume: number;
    timestamp: number;
  }[];
  priceDivergence: number;  // max price diff %
  oiDivergence: number;
  fundingDivergence: number;
  leadExchange: ExchangeName | null;
}

export async function getCrossExchangeData(symbol: string, exchanges: ExchangeName[] = ['binance', 'bybit', 'okx']): Promise<CrossExchangeData> {
  const result: CrossExchangeData = {
    symbol,
    exchanges: [],
    priceDivergence: 0,
    oiDivergence: 0,
    fundingDivergence: 0,
    leadExchange: null,
  };

  const promises = exchanges.map(async (ex) => {
    try {
      const [ticker, oi, funding] = await Promise.all([
        getExchangeTicker(symbol, ex),
        getExchangeOI(symbol, ex).catch(() => null),
        getExchangeFunding(symbol, ex).catch(() => null),
      ]);

      if (ticker) {
        return {
          exchange: ex,
          price: ticker.lastPrice,
          oi: oi?.openInterest || 0,
          funding: funding?.fundingRate || 0,
          volume: ticker.volume24h,
          timestamp: ticker.timestamp,
        };
      }
    } catch {
      // skip
    }
    return null;
  });

  const settled = await Promise.allSettled(promises);
  for (const r of settled) {
    if (r.status === 'fulfilled' && r.value) {
      result.exchanges.push(r.value);
    }
  }

  // Calculate divergences
  if (result.exchanges.length >= 2) {
    const prices = result.exchanges.map(e => e.price).filter(p => p > 0);
    const ois = result.exchanges.map(e => e.oi).filter(o => o > 0);
    const fundings = result.exchanges.map(e => e.funding);

    if (prices.length >= 2) {
      const minP = Math.min(...prices);
      const maxP = Math.max(...prices);
      result.priceDivergence = minP > 0 ? ((maxP - minP) / minP) * 100 : 0;
    }

    if (ois.length >= 2) {
      const minO = Math.min(...ois);
      const maxO = Math.max(...ois);
      result.oiDivergence = minO > 0 ? ((maxO - minO) / minO) * 100 : 0;
    }

    if (fundings.length >= 2) {
      result.fundingDivergence = Math.max(...fundings) - Math.min(...fundings);
    }

    // Determine lead exchange (highest volume)
    const sorted = [...result.exchanges].sort((a, b) => b.volume - a.volume);
    result.leadExchange = sorted[0]?.exchange || null;
  }

  return result;
}

// ============ EXCHANGE STATUS ============

export async function checkExchangeStatus(exchange: ExchangeName): Promise<{
  exchange: ExchangeName;
  status: 'OK' | 'SLOW' | 'DOWN';
  latency: number;
}> {
  const start = Date.now();
  try {
    switch (exchange) {
      case 'binance':
        await fetch(`${EXCHANGES.binance.futuresBaseUrl}/fapi/v1/time`, { signal: AbortSignal.timeout(5000) });
        break;
      case 'bybit':
        await fetch(`${EXCHANGES.bybit.futuresBaseUrl}/v5/market/time`, { signal: AbortSignal.timeout(5000) });
        break;
      case 'okx':
        await fetch(`${EXCHANGES.okx.futuresBaseUrl}/api/v5/public/time`, { signal: AbortSignal.timeout(5000) });
        break;
      case 'bitget':
        await fetch(`${EXCHANGES.bitget.futuresBaseUrl}/api/v2/public/time`, { signal: AbortSignal.timeout(5000) });
        break;
      case 'kraken':
        await fetch(`https://api.kraken.com/0/public/Time`, { signal: AbortSignal.timeout(5000) });
        break;
    }
    const latency = Date.now() - start;
    return { exchange, status: latency < 1000 ? 'OK' : 'SLOW', latency };
  } catch {
    return { exchange, status: 'DOWN', latency: Date.now() - start };
  }
}

export async function checkAllExchangeStatus(): Promise<{ exchange: ExchangeName; status: 'OK' | 'SLOW' | 'DOWN'; latency: number }[]> {
  const exchanges = Object.values(EXCHANGES).filter(e => e.enabled).map(e => e.name);
  return Promise.all(exchanges.map(checkExchangeStatus));
}
