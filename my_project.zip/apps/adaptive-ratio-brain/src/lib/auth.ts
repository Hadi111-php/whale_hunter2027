// Authentication Module
// Ready for backend integration (FastAPI/Go)
// Currently uses localStorage, will switch to JWT + API

export interface User {
  id: string;
  username: string;
  email: string;
  role: 'admin' | 'user' | 'viewer';
  apiKeys: ExchangeApiKey[];
  settings: UserSettings;
  createdAt: number;
  lastLogin: number;
}

export interface ExchangeApiKey {
  exchange: string;
  apiKey: string;
  secretKey: string; // encrypted in production
  passphrase?: string; // for OKX
  label: string;
  permissions: ('read' | 'trade' | 'withdraw')[];
  enabled: boolean;
  addedAt: number;
}

export interface UserSettings {
  theme: 'dark' | 'light';
  language: 'en' | 'fa';
  notifications: boolean;
  telegramChatId?: string;
  defaultExchange: string;
  timezone: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  loading: boolean;
}

const STORAGE_KEY = 'wh_auth';
const USERS_KEY = 'wh_users';

// Hash password (simple for demo - use bcrypt in production)
function simpleHash(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  return Math.abs(hash).toString(36) + str.length.toString(36);
}

function generateToken(): string {
  return Array.from(crypto.getRandomValues(new Uint8Array(32)))
    .map(b => b.toString(16).padStart(2, '0')).join('');
}

class AuthService {
  private currentUser: User | null = null;
  private token: string | null = null;
  private listeners: Set<(state: AuthState) => void> = new Set();

  constructor() {
    this.loadSession();
  }

  subscribe(listener: (state: AuthState) => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    const state = this.getState();
    this.listeners.forEach(l => l(state));
  }

  getState(): AuthState {
    return {
      user: this.currentUser,
      token: this.token,
      isAuthenticated: !!this.currentUser,
      loading: false,
    };
  }

  private loadSession() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const session = JSON.parse(raw);
      if (session.token && session.userId) {
        const users = this.getUsers();
        const user = users.find(u => u.id === session.userId);
        if (user) {
          this.currentUser = user;
          this.token = session.token;
        }
      }
    } catch { /* ignore */ }
  }

  private saveSession() {
    if (this.currentUser && this.token) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({
        token: this.token,
        userId: this.currentUser.id,
      }));
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
  }

  private getUsers(): User[] {
    try {
      const raw = localStorage.getItem(USERS_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch { return []; }
  }

  private saveUsers(users: User[]) {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }

  async register(username: string, email: string, password: string): Promise<{ success: boolean; error?: string }> {
    const users = this.getUsers();

    if (users.find(u => u.username === username)) {
      return { success: false, error: 'Username already exists' };
    }
    if (users.find(u => u.email === email)) {
      return { success: false, error: 'Email already registered' };
    }
    if (password.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters' };
    }

    const user: User = {
      id: `U-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      username,
      email,
      role: users.length === 0 ? 'admin' : 'user', // first user is admin
      apiKeys: [],
      settings: {
        theme: 'dark',
        language: 'en',
        notifications: true,
        defaultExchange: 'binance',
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      },
      createdAt: Date.now(),
      lastLogin: Date.now(),
    };

    // Store password hash separately
    const pwStore = JSON.parse(localStorage.getItem('wh_pw') || '{}');
    pwStore[user.id] = simpleHash(password);
    localStorage.setItem('wh_pw', JSON.stringify(pwStore));

    users.push(user);
    this.saveUsers(users);

    this.currentUser = user;
    this.token = generateToken();
    this.saveSession();
    this.notify();

    return { success: true };
  }

  async login(username: string, password: string): Promise<{ success: boolean; error?: string }> {
    const users = this.getUsers();
    const user = users.find(u => u.username === username || u.email === username);

    if (!user) {
      return { success: false, error: 'User not found' };
    }

    const pwStore = JSON.parse(localStorage.getItem('wh_pw') || '{}');
    const storedHash = pwStore[user.id];

    if (!storedHash || storedHash !== simpleHash(password)) {
      return { success: false, error: 'Invalid password' };
    }

    user.lastLogin = Date.now();
    this.saveUsers(users);

    this.currentUser = user;
    this.token = generateToken();
    this.saveSession();
    this.notify();

    return { success: true };
  }

  logout() {
    this.currentUser = null;
    this.token = null;
    this.saveSession();
    this.notify();
  }

  updateProfile(updates: Partial<User>) {
    if (!this.currentUser) return;
    const users = this.getUsers();
    const idx = users.findIndex(u => u.id === this.currentUser!.id);
    if (idx >= 0) {
      users[idx] = { ...users[idx], ...updates };
      this.currentUser = users[idx];
      this.saveUsers(users);
      this.notify();
    }
  }

  addApiKey(key: ExchangeApiKey) {
    if (!this.currentUser) return;
    const users = this.getUsers();
    const idx = users.findIndex(u => u.id === this.currentUser!.id);
    if (idx >= 0) {
      users[idx].apiKeys.push(key);
      this.currentUser = users[idx];
      this.saveUsers(users);
      this.notify();
    }
  }

  removeApiKey(exchange: string) {
    if (!this.currentUser) return;
    const users = this.getUsers();
    const idx = users.findIndex(u => u.id === this.currentUser!.id);
    if (idx >= 0) {
      users[idx].apiKeys = users[idx].apiKeys.filter(k => k.exchange !== exchange);
      this.currentUser = users[idx];
      this.saveUsers(users);
      this.notify();
    }
  }

  updateSettings(settings: Partial<UserSettings>) {
    if (!this.currentUser) return;
    const users = this.getUsers();
    const idx = users.findIndex(u => u.id === this.currentUser!.id);
    if (idx >= 0) {
      users[idx].settings = { ...users[idx].settings, ...settings };
      this.currentUser = users[idx];
      this.saveUsers(users);
      this.notify();
    }
  }

  isAdmin(): boolean {
    return this.currentUser?.role === 'admin';
  }

  getApiKey(exchange: string): ExchangeApiKey | undefined {
    return this.currentUser?.apiKeys.find(k => k.exchange === exchange && k.enabled);
  }
}

export const authService = new AuthService();
