// Binance Futures API - Real Data
import { cache } from './cache';

const BINANCE_FUTURES_BASE = 'https://fapi.binance.com';
const BINANCE_SPOT_BASE = 'https://api.binance.com';

export interface FuturesTicker {
  symbol: string;
  lastPrice: string;
  priceChangePercent: string;
  volume: string;
  quoteVolume: string;
  highPrice: string;
  lowPrice: string;
  openPrice: string;
  count: number;
}

export interface Kline {
  openTime: number;
  open: string;
  high: string;
  low: string;
  close: string;
  volume: string;
  closeTime: number;
  quoteVolume: string;
  trades: number;
}

export interface OrderBookEntry {
  price: string;
  qty: string;
}

export interface FundingRate {
  symbol: string;
  fundingRate: string;
  fundingTime: number;
}

export interface OpenInterest {
  symbol: string;
  openInterest: string;
}

export interface LongShortRatio {
  symbol: string;
  longShortRatio: string;
  longAccount: string;
  shortAccount: string;
  timestamp: number;
}

// Fetch with cache wrapper
async function cachedFetch<T>(key: string, url: string, ttlMs: number): Promise<T> {
  const cached = cache.get<T>(key);
  if (cached) return cached;

  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    cache.set(key, data, ttlMs);
    return data as T;
  } catch (err) {
    console.error(`API Error [${key}]:`, err);
    throw err;
  }
}

// Get all futures tickers (24h)
export async function getFuturesTickers(): Promise<FuturesTicker[]> {
  return cachedFetch<FuturesTicker[]>(
    'futures_tickers',
    `${BINANCE_FUTURES_BASE}/fapi/v1/ticker/24hr`,
    10000 // 10s cache
  );
}

// Get single ticker
export async function getFuturesTicker(symbol: string): Promise<FuturesTicker> {
  return cachedFetch<FuturesTicker>(
    `ticker_${symbol}`,
    `${BINANCE_FUTURES_BASE}/fapi/v1/ticker/24hr?symbol=${symbol}`,
    5000
  );
}

// Get klines/candlesticks
export async function getKlines(symbol: string, interval: string = '1h', limit: number = 100): Promise<Kline[]> {
  const raw = await cachedFetch<number[][]>(
    `klines_${symbol}_${interval}_${limit}`,
    `${BINANCE_FUTURES_BASE}/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`,
    30000
  );
  return raw.map(k => ({
    openTime: k[0],
    open: String(k[1]),
    high: String(k[2]),
    low: String(k[3]),
    close: String(k[4]),
    volume: String(k[5]),
    closeTime: k[6],
    quoteVolume: String(k[7]),
    trades: k[8],
  }));
}

// Get order book depth
export async function getOrderBook(symbol: string, limit: number = 20): Promise<{ bids: OrderBookEntry[]; asks: OrderBookEntry[] }> {
  const data = await cachedFetch<{ bids: string[][]; asks: string[][] }>(
    `orderbook_${symbol}_${limit}`,
    `${BINANCE_FUTURES_BASE}/fapi/v1/depth?symbol=${symbol}&limit=${limit}`,
    3000
  );
  return {
    bids: data.bids.map(b => ({ price: b[0], qty: b[1] })),
    asks: data.asks.map(a => ({ price: a[0], qty: a[1] })),
  };
}

// Get funding rate
export async function getFundingRate(symbol: string): Promise<FundingRate> {
  return cachedFetch<FundingRate>(
    `funding_${symbol}`,
    `${BINANCE_FUTURES_BASE}/fapi/v1/premiumIndex?symbol=${symbol}`,
    30000
  );
}

// Get open interest
export async function getOpenInterest(symbol: string): Promise<OpenInterest> {
  return cachedFetch<OpenInterest>(
    `oi_${symbol}`,
    `${BINANCE_FUTURES_BASE}/fapi/v1/openInterest?symbol=${symbol}`,
    15000
  );
}

// Get top long/short ratio
export async function getLongShortRatio(symbol: string, period: string = '1h', limit: number = 30): Promise<LongShortRatio[]> {
  return cachedFetch<LongShortRatio[]>(
    `lsr_${symbol}_${period}`,
    `${BINANCE_FUTURES_BASE}/futures/data/globalLongShortAccountRatio?symbol=${symbol}&period=${period}&limit=${limit}`,
    60000
  );
}

// Get recent trades
export async function getRecentTrades(symbol: string, limit: number = 50): Promise<{ price: string; qty: string; time: number; isBuyerMaker: boolean }[]> {
  return cachedFetch(
    `trades_${symbol}_${limit}`,
    `${BINANCE_FUTURES_BASE}/fapi/v1/trades?symbol=${symbol}&limit=${limit}`,
    5000
  );
}

// Get exchange info
export async function getExchangeInfo(): Promise<{ symbols: { symbol: string; pair: string; status: string; baseAsset: string; quoteAsset: string }[] }> {
  return cachedFetch(
    'exchange_info',
    `${BINANCE_FUTURES_BASE}/fapi/v1/exchangeInfo`,
    300000 // 5 min cache
  );
}

// Get server time
export async function getServerTime(): Promise<{ serverTime: number }> {
  return cachedFetch(
    'server_time',
    `${BINANCE_FUTURES_BASE}/fapi/v1/time`,
    1000
  );
}

// CoinGecko for global market data (fallback/extra)
export async function getGlobalMarketData(): Promise<{
  total_market_cap: number;
  total_volume: number;
  btc_dominance: number;
  active_cryptocurrencies: number;
}> {
  const cached = cache.get<{ total_market_cap: number; total_volume: number; btc_dominance: number; active_cryptocurrencies: number }>('global_market');
  if (cached) return cached;

  try {
    const res = await fetch('https://api.coingecko.com/api/v3/global');
    const json = await res.json();
    const data = {
      total_market_cap: json.data.total_market_cap.usd,
      total_volume: json.data.total_volume.usd,
      btc_dominance: json.data.market_cap_percentage.btc,
      active_cryptocurrencies: json.data.active_cryptocurrencies,
    };
    cache.set('global_market', data, 60000);
    return data;
  } catch {
    return {
      total_market_cap: 0,
      total_volume: 0,
      btc_dominance: 0,
      active_cryptocurrencies: 0,
    };
  }
}

// Spot price for reference
export async function getSpotPrice(symbol: string): Promise<{ symbol: string; price: string }> {
  return cachedFetch(
    `spot_${symbol}`,
    `${BINANCE_SPOT_BASE}/api/v3/ticker/price?symbol=${symbol}`,
    5000
  );
}
