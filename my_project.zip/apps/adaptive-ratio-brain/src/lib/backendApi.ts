// Backend API Layer
// This module is ready for FastAPI/Go backend integration
// Currently falls back to direct exchange API calls
// When backend is deployed, set BACKEND_URL in settings

import { cache } from './cache';

// Backend configuration
const getBackendUrl = (): string | null => {
  try {
    const settings = JSON.parse(localStorage.getItem('wh_backend') || '{}');
    return settings.url || null;
  } catch { return null; }
};

export function setBackendUrl(url: string) {
  localStorage.setItem('wh_backend', JSON.stringify({ url, updatedAt: Date.now() }));
}

export function getBackendConfig() {
  try {
    return JSON.parse(localStorage.getItem('wh_backend') || '{}');
  } catch { return {}; }
}

// Generic backend fetch with auth
async function backendFetch<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const baseUrl = getBackendUrl();
  if (!baseUrl) throw new Error('Backend URL not configured');

  const token = (() => {
    try {
      const auth = JSON.parse(localStorage.getItem('wh_auth') || '{}');
      return auth.token || '';
    } catch { return ''; }
  })();

  const res = await fetch(`${baseUrl}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      ...(options.headers || {}),
    },
  });

  if (!res.ok) {
    const error = await res.text().catch(() => `HTTP ${res.status}`);
    throw new Error(error);
  }

  return res.json();
}

// ============ BACKEND ENDPOINTS ============

// Health check
export async function checkBackendHealth(): Promise<{
  status: 'ok' | 'error';
  version: string;
  uptime: number;
  exchanges: { name: string; status: string }[];
  brain: { status: string; symbols: number };
  database: { status: string; size: string };
  redis: { status: string };
}> {
  const cacheKey = 'backend_health';
  const cached = cache.get<any>(cacheKey);
  if (cached) return cached;

  try {
    const data = await backendFetch<any>('/api/health');
    cache.set(cacheKey, data, 5000);
    return data;
  } catch {
    return {
      status: 'error',
      version: 'N/A',
      uptime: 0,
      exchanges: [],
      brain: { status: 'offline', symbols: 0 },
      database: { status: 'offline', size: '0' },
      redis: { status: 'offline' },
    };
  }
}

// Get tickers from backend (with Redis cache)
export async function getBackendTickers(exchange?: string): Promise<any[]> {
  try {
    const params = exchange ? `?exchange=${exchange}` : '';
    return await backendFetch<any[]>(`/api/tickers${params}`);
  } catch { return []; }
}

// Get brain signals from backend
export async function getBackendBrainSignals(symbols?: string[]): Promise<any[]> {
  try {
    const params = symbols ? `?symbols=${symbols.join(',')}` : '';
    return await backendFetch<any[]>(`/api/brain/signals${params}`);
  } catch { return []; }
}

// Get brain learnings
export async function getBackendLearnings(symbol?: string): Promise<any> {
  try {
    const params = symbol ? `?symbol=${symbol}` : '';
    return await backendFetch<any>(`/api/brain/learnings${params}`);
  } catch { return null; }
}

// Submit paper trade
export async function submitBackendTrade(trade: {
  symbol: string;
  exchange: string;
  side: 'LONG' | 'SHORT';
  quantity: number;
  leverage: number;
  stopLossPercent: number;
  takeProfitPercent: number;
}): Promise<any> {
  return backendFetch('/api/trades/paper', {
    method: 'POST',
    body: JSON.stringify(trade),
  });
}

// Close paper trade
export async function closeBackendTrade(tradeId: string): Promise<any> {
  return backendFetch(`/api/trades/paper/${tradeId}/close`, {
    method: 'POST',
  });
}

// Get trade history
export async function getBackendTradeHistory(): Promise<any[]> {
  try {
    return await backendFetch<any[]>('/api/trades/history');
  } catch { return []; }
}

// Auth endpoints
export async function backendLogin(username: string, password: string): Promise<{ token: string; user: any }> {
  return backendFetch('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ username, password }),
  });
}

export async function backendRegister(username: string, email: string, password: string): Promise<{ token: string; user: any }> {
  return backendFetch('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify({ username, email, password }),
  });
}

// Save API keys (encrypted on backend)
export async function saveBackendApiKey(exchangeKey: {
  exchange: string;
  apiKey: string;
  secretKey: string;
  passphrase?: string;
  label: string;
}): Promise<any> {
  return backendFetch('/api/keys', {
    method: 'POST',
    body: JSON.stringify(exchangeKey),
  });
}

// ============ CONNECTION CHECK ============

export async function isBackendAvailable(): Promise<boolean> {
  const url = getBackendUrl();
  if (!url) return false;
  
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3000);
    const res = await fetch(`${url}/api/health`, {
      signal: controller.signal,
    });
    clearTimeout(timeout);
    return res.ok;
  } catch {
    return false;
  }
}

// ============ WEBSOCKET ============

export class BackendWebSocket {
  private ws: WebSocket | null = null;
  private listeners: Map<string, Set<(data: any) => void>> = new Map();
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 10;
  private reconnectDelay = 1000;

  connect() {
    const url = getBackendUrl();
    if (!url) return;

    const wsUrl = url.replace('http', 'ws') + '/ws';

    try {
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        console.log('[WS] Connected to backend');
        this.reconnectAttempts = 0;
        this.emit('connection', { status: 'connected' });
      };

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          this.emit(data.type || 'message', data);
        } catch { /* ignore */ }
      };

      this.ws.onclose = () => {
        console.log('[WS] Disconnected');
        this.emit('connection', { status: 'disconnected' });
        this.tryReconnect();
      };

      this.ws.onerror = () => {
        this.emit('connection', { status: 'error' });
      };
    } catch {
      this.tryReconnect();
    }
  }

  private tryReconnect() {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);
      setTimeout(() => this.connect(), delay);
    }
  }

  on(event: string, callback: (data: any) => void) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);
    return () => this.listeners.get(event)?.delete(callback);
  }

  private emit(event: string, data: any) {
    this.listeners.get(event)?.forEach(cb => cb(data));
  }

  send(type: string, data: any) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type, ...data }));
    }
  }

  disconnect() {
    this.maxReconnectAttempts = 0;
    this.ws?.close();
    this.ws = null;
  }

  get isConnected() {
    return this.ws?.readyState === WebSocket.OPEN;
  }
}

export const backendWS = new BackendWebSocket();
