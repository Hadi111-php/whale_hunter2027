import { useAppStore, type AppPage } from '../store/appStore';
import { authService } from '../lib/auth';
import { getStorageStats, downloadBackup } from '../lib/storageWarning';
import { isBackendAvailable } from '../lib/backendApi';
import {
  LayoutDashboard, BarChart3, Radio, ShieldCheck, Bot, Settings, Menu, X, Brain, HeartPulse,
  Key, LogOut, User, Database, AlertTriangle, Download, HardDrive
} from 'lucide-react';
import { useState, useEffect } from 'react';

const navItems: { id: AppPage; label: string; labelFa: string; icon: React.ReactNode }[] = [
  { id: 'dashboard', label: 'Dashboard', labelFa: 'داشبورد', icon: <LayoutDashboard size={20} /> },
  { id: 'brain', label: 'Brain', labelFa: 'مغز تحلیلی', icon: <Brain size={20} /> },
  { id: 'market', label: 'Market', labelFa: 'بازار', icon: <BarChart3 size={20} /> },
  { id: 'signals', label: 'Signals', labelFa: 'سیگنال', icon: <Radio size={20} /> },
  { id: 'validation', label: 'Validation', labelFa: 'اعتبارسنجی', icon: <ShieldCheck size={20} /> },
  { id: 'autotrade', label: 'Auto Trade', labelFa: 'اتوترید', icon: <Bot size={20} /> },
  { id: 'datainject', label: 'Data Inject', labelFa: 'تزریق داده', icon: <Database size={20} /> },
  { id: 'apikeys', label: 'API Keys', labelFa: 'کلیدها', icon: <Key size={20} /> },
  { id: 'health', label: 'Health', labelFa: 'سلامت سیستم', icon: <HeartPulse size={20} /> },
  { id: 'settings', label: 'Settings', labelFa: 'تنظیمات', icon: <Settings size={20} /> },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const { currentPage, setPage } = useAppStore();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [storageWarning, setStorageWarning] = useState(false);
  const [storagePct, setStoragePct] = useState(0);
  const [backendConnected, setBackendConnected] = useState(false);
  const [showStorageBanner, setShowStorageBanner] = useState(true);
  const user = authService.getState().user;

  useEffect(() => {
    // Check storage usage
    const stats = getStorageStats();
    setStoragePct(Math.round(stats.usagePercent));
    setStorageWarning(stats.isCritical);

    // Check backend
    isBackendAvailable().then(ok => setBackendConnected(ok));

    // Re-check every 60 seconds
    const interval = setInterval(() => {
      const s = getStorageStats();
      setStoragePct(Math.round(s.usagePercent));
      setStorageWarning(s.isCritical);
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const handleLogout = () => {
    if (confirm('Logout?')) {
      authService.logout();
    }
  };

  return (
    <div className="flex h-screen bg-gray-950 text-white overflow-hidden">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-gray-900 border-r border-gray-800 transform transition-transform lg:transform-none ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-800">
          <div className="text-3xl">🐋</div>
          <div>
            <h1 className="text-lg font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
              Whale Hunter
            </h1>
            <p className="text-xs text-gray-500">2027 - Futures Edition</p>
          </div>
          <button className="lg:hidden ml-auto" onClick={() => setSidebarOpen(false)}>
            <X size={20} />
          </button>
        </div>

        {/* User Info */}
        {user && (
          <div className="px-4 py-3 border-b border-gray-800">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-purple-500 flex items-center justify-center">
                <User size={14} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{user.username}</p>
                <p className="text-xs text-gray-500 capitalize">{user.role}</p>
              </div>
              <button onClick={handleLogout} className="p-1.5 rounded hover:bg-gray-800 text-gray-500 hover:text-red-400" title="Logout">
                <LogOut size={14} />
              </button>
            </div>
          </div>
        )}

        <nav className="p-3 space-y-1 overflow-y-auto" style={{ maxHeight: 'calc(100vh - 200px)' }}>
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => { setPage(item.id); setSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm transition-all ${
                currentPage === item.id
                  ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
              }`}
            >
              {item.icon}
              <span>{item.label}</span>
              <span className="text-xs text-gray-600 ml-auto">{item.labelFa}</span>
            </button>
          ))}
        </nav>

        <div className="absolute bottom-4 left-4 right-4 space-y-2">
          {/* Storage status */}
          <div className={`p-2.5 rounded-lg border ${backendConnected ? 'bg-green-500/5 border-green-500/20' : 'bg-yellow-500/5 border-yellow-500/20'}`}>
            <div className="flex items-center gap-2 mb-1">
              {backendConnected ? (
                <>
                  <div className="w-2 h-2 rounded-full bg-green-400"></div>
                  <span className="text-xs text-green-400">Backend + DB Connected</span>
                </>
              ) : (
                <>
                  <AlertTriangle size={12} className="text-yellow-400" />
                  <span className="text-xs text-yellow-400">Browser Storage Only</span>
                </>
              )}
            </div>
            {!backendConnected && (
              <div className="mt-1">
                <div className="flex justify-between text-xs text-gray-500 mb-0.5">
                  <span>localStorage</span>
                  <span>{storagePct}%</span>
                </div>
                <div className="w-full h-1 bg-gray-700 rounded-full">
                  <div className={`h-1 rounded-full transition-all ${storagePct > 80 ? 'bg-red-400' : storagePct > 50 ? 'bg-yellow-400' : 'bg-green-400'}`} style={{ width: `${Math.min(100, storagePct)}%` }} />
                </div>
              </div>
            )}
          </div>
          
          {/* Exchange status */}
          <div className="p-2.5 bg-gray-800/50 rounded-lg border border-gray-700">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></div>
              <span className="text-xs text-green-400">Multi-Exchange</span>
            </div>
            <p className="text-xs text-gray-500">Binance • Bybit • OKX • Bitget</p>
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="h-14 bg-gray-900/80 backdrop-blur border-b border-gray-800 flex items-center px-4 gap-4">
          <button className="lg:hidden" onClick={() => setSidebarOpen(true)}>
            <Menu size={20} />
          </button>
          <h2 className="text-sm font-medium text-gray-300">
            {navItems.find(n => n.id === currentPage)?.label} - {navItems.find(n => n.id === currentPage)?.labelFa}
          </h2>
          <div className="ml-auto flex items-center gap-3">
            <div className="hidden sm:block text-xs text-gray-500">
              {new Date().toLocaleString('fa-IR')}
            </div>
          </div>
        </header>
        {/* Storage Warning Banner */}
        {showStorageBanner && !backendConnected && (
          <div className={`px-4 py-2.5 flex items-center gap-3 text-sm border-b ${storageWarning ? 'bg-red-500/10 border-red-500/20 text-red-400' : 'bg-yellow-500/10 border-yellow-500/20 text-yellow-400'}`}>
            <HardDrive size={16} />
            <div className="flex-1">
              <span className="font-medium">
                {storageWarning ? '⚠️ Storage Critical!' : '💾 Data in Browser Memory'}
              </span>
              <span className="text-xs ml-2 opacity-80">
                {backendConnected 
                  ? '✅ Backend connected - data safe in PostgreSQL'
                  : `localStorage: ${storagePct}% used • Data lost if cache cleared • Deploy backend for persistence`
                }
              </span>
            </div>
            <button 
              onClick={downloadBackup}
              className="flex items-center gap-1 px-2.5 py-1 bg-yellow-500/20 rounded text-xs hover:bg-yellow-500/30"
              title="Download backup of all data"
            >
              <Download size={12} /> Backup
            </button>
            <button onClick={() => setShowStorageBanner(false)} className="opacity-50 hover:opacity-100">
              <X size={14} />
            </button>
          </div>
        )}
        
        <main className="flex-1 overflow-auto p-4">
          {children}
        </main>
      </div>
    </div>
  );
}
