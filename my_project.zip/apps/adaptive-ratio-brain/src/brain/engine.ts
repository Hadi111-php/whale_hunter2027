// Adaptive Ratio Brain Engine - Multi-Exchange
// Core analysis engine for futures market trap detection
// Per-symbol per-exchange learning with 12h and 30d cycles

import type {
  RatioData, DivergenceTrap, SignalFeedback, ActiveRatio,
  MemoryShortTerm, MemoryLongTerm, BrainOutput, BrainConfig,
  MarketState, PaperTrade, SymbolLearning, LearningRecord,
  ReversalPattern
} from './types';
import { DEFAULT_BRAIN_CONFIG } from './types';
import type { ExchangeName } from '../lib/exchangeApi';

function std(arr: number[]): number {
  if (arr.length === 0) return 0;
  const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
  const variance = arr.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / arr.length;
  return Math.sqrt(variance);
}

function avg(arr: number[]): number {
  if (arr.length === 0) return 0;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function symbolExKey(symbol: string, exchange: ExchangeName): string {
  return `${symbol}:${exchange}`;
}

export class AdaptiveRatioBrain {
  private config: BrainConfig;
  private shortTermMemory: Map<string, RatioData[]> = new Map();
  private longTermMemory: Map<string, RatioData[]> = new Map();
  private feedbackLog: SignalFeedback[] = [];
  private activeRatios: ActiveRatio[] = [];
  private paperTrades: PaperTrade[] = [];
  private outputs: Map<string, BrainOutput> = new Map();
  private symbolLearnings: Map<string, SymbolLearning> = new Map();
  private lastLearning12h: Map<string, number> = new Map();
  private lastLearning30d: number = 0;
  private listeners: Set<() => void> = new Set();

  constructor(config?: Partial<BrainConfig>) {
    this.config = { ...DEFAULT_BRAIN_CONFIG, ...config };
    this.initializeRatios();
    this.loadFromStorage();
  }

  private initializeRatios() {
    const defaultRatios: ActiveRatio[] = [
      { id: 'oi_ratio', name: 'OI Ratio', successCount: 0, failCount: 0, weight: 1.0, lastUsed: Date.now(), status: 'ACTIVE', avgConfirmationCandles: 0 },
      { id: 'vol_spike', name: 'Volume Spike Ratio', successCount: 0, failCount: 0, weight: 1.0, lastUsed: Date.now(), status: 'ACTIVE', avgConfirmationCandles: 0 },
      { id: 'price_momentum', name: 'Price Momentum', successCount: 0, failCount: 0, weight: 1.0, lastUsed: Date.now(), status: 'ACTIVE', avgConfirmationCandles: 0 },
      { id: 'divergence_trap', name: 'Divergence Trap', successCount: 0, failCount: 0, weight: 1.5, lastUsed: Date.now(), status: 'ACTIVE', avgConfirmationCandles: 0 },
      { id: 'funding_divergence', name: 'Funding Divergence', successCount: 0, failCount: 0, weight: 0.8, lastUsed: Date.now(), status: 'ACTIVE', avgConfirmationCandles: 0 },
      { id: 'vol_oi_correlation', name: 'Volume-OI Correlation', successCount: 0, failCount: 0, weight: 1.2, lastUsed: Date.now(), status: 'ACTIVE', avgConfirmationCandles: 0 },
      { id: 'cross_exchange_lead', name: 'Cross-Exchange Lead', successCount: 0, failCount: 0, weight: 0.9, lastUsed: Date.now(), status: 'ACTIVE', avgConfirmationCandles: 0 },
    ];
    if (this.activeRatios.length === 0) {
      this.activeRatios = defaultRatios;
    }
  }

  subscribe(listener: () => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach(l => l());
  }

  private saveToStorage() {
    try {
      const data = {
        feedbackLog: this.feedbackLog.slice(-200),
        activeRatios: this.activeRatios,
        paperTrades: this.paperTrades.slice(-100),
        shortTermMemory: Object.fromEntries(
          Array.from(this.shortTermMemory.entries()).map(([k, v]) => [k, v.slice(-50)])
        ),
        longTermMemory: Object.fromEntries(
          Array.from(this.longTermMemory.entries()).map(([k, v]) => [k, v.slice(-200)])
        ),
        symbolLearnings: Object.fromEntries(this.symbolLearnings),
        lastLearning12h: Object.fromEntries(this.lastLearning12h),
        lastLearning30d: this.lastLearning30d,
      };
      localStorage.setItem('brain_state', JSON.stringify(data));
    } catch (e) {
      console.warn('Failed to save brain state:', e);
    }
  }

  private loadFromStorage() {
    try {
      const raw = localStorage.getItem('brain_state');
      if (!raw) return;
      const data = JSON.parse(raw);
      if (data.feedbackLog) this.feedbackLog = data.feedbackLog;
      if (data.activeRatios) this.activeRatios = data.activeRatios;
      if (data.paperTrades) this.paperTrades = data.paperTrades;
      if (data.shortTermMemory) {
        this.shortTermMemory = new Map(Object.entries(data.shortTermMemory) as [string, RatioData[]][]);
      }
      if (data.longTermMemory) {
        this.longTermMemory = new Map(Object.entries(data.longTermMemory) as [string, RatioData[]][]);
      }
      if (data.symbolLearnings) {
        this.symbolLearnings = new Map(Object.entries(data.symbolLearnings) as [string, SymbolLearning][]);
      }
      if (data.lastLearning12h) {
        this.lastLearning12h = new Map(Object.entries(data.lastLearning12h) as [string, number][]);
      }
      if (data.lastLearning30d) {
        this.lastLearning30d = data.lastLearning30d;
      }
    } catch (e) {
      console.warn('Failed to load brain state:', e);
    }
  }

  // ========== RATIO CALCULATIONS ==========

  calcOIRatio(oiNow: number, oiPrev: number): number {
    if (oiPrev === 0) return 0;
    return (oiNow - oiPrev) / oiPrev;
  }

  calcVolRatio(volNow: number, volumes: number[]): number {
    const avgVol = avg(volumes.slice(-this.config.volumeAvgPeriod));
    if (avgVol === 0) return 0;
    return volNow / avgVol;
  }

  calcPriceRatio(closeNow: number, closePrev: number): number {
    if (closePrev === 0) return 0;
    return (closeNow - closePrev) / closePrev;
  }

  // ========== DIVERGENCE TRAP DETECTION ==========

  detectTrap(ratioData: RatioData): DivergenceTrap {
    const { oiRatio, volRatio, priceRatio } = ratioData;
    const cfg = this.config;

    const oiUp = oiRatio > cfg.trapThresholdOI;
    const oiDown = oiRatio < -cfg.trapThresholdOI;
    const volHigh = volRatio > cfg.trapThresholdVol;
    const priceUp = priceRatio > cfg.trapThresholdPrice;
    const priceDown = priceRatio < -cfg.trapThresholdPrice;

    const oiDir = oiUp ? 'UP' as const : oiDown ? 'DOWN' as const : 'FLAT' as const;
    const volDir = volHigh ? 'UP' as const : 'FLAT' as const;
    const priceDir = priceUp ? 'UP' as const : priceDown ? 'DOWN' as const : 'FLAT' as const;

    if (oiUp && volHigh && priceDown) {
      const confidence = Math.min(1, (Math.abs(oiRatio) + volRatio / 3 + Math.abs(priceRatio) * 10) / 3);
      return {
        type: 'LONG_TRAP', confidence,
        description: 'OI↑ + Volume↑ + Price↓ → Potential long trap / liquidity grab',
        oiDirection: oiDir, volDirection: volDir, priceDirection: priceDir,
      };
    }

    if (oiUp && volHigh && priceUp) {
      const confidence = Math.min(1, (Math.abs(oiRatio) + volRatio / 3 + Math.abs(priceRatio) * 10) / 3);
      return {
        type: 'SHORT_TRAP', confidence,
        description: 'OI↑ + Volume↑ + Price↑↑ → Potential short squeeze trap',
        oiDirection: oiDir, volDirection: volDir, priceDirection: priceDir,
      };
    }

    return {
      type: 'NONE', confidence: 0,
      description: 'No divergence trap detected',
      oiDirection: oiDir, volDirection: volDir, priceDirection: priceDir,
    };
  }

  // ========== MEMORY MANAGEMENT ==========

  getShortTermMemory(key: string): MemoryShortTerm {
    const records = this.shortTermMemory.get(key) || [];
    const windowMs = this.config.shortTermWindowHours * 60 * 60 * 1000;
    const cutoff = Date.now() - windowMs;
    const filtered = records.filter(r => r.timestamp > cutoff).slice(-this.config.shortTermMaxRecords);

    return {
      records: filtered,
      avgOiRatio: avg(filtered.map(r => r.oiRatio)),
      avgVolRatio: avg(filtered.map(r => r.volRatio)),
      avgPriceRatio: avg(filtered.map(r => r.priceRatio)),
      stdOiRatio: std(filtered.map(r => r.oiRatio)),
      stdVolRatio: std(filtered.map(r => r.volRatio)),
      stdPriceRatio: std(filtered.map(r => r.priceRatio)),
    };
  }

  getLongTermMemory(key: string): MemoryLongTerm {
    const records = this.longTermMemory.get(key) || [];
    const windowMs = this.config.longTermWindowDays * 24 * 60 * 60 * 1000;
    const cutoff = Date.now() - windowMs;
    const filtered = records.filter(r => r.timestamp > cutoff);

    return {
      records: filtered,
      avgOiRatio: avg(filtered.map(r => r.oiRatio)),
      avgVolRatio: avg(filtered.map(r => r.volRatio)),
      avgPriceRatio: avg(filtered.map(r => r.priceRatio)),
      stdOiRatio: std(filtered.map(r => r.oiRatio)),
      stdVolRatio: std(filtered.map(r => r.volRatio)),
      stdPriceRatio: std(filtered.map(r => r.priceRatio)),
    };
  }

  determineMarketState(key: string): MarketState {
    const st = this.getShortTermMemory(key);
    const lt = this.getLongTermMemory(key);

    if (st.records.length < 3) return 'Unknown';
    if (lt.records.length < 5) return 'Short-Term Dominant';

    const oiDiff = Math.abs(st.avgOiRatio - lt.avgOiRatio);
    const volDiff = Math.abs(st.avgVolRatio - lt.avgVolRatio);
    const priceDiff = Math.abs(st.avgPriceRatio - lt.avgPriceRatio);

    const totalDiff = oiDiff + volDiff * 0.1 + priceDiff;

    if (totalDiff < 0.02) return 'Long-Term Dominant';
    if (totalDiff > 0.08) return 'Short-Term Dominant';
    return 'Transitioning';
  }

  // ========== 12-HOUR LEARNING ==========

  private performLearning12h(symbol: string, exchange: ExchangeName) {
    const key = symbolExKey(symbol, exchange);
    const lastTime = this.lastLearning12h.get(key) || 0;
    const now = Date.now();

    if (now - lastTime < this.config.learningInterval12h) return;

    const stMemory = this.getShortTermMemory(key);
    if (stMemory.records.length < 5) return;

    const marketState = this.determineMarketState(key);

    // Determine dominant signal from recent data
    let buyCount = 0, sellCount = 0;
    for (const r of stMemory.records) {
      if (r.priceRatio > 0) buyCount++;
      else if (r.priceRatio < 0) sellCount++;
    }
    const dominantSignal = buyCount > sellCount ? 'BUY' as const
      : sellCount > buyCount ? 'SELL' as const : 'HOLD' as const;

    const learning: LearningRecord = {
      timestamp: now,
      avgOiRatio: stMemory.avgOiRatio,
      avgVolRatio: stMemory.avgVolRatio,
      avgPriceRatio: stMemory.avgPriceRatio,
      stdOiRatio: stMemory.stdOiRatio,
      stdVolRatio: stMemory.stdVolRatio,
      stdPriceRatio: stMemory.stdPriceRatio,
      avgFundingRate: avg(stMemory.records.map(r => r.fundingRate)),
      marketState,
      dominantSignal,
      confidence: Math.abs(buyCount - sellCount) / Math.max(1, stMemory.records.length),
      sampleCount: stMemory.records.length,
    };

    // Get or create symbol learning
    let sl = this.symbolLearnings.get(key);
    if (!sl) {
      sl = {
        symbol, exchange,
        shortTermLearnings: [],
        longTermLearnings: [],
        ratioWeights: {},
        reversalPatterns: [],
        lastUpdated: now,
      };
    }

    sl.shortTermLearnings.push(learning);
    // Keep only last N records
    sl.shortTermLearnings = sl.shortTermLearnings.slice(-this.config.maxLearningRecords12h);
    sl.lastUpdated = now;

    this.symbolLearnings.set(key, sl);
    this.lastLearning12h.set(key, now);

    // Check if we need 30d meta-learning
    this.checkMetaLearning(key);

    console.log(`[Brain] 12h learning saved: ${symbol}/${exchange} | State: ${marketState} | Signal: ${dominantSignal}`);
  }

  // ========== 30-DAY META LEARNING ==========
  // Every 60 records of 12h learnings → do meta-analysis

  private checkMetaLearning(key: string) {
    const sl = this.symbolLearnings.get(key);
    if (!sl) return;

    // Every 60 short-term records → produce 1 long-term learning
    if (sl.shortTermLearnings.length >= 60 && sl.shortTermLearnings.length % 60 === 0) {
      const last60 = sl.shortTermLearnings.slice(-60);

      const metaLearning: LearningRecord = {
        timestamp: Date.now(),
        avgOiRatio: avg(last60.map(l => l.avgOiRatio)),
        avgVolRatio: avg(last60.map(l => l.avgVolRatio)),
        avgPriceRatio: avg(last60.map(l => l.avgPriceRatio)),
        stdOiRatio: avg(last60.map(l => l.stdOiRatio)),
        stdVolRatio: avg(last60.map(l => l.stdVolRatio)),
        stdPriceRatio: avg(last60.map(l => l.stdPriceRatio)),
        avgFundingRate: avg(last60.map(l => l.avgFundingRate)),
        marketState: this.getMostCommon(last60.map(l => l.marketState)),
        dominantSignal: this.getMostCommon(last60.map(l => l.dominantSignal)),
        confidence: avg(last60.map(l => l.confidence)),
        sampleCount: last60.reduce((s, l) => s + l.sampleCount, 0),
      };

      sl.longTermLearnings.push(metaLearning);
      sl.longTermLearnings = sl.longTermLearnings.slice(-this.config.maxLearningRecords30d);

      // Update ratio weights based on accumulated feedback for this symbol
      this.updateSymbolRatioWeights(key);

      console.log(`[Brain] 30d meta-learning saved: ${sl.symbol}/${sl.exchange} | ${last60.length} → 1 meta record`);
    }
  }

  private getMostCommon<T>(arr: T[]): T {
    const counts = new Map<T, number>();
    for (const item of arr) {
      counts.set(item, (counts.get(item) || 0) + 1);
    }
    let maxCount = 0;
    let most = arr[0];
    for (const [item, count] of counts) {
      if (count > maxCount) { maxCount = count; most = item; }
    }
    return most;
  }

  // ========== PER-SYMBOL RATIO WEIGHTS ==========

  private updateSymbolRatioWeights(key: string) {
    const sl = this.symbolLearnings.get(key);
    if (!sl) return;

    const symbolFeedback = this.feedbackLog.filter(
      f => symbolExKey(f.symbol, f.exchange) === key && f.result !== 'PENDING'
    );

    if (symbolFeedback.length < 5) return;

    const successRate = symbolFeedback.filter(f => f.result === 'SUCCESS').length / symbolFeedback.length;

    // Update per-ratio weights for this symbol
    for (const ratio of this.activeRatios) {
      if (!sl.ratioWeights[ratio.id]) {
        sl.ratioWeights[ratio.id] = { weight: ratio.weight, success: 0, fail: 0, active: true };
      }

      const rw = sl.ratioWeights[ratio.id];
      // Adjust weight based on this symbol's success rate
      if (successRate > 0.6) {
        rw.weight = Math.min(3, rw.weight + 0.05);
        rw.success++;
      } else if (successRate < 0.4) {
        rw.weight = Math.max(0.1, rw.weight - 0.08);
        rw.fail++;
      }

      // Mark as inactive if too many failures
      const total = rw.success + rw.fail;
      if (total >= 10 && rw.success / total < 0.25) {
        rw.active = false;
      }
    }

    sl.lastUpdated = Date.now();
    this.symbolLearnings.set(key, sl);
  }

  // ========== SIGNAL GENERATION ==========

  generateBrainSignal(symbol: string, currentRatio: RatioData): BrainOutput {
    const exchange = currentRatio.exchange;
    const key = symbolExKey(symbol, exchange);

    // Store in memory
    const stRecords = this.shortTermMemory.get(key) || [];
    stRecords.push(currentRatio);
    this.shortTermMemory.set(key, stRecords.slice(-100));

    const ltRecords = this.longTermMemory.get(key) || [];
    ltRecords.push(currentRatio);
    this.longTermMemory.set(key, ltRecords.slice(-500));

    // Try 12h learning
    this.performLearning12h(symbol, exchange);

    // Detect trap
    const trap = this.detectTrap(currentRatio);

    // Get memory states
    const stMemory = this.getShortTermMemory(key);
    const ltMemory = this.getLongTermMemory(key);
    const marketState = this.determineMarketState(key);

    // Get per-symbol ratio weights if available
    const sl = this.symbolLearnings.get(key);

    // Calculate weighted signal
    let signalScore = 0;
    const activeRatiosList = this.activeRatios.filter(r => r.status === 'ACTIVE');
    const archivedRatiosList = this.activeRatios.filter(r => r.status === 'ARCHIVED');

    for (const ratio of activeRatiosList) {
      // Use per-symbol weight if available, otherwise global weight
      const symbolWeight = sl?.ratioWeights[ratio.id];
      const effectiveWeight = (symbolWeight?.active !== false) ? (symbolWeight?.weight || ratio.weight) : 0;

      if (effectiveWeight === 0) continue;

      switch (ratio.id) {
        case 'oi_ratio':
          if (currentRatio.oiRatio > stMemory.avgOiRatio + stMemory.stdOiRatio) {
            signalScore += effectiveWeight * (currentRatio.priceRatio > 0 ? 1 : -1);
          }
          break;
        case 'vol_spike':
          if (currentRatio.volRatio > 2) {
            signalScore += effectiveWeight * (currentRatio.priceRatio > 0 ? 0.5 : -0.5);
          }
          break;
        case 'price_momentum':
          signalScore += effectiveWeight * Math.sign(currentRatio.priceRatio) * Math.min(Math.abs(currentRatio.priceRatio) * 100, 2);
          break;
        case 'divergence_trap':
          if (trap.type === 'LONG_TRAP') signalScore -= effectiveWeight * trap.confidence * 2;
          else if (trap.type === 'SHORT_TRAP') signalScore += effectiveWeight * trap.confidence * 2;
          break;
        case 'funding_divergence':
          if (Math.abs(currentRatio.fundingRate) > 0.001) {
            signalScore -= effectiveWeight * Math.sign(currentRatio.fundingRate) * 0.5;
          }
          break;
        case 'vol_oi_correlation':
          if (currentRatio.oiRatio > 0 && currentRatio.volRatio > 1.5) {
            signalScore += effectiveWeight * (currentRatio.priceRatio > 0 ? 0.3 : -0.3);
          }
          break;
        case 'cross_exchange_lead':
          // handled externally via crossExchangeData
          break;
      }
    }

    // Normalize confidence
    const maxPossibleScore = activeRatiosList.reduce((s, r) => s + (sl?.ratioWeights[r.id]?.weight || r.weight) * 2, 0);
    const confidence = maxPossibleScore > 0 ? Math.min(1, Math.abs(signalScore) / maxPossibleScore) : 0;

    let signal: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
    if (signalScore > 0 && confidence >= this.config.minConfidence) signal = 'BUY';
    if (signalScore < 0 && confidence >= this.config.minConfidence) signal = 'SELL';

    // Feedback stats
    const recentFeedback = this.feedbackLog.filter(
      f => f.symbol === symbol && f.result !== 'PENDING' &&
      f.entryTime > Date.now() - 30 * 24 * 60 * 60 * 1000
    );
    const successRate = recentFeedback.length > 0
      ? recentFeedback.filter(f => f.result === 'SUCCESS').length / recentFeedback.length : 0;
    const avgCandles = recentFeedback.length > 0
      ? avg(recentFeedback.map(f => f.candlesToConfirm)) : 0;

    const output: BrainOutput = {
      symbol,
      exchange,
      marketState,
      activeRatios: activeRatiosList,
      archivedRatios: archivedRatiosList,
      currentSignal: signal,
      confidenceScore: confidence,
      divergenceTrap: trap,
      feedbackStats: {
        successRate30d: successRate,
        avgConfirmationCandles: avgCandles,
        totalSignals: this.feedbackLog.filter(f => f.symbol === symbol).length,
        activeSignals: this.feedbackLog.filter(f => f.symbol === symbol && f.result === 'PENDING').length,
      },
      shortTermMemory: {
        avgOiRatio: stMemory.avgOiRatio,
        avgVolRatio: stMemory.avgVolRatio,
        avgPriceRatio: stMemory.avgPriceRatio,
      },
      longTermMemory: {
        avgOiRatio: ltMemory.avgOiRatio,
        avgVolRatio: ltMemory.avgVolRatio,
        avgPriceRatio: ltMemory.avgPriceRatio,
      },
      lastUpdate: Date.now(),
      ratios: {
        oiRatio: currentRatio.oiRatio,
        volRatio: currentRatio.volRatio,
        priceRatio: currentRatio.priceRatio,
        fundingRate: currentRatio.fundingRate,
      },
    };

    this.outputs.set(symbol, output);

    // If signal emitted, create feedback entry
    if (signal !== 'HOLD') {
      this.createFeedbackEntry(symbol, exchange, signal, currentRatio.close, currentRatio);
    }

    this.saveToStorage();
    this.notify();
    return output;
  }

  // ========== FEEDBACK LOOP ==========

  private createFeedbackEntry(symbol: string, exchange: ExchangeName, signalType: 'BUY' | 'SELL', entryPrice: number, ratioData: RatioData) {
    const feedback: SignalFeedback = {
      id: `FB-${symbol}-${Date.now()}`,
      symbol, exchange, signalType, entryPrice,
      entryTime: Date.now(),
      trackingCandles: this.config.trackingCandles,
      maxFavorableExcursion: entryPrice,
      maxAdverseExcursion: entryPrice,
      candlesToConfirm: 0,
      result: 'PENDING',
      ratiosAtEntry: {
        oiRatio: ratioData.oiRatio,
        volRatio: ratioData.volRatio,
        priceRatio: ratioData.priceRatio,
        fundingRate: ratioData.fundingRate,
      },
    };
    this.feedbackLog.push(feedback);
  }

  updateFeedback(symbol: string, currentPrice: number, candleIndex: number) {
    const pendingFeedbacks = this.feedbackLog.filter(
      f => f.symbol === symbol && f.result === 'PENDING'
    );

    for (const fb of pendingFeedbacks) {
      const elapsed = candleIndex;

      if (fb.signalType === 'BUY') {
        if (currentPrice > fb.maxFavorableExcursion) fb.maxFavorableExcursion = currentPrice;
        if (currentPrice < fb.maxAdverseExcursion) fb.maxAdverseExcursion = currentPrice;
        if (currentPrice > fb.entryPrice * 1.002 && fb.candlesToConfirm === 0) {
          fb.candlesToConfirm = elapsed;
        }
      } else {
        if (currentPrice < fb.maxFavorableExcursion) fb.maxFavorableExcursion = currentPrice;
        if (currentPrice > fb.maxAdverseExcursion) fb.maxAdverseExcursion = currentPrice;
        if (currentPrice < fb.entryPrice * 0.998 && fb.candlesToConfirm === 0) {
          fb.candlesToConfirm = elapsed;
        }
      }

      if (elapsed >= fb.trackingCandles) {
        const pnl = fb.signalType === 'BUY'
          ? (currentPrice - fb.entryPrice) / fb.entryPrice
          : (fb.entryPrice - currentPrice) / fb.entryPrice;

        fb.exitPrice = currentPrice;
        fb.exitTime = Date.now();
        fb.pnlPercent = pnl * 100;
        fb.result = pnl > 0 ? 'SUCCESS' : 'FAIL';

        // Update global ratio weights
        this.updateRatioWeights(fb.result);

        // Save reversal pattern per symbol
        if (fb.ratiosAtEntry) {
          this.saveReversalPattern(fb);
        }
      }
    }

    this.saveToStorage();
    this.notify();
  }

  private saveReversalPattern(fb: SignalFeedback) {
    const key = symbolExKey(fb.symbol, fb.exchange);
    const sl = this.symbolLearnings.get(key);
    if (!sl || !fb.ratiosAtEntry) return;

    const pattern: ReversalPattern = {
      id: `RP-${fb.id}`,
      symbol: fb.symbol,
      exchange: fb.exchange,
      timestamp: fb.entryTime,
      ratiosAtReversal: fb.ratiosAtEntry,
      directionBefore: fb.signalType === 'BUY' ? 'DOWN' : 'UP',
      directionAfter: fb.result === 'SUCCESS'
        ? (fb.signalType === 'BUY' ? 'UP' : 'DOWN')
        : (fb.signalType === 'BUY' ? 'DOWN' : 'UP'),
      pnlPercent: fb.pnlPercent || 0,
      candlesToConfirm: fb.candlesToConfirm,
      useful: fb.result === 'SUCCESS',
    };

    sl.reversalPatterns.push(pattern);
    // Keep only last 50 patterns
    sl.reversalPatterns = sl.reversalPatterns.slice(-50);
    sl.lastUpdated = Date.now();
    this.symbolLearnings.set(key, sl);
  }

  private updateRatioWeights(result: 'SUCCESS' | 'FAIL') {
    for (const ratio of this.activeRatios) {
      if (ratio.status !== 'ACTIVE') continue;

      if (result === 'SUCCESS') {
        ratio.successCount++;
        ratio.weight = Math.min(3, ratio.weight + this.config.weightIncrement);
      } else {
        ratio.failCount++;
        ratio.weight = Math.max(0.1, ratio.weight - this.config.weightDecrement);
      }

      const total = ratio.successCount + ratio.failCount;
      if (total >= 10 && ratio.successCount / total < 0.3) {
        ratio.status = 'ARCHIVED';
      }

      const relevantFeedback = this.feedbackLog.filter(f => f.result === 'SUCCESS' && f.candlesToConfirm > 0);
      if (relevantFeedback.length > 0) {
        ratio.avgConfirmationCandles = avg(relevantFeedback.map(f => f.candlesToConfirm));
      }

      ratio.lastUsed = Date.now();
    }
  }

  // ========== PAPER TRADING ==========

  openPaperTrade(params: {
    symbol: string;
    exchange: ExchangeName;
    side: 'LONG' | 'SHORT';
    entryPrice: number;
    quantity: number;
    leverage: number;
    stopLossPercent: number;
    takeProfitPercent: number;
    source: 'BRAIN_AUTO' | 'MANUAL';
    signalId?: string;
    brainConfidence?: number;
  }): PaperTrade {
    const { symbol, exchange, side, entryPrice, quantity, leverage, stopLossPercent, takeProfitPercent, source, signalId, brainConfidence } = params;

    // Get current ratios for this symbol
    const key = symbolExKey(symbol, exchange);
    const stRecords = this.shortTermMemory.get(key) || [];
    const lastRatio = stRecords[stRecords.length - 1];

    const trade: PaperTrade = {
      id: `PT-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      symbol, exchange, side, entryPrice,
      currentPrice: entryPrice,
      quantity, leverage,
      stopLoss: side === 'LONG' ? entryPrice * (1 - stopLossPercent / 100) : entryPrice * (1 + stopLossPercent / 100),
      takeProfit: side === 'LONG' ? entryPrice * (1 + takeProfitPercent / 100) : entryPrice * (1 - takeProfitPercent / 100),
      status: 'OPEN',
      openTime: Date.now(),
      pnl: 0, pnlPercent: 0,
      source, signalId, brainConfidence,
      ratiosAtEntry: lastRatio ? {
        oiRatio: lastRatio.oiRatio,
        volRatio: lastRatio.volRatio,
        priceRatio: lastRatio.priceRatio,
        fundingRate: lastRatio.fundingRate,
      } : undefined,
    };

    this.paperTrades.push(trade);
    this.saveToStorage();
    this.notify();
    return trade;
  }

  updatePaperTrades(prices: Map<string, number>) {
    for (const trade of this.paperTrades) {
      if (trade.status !== 'OPEN') continue;

      const currentPrice = prices.get(trade.symbol);
      if (!currentPrice) continue;

      trade.currentPrice = currentPrice;

      if (trade.side === 'LONG') {
        trade.pnl = (currentPrice - trade.entryPrice) * trade.quantity * trade.leverage;
        trade.pnlPercent = ((currentPrice - trade.entryPrice) / trade.entryPrice) * 100 * trade.leverage;
      } else {
        trade.pnl = (trade.entryPrice - currentPrice) * trade.quantity * trade.leverage;
        trade.pnlPercent = ((trade.entryPrice - currentPrice) / trade.entryPrice) * 100 * trade.leverage;
      }

      if (trade.side === 'LONG') {
        if (currentPrice <= trade.stopLoss) { trade.status = 'CLOSED_SL'; trade.closeTime = Date.now(); }
        else if (currentPrice >= trade.takeProfit) { trade.status = 'CLOSED_TP'; trade.closeTime = Date.now(); }
      } else {
        if (currentPrice >= trade.stopLoss) { trade.status = 'CLOSED_SL'; trade.closeTime = Date.now(); }
        else if (currentPrice <= trade.takeProfit) { trade.status = 'CLOSED_TP'; trade.closeTime = Date.now(); }
      }

      // When trade closes, save reversal pattern
      if (trade.status !== 'OPEN' && trade.ratiosAtEntry) {
        const key = symbolExKey(trade.symbol, trade.exchange);
        const sl = this.symbolLearnings.get(key);
        if (sl) {
          const pattern: ReversalPattern = {
            id: `RP-trade-${trade.id}`,
            symbol: trade.symbol,
            exchange: trade.exchange,
            timestamp: trade.openTime,
            ratiosAtReversal: trade.ratiosAtEntry,
            directionBefore: trade.side === 'LONG' ? 'DOWN' : 'UP',
            directionAfter: trade.pnl > 0
              ? (trade.side === 'LONG' ? 'UP' : 'DOWN')
              : (trade.side === 'LONG' ? 'DOWN' : 'UP'),
            pnlPercent: trade.pnlPercent,
            candlesToConfirm: Math.floor((Date.now() - trade.openTime) / 60000),
            useful: trade.pnl > 0,
          };
          sl.reversalPatterns.push(pattern);
          sl.reversalPatterns = sl.reversalPatterns.slice(-50);
          this.symbolLearnings.set(key, sl);
        }
      }
    }

    this.saveToStorage();
    this.notify();
  }

  closePaperTrade(tradeId: string, currentPrice: number) {
    const trade = this.paperTrades.find(t => t.id === tradeId);
    if (!trade || trade.status !== 'OPEN') return;

    trade.currentPrice = currentPrice;
    trade.status = 'CLOSED_MANUAL';
    trade.closeTime = Date.now();

    if (trade.side === 'LONG') {
      trade.pnl = (currentPrice - trade.entryPrice) * trade.quantity * trade.leverage;
      trade.pnlPercent = ((currentPrice - trade.entryPrice) / trade.entryPrice) * 100 * trade.leverage;
    } else {
      trade.pnl = (trade.entryPrice - currentPrice) * trade.quantity * trade.leverage;
      trade.pnlPercent = ((trade.entryPrice - currentPrice) / trade.entryPrice) * 100 * trade.leverage;
    }

    this.saveToStorage();
    this.notify();
  }

  // ========== GETTERS ==========

  getOutput(symbol: string): BrainOutput | undefined { return this.outputs.get(symbol); }
  getAllOutputs(): BrainOutput[] { return Array.from(this.outputs.values()); }
  getFeedbackLog(): SignalFeedback[] { return [...this.feedbackLog]; }
  getPaperTrades(): PaperTrade[] { return [...this.paperTrades]; }
  getOpenPaperTrades(): PaperTrade[] { return this.paperTrades.filter(t => t.status === 'OPEN'); }
  getClosedPaperTrades(): PaperTrade[] { return this.paperTrades.filter(t => t.status !== 'OPEN'); }
  getActiveRatios(): ActiveRatio[] { return this.activeRatios.filter(r => r.status === 'ACTIVE'); }
  getArchivedRatios(): ActiveRatio[] { return this.activeRatios.filter(r => r.status === 'ARCHIVED'); }
  getAllRatios(): ActiveRatio[] { return [...this.activeRatios]; }
  getConfig(): BrainConfig { return { ...this.config }; }
  getSymbolLearnings(): Map<string, SymbolLearning> { return this.symbolLearnings; }
  getSymbolLearning(symbol: string, exchange: ExchangeName): SymbolLearning | undefined {
    return this.symbolLearnings.get(symbolExKey(symbol, exchange));
  }

  updateConfig(partial: Partial<BrainConfig>) {
    this.config = { ...this.config, ...partial };
    this.saveToStorage();
    this.notify();
  }

  getPaperTradeStats() {
    const closed = this.getClosedPaperTrades();
    const open = this.getOpenPaperTrades();
    const wins = closed.filter(t => t.pnl > 0);
    const losses = closed.filter(t => t.pnl <= 0);

    return {
      totalTrades: closed.length,
      openTrades: open.length,
      wins: wins.length,
      losses: losses.length,
      winRate: closed.length > 0 ? (wins.length / closed.length) * 100 : 0,
      totalPnl: closed.reduce((s, t) => s + t.pnl, 0),
      unrealizedPnl: open.reduce((s, t) => s + t.pnl, 0),
      avgWin: wins.length > 0 ? avg(wins.map(t => t.pnlPercent)) : 0,
      avgLoss: losses.length > 0 ? avg(losses.map(t => t.pnlPercent)) : 0,
      bestTrade: closed.length > 0 ? Math.max(...closed.map(t => t.pnlPercent)) : 0,
      worstTrade: closed.length > 0 ? Math.min(...closed.map(t => t.pnlPercent)) : 0,
      brainAutoTrades: closed.filter(t => t.source === 'BRAIN_AUTO').length,
      manualTrades: closed.filter(t => t.source === 'MANUAL').length,
    };
  }

  resetBrain() {
    this.shortTermMemory.clear();
    this.longTermMemory.clear();
    this.feedbackLog = [];
    this.paperTrades = [];
    this.outputs.clear();
    this.symbolLearnings.clear();
    this.lastLearning12h.clear();
    this.lastLearning30d = 0;
    this.activeRatios = [];
    this.initializeRatios();
    localStorage.removeItem('brain_state');
    this.notify();
  }
}

// Singleton instance
export const brain = new AdaptiveRatioBrain();
