from __future__ import annotations

from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import textwrap

OUT = Path('/home/user/local_cursor_agent/dsa_outputs')
OUT.mkdir(parents=True, exist_ok=True)

FONT_REG = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONT_BOLD = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'

A4 = (1654, 2339)  # 200dpi-ish
BG = (248, 250, 252)
INK = (20, 31, 52)
MUTED = (86, 101, 125)
BLUE = (24, 70, 128)
CYAN = (14, 116, 144)
GOLD = (151, 95, 20)
RED = (126, 45, 45)
LIGHT_BLUE = (222, 238, 251)
BORDER = (196, 210, 226)
WHITE = (255, 255, 255)


def font(size: int, bold: bool = False):
    return ImageFont.truetype(FONT_BOLD if bold else FONT_REG, size=size)


class PDFDoc:
    def __init__(self, title: str):
        self.title = title
        self.pages = []
        self.page_no = 0
        self.margin_x = 110
        self.top = 90
        self.bottom = A4[1] - 120
        self.new_page()

    def new_page(self):
        self.page_no += 1
        self.img = Image.new('RGB', A4, BG)
        self.draw = ImageDraw.Draw(self.img)
        # white content panel
        self.draw.rounded_rectangle([60, 55, A4[0]-60, A4[1]-55], radius=34, fill=WHITE, outline=(226, 232, 240), width=2)
        self.y = self.top
        if self.page_no > 1:
            self.header_small(self.title)
        self.pages.append(self.img)

    def ensure(self, need=80):
        if self.y + need > self.bottom:
            self.footer()
            self.new_page()

    def footer(self):
        txt = f"Pre-NDA Concept Brief | محرمانه | صفحه {self.page_no}"
        self.draw.text((A4[0]//2, A4[1]-83), txt, font=font(20), fill=MUTED, anchor='mm', direction='rtl', language='fa')

    def header_small(self, text):
        self.draw.text((A4[0]-self.margin_x, 84), text, font=font(20, True), fill=BLUE, anchor='ra', direction='rtl', language='fa')
        self.draw.line([self.margin_x, 118, A4[0]-self.margin_x, 118], fill=(226,232,240), width=2)
        self.y = 145

    def text_width(self, s, f, direction='rtl'):
        if not s:
            return 0
        try:
            bbox = self.draw.textbbox((0,0), s, font=f, direction=direction, language='fa')
        except Exception:
            bbox = self.draw.textbbox((0,0), s, font=f)
        return bbox[2] - bbox[0]

    def rtl(self, text, size=26, bold=False, color=INK, x=None, y=None, anchor='ra'):
        f = font(size, bold)
        x = x if x is not None else A4[0] - self.margin_x
        y = y if y is not None else self.y
        self.draw.text((x, y), text, font=f, fill=color, anchor=anchor, direction='rtl', language='fa')

    def center(self, text, size=30, bold=False, color=INK):
        self.ensure(size + 20)
        self.draw.text((A4[0]//2, self.y), text, font=font(size, bold), fill=color, anchor='ma', direction='rtl', language='fa')
        self.y += int(size * 1.55)

    def heading(self, text, level=1):
        self.ensure(80)
        size = 34 if level == 1 else 29
        col = BLUE if level == 1 else CYAN
        self.rtl(text, size=size, bold=True, color=col)
        self.y += int(size * 1.35)
        self.draw.line([self.margin_x, self.y-8, A4[0]-self.margin_x, self.y-8], fill=(226,232,240), width=2)
        self.y += 12

    def wrap_lines(self, text, f, max_width):
        lines = []
        for para in str(text).split('\n'):
            words = para.split(' ')
            cur = ''
            for w in words:
                trial = w if not cur else cur + ' ' + w
                if self.text_width(trial, f) <= max_width:
                    cur = trial
                else:
                    if cur:
                        lines.append(cur)
                    # hard split very long tokens
                    if self.text_width(w, f) > max_width:
                        chunk = ''
                        for ch in w:
                            t = chunk + ch
                            if self.text_width(t, f) <= max_width:
                                chunk = t
                            else:
                                if chunk:
                                    lines.append(chunk)
                                chunk = ch
                        cur = chunk
                    else:
                        cur = w
            if cur:
                lines.append(cur)
            if not para.strip():
                lines.append('')
        return lines

    def paragraph(self, text, size=25, bold=False, color=INK, gap=10, indent=0):
        f = font(size, bold)
        maxw = A4[0] - 2*self.margin_x - indent
        lines = self.wrap_lines(text, f, maxw)
        for line in lines:
            self.ensure(size + 20)
            if line:
                self.rtl(line, size=size, bold=bold, color=color, x=A4[0]-self.margin_x-indent)
            self.y += int(size * 1.45)
        self.y += gap

    def bullet(self, text, size=24):
        self.paragraph('• ' + text, size=size, gap=2)

    def callout(self, text, color=LIGHT_BLUE, border=(150,190,220)):
        f = font(26, True)
        lines = self.wrap_lines(text, f, A4[0]-2*self.margin_x-70)
        h = len(lines)*42 + 46
        self.ensure(h+20)
        x1, y1, x2, y2 = self.margin_x, self.y, A4[0]-self.margin_x, self.y+h
        self.draw.rounded_rectangle([x1,y1,x2,y2], radius=22, fill=color, outline=border, width=2)
        yy = y1 + 34
        for line in lines:
            self.draw.text((x2-34, yy), line, font=f, fill=BLUE, anchor='ra', direction='rtl', language='fa')
            yy += 42
        self.y = y2 + 24

    def table(self, headers, rows, highlight_index=None):
        colw = [220, 290, 290, 360]
        total = sum(colw)
        x0 = (A4[0]-total)//2
        rowh = 58
        h = rowh * (len(rows)+1)
        self.ensure(h+50)
        y0 = self.y
        x = x0
        for i, head in enumerate(headers):
            self.draw.rectangle([x,y0,x+colw[i],y0+rowh], fill=BLUE, outline=BORDER)
            self.draw.text((x+colw[i]/2, y0+rowh/2), head, font=font(22, True), fill=WHITE, anchor='mm', direction='ltr')
            x += colw[i]
        for r_i, row in enumerate(rows):
            y = y0 + rowh*(r_i+1)
            x = x0
            fill = LIGHT_BLUE if highlight_index == r_i else WHITE
            for i, val in enumerate(row):
                self.draw.rectangle([x,y,x+colw[i],y+rowh], fill=fill, outline=BORDER)
                self.draw.text((x+colw[i]/2, y+rowh/2), val, font=font(21, highlight_index == r_i), fill=INK, anchor='mm', direction='rtl', language='fa')
                x += colw[i]
        self.y += h + 28

    def save(self, path: Path):
        self.footer()
        self.pages[0].save(path, save_all=True, append_images=self.pages[1:], resolution=200.0)


def executive_pdf():
    d = PDFDoc('DSA — Deep Spiral Architecture')
    d.center('DSA: Deep Spiral Architecture', size=48, bold=True, color=BLUE)
    d.center('معماری مارپیچی حافظه برای یادگیری پیوسته', size=32, bold=True, color=CYAN)
    d.center('نام کد پروژه: DeepSpiral Angel', size=26, bold=True, color=GOLD)
    d.center('ارائه‌دهنده: هادی طباطبایی (TaHa111)', size=24, color=INK)
    d.callout('محرمانه | Pre-NDA Concept Brief | صرفاً جهت معرفی اولیه و ارزیابی مسیر محرمانگی', color=(255,247,226), border=(235,180,90))

    d.heading('۱. مسئله راهبردی')
    d.paragraph('در یادگیری پیوسته، مدل‌های هوش مصنوعی هنگام مواجهه با داده‌های جدید، بخشی از اطلاعات قبلی را از دست می‌دهند. این پدیده «فراموشی فاجعه‌بار» نام دارد و برای سامانه‌های هوش مصنوعی پایدار، بومی و بلندمدت یک چالش بنیادی است.')

    d.heading('۲. ایده محوری DSA')
    d.paragraph('DSA حافظه را از ترتیب خطی زمان به یک هندسه مارپیچی منتقل می‌کند. هر نقطه روی اسپیرال یک شکاف حافظه یا Memory Slot است. ارتباط میان حافظه‌ها تنها تابع زمان نیست؛ فاصله هندسی، فاز و وزن زمانی نیز دخیل هستند.')
    d.callout('شعار مفهومی: «محو شدن، نه فراموشی» — Fade, not Forget')

    d.heading('۳. سطح افشای فنی در این جلسه')
    d.bullet('فرمول پایه حرکت مارپیچی در سطح مفهومی قابل توضیح است.')
    d.bullet('تابع کامل وزن‌دهی، پارامترهای دقیق و کد اعتبارسنجی، هسته اختراع محسوب می‌شوند.')
    d.bullet('جزئیات کامل پس از NDA یا در مسیر رسمی محرمانگی ارائه خواهد شد.')

    d.heading('۴. نتایج اولیه Proof-of-Concept')
    d.paragraph('هدف این آزمایش، سنجش پایداری حافظه و Early Recall در یادگیری متوالی بوده است، نه ارائه benchmark نهایی accuracy.', bold=True, color=RED)
    d.table(['N','Final Acc','Max Acc','Early Recall'], [
        ['۸','۱۱.۵۷٪','۱۲.۹۹٪','۸۳.۰٪'],
        ['۱۲','۱۰.۰۳٪','۱۰.۲۶٪','۱۰۰.۰٪'],
        ['۱۸','۹.۴۹٪','۱۰.۵۲٪','۰.۰٪'],
        ['۲۰','۹.۱۲٪','۱۰.۳۵٪','۷۹.۲٪'],
        ['۳۶','۱۰.۳۲٪','۱۱.۷۲٪','۹۲.۵٪'],
        ['۴۸','۹.۶۴٪','۱۰.۵۵٪','۸۶.۴٪'],
    ], highlight_index=1)
    d.paragraph('مشاهده کلیدی: در N=12، Early Recall به ۱۰۰٪ رسید؛ این نقطه در کد پروژه به صورت داخلی «نقطه فرشته» نام‌گذاری شده است.', bold=True, color=CYAN)
    d.paragraph('در N=18 افت موقت مشاهده شد و در N=20 بازیابی رخ داد. این رفتار می‌تواند نشانه‌ای از گذار فازی یا بازآرایی حافظه باشد و نیازمند تحلیل تکمیلی در جلسه فنی پس از NDA است.')

    d.heading('۵. اهمیت برای زبان فارسی')
    d.paragraph('در یک تست اولیه تشخیص ابهام فارسی، تمایز میان «اِعراب» به معنای اعراب‌گذاری و «اعراب» به معنای قوم عرب بررسی شد. مدل خطی ۰٪ و DSA در این تست اولیه ۱۰۰٪ تشخیص ثبت کرد. این نتیجه ظرفیت بالقوه معماری را برای حفظ تمایزهای ظریف معنایی در زبان فارسی نشان می‌دهد.')

    d.heading('۶. چشم‌انداز توسعه')
    d.paragraph('در فاز آینده، معماری می‌تواند به حالت Dual Hemisphere Spiral گسترش یابد: دو مارپیچ مکمل، مشابه دو نیمکره مغز، برای تفکیک و تعامل میان حافظه تحلیلی و حافظه خلاق. این توسعه درون معماری مادر DSA تعریف می‌شود.')

    d.heading('۷. درخواست جلسه')
    d.bullet('تعریف مسیر محرمانگی و NDA برای ارائه کامل فرمول، کد و نتایج.')
    d.bullet('بررسی حمایت برای ثبت اختراع داخلی/بین‌المللی.')
    d.bullet('تشکیل جلسه فنی دوم با تیم تخصصی AI پس از چارچوب محرمانگی.')
    d.bullet('حمایت در ارزیابی، اعتبارسنجی و مسیر مالکیت فکری معماری DSA.')
    d.callout('این سند شامل معرفی مفهومی است و فاقد جزئیات کامل پیاده‌سازی، فرمول وزن‌دهی و کد اعتبارسنجی است.', color=(255,235,235), border=(230,150,150))
    d.center('هادی طباطبایی | Hadi.tabatabaei@gmail.com | #DSA #TaHa111', size=20, color=MUTED)
    path = OUT/'DSA_PreNDA_Executive_Brief_FA.pdf'
    d.save(path)
    return path


def speaker_pdf():
    d = PDFDoc('DSA — Speaker Notes')
    d.center('DSA — متن صحبت ارائه‌دهنده', size=42, bold=True, color=BLUE)
    d.center('نسخه شخصی هادی طباطبایی برای جلسه معرفی پیش از NDA', size=25, color=GOLD)
    d.callout('هدف جلسه: معرفی مفهومی، نمایش شواهد اولیه، و درخواست مسیر NDA + بررسی ثبت. نه افشای کامل اختراع.', color=(255,247,226), border=(235,180,90))

    sections = [
        ('شروع', 'سلام و وقت بخیر. هادی طباطبایی هستم. امروز برای افشای کامل اختراع نیامده‌ام؛ هدفم معرفی مفهومی معماری DSA، ارائه شواهد اولیه و درخواست ایجاد مسیر محرمانگی، بررسی فنی و ثبت رسمی است.'),
        ('مسئله', 'مسئله‌ای که روی آن کار کرده‌ام، فراموشی فاجعه‌بار در یادگیری پیوسته است. مدل وقتی داده جدید یاد می‌گیرد، در بسیاری از حالت‌ها بخشی از اطلاعات قبلی را از دست می‌دهد. من این را بحران حافظه در مدل‌های یادگیرنده می‌دانم.'),
        ('راه‌حل', 'ایده DSA این است که حافظه را از حالت خطی خارج کنیم و روی یک ساختار مارپیچی قرار دهیم. هر نقطه روی اسپیرال یک Memory Slot است. ارتباط میان نقاط فقط براساس زمان نیست؛ فاصله هندسی، فاز و وزن زمانی هم اثر دارند.'),
        ('شعار', 'شعار این معماری این است: محو شدن، نه فراموشی. یعنی اطلاعات قدیمی الزاماً حذف نمی‌شوند؛ اثرشان کنترل‌شده کاهش می‌یابد، اما امکان بازیابی ساختاری باقی می‌ماند.'),
        ('نتایج', 'در تست اولیه روی وظایف متوالی CIFAR-10، هدف benchmark نهایی accuracy نبود؛ هدف سنجش حافظه و Early Recall بود. در N=12، Early Recall به ۱۰۰٪ رسید. من به صورت داخلی این نقطه را «نقطه فرشته» نام‌گذاری کرده‌ام.'),
        ('N=18', 'در N=18 افت موقت دیده می‌شود و در N=20 بازیابی رخ می‌دهد. من فعلاً این رفتار را نشانه احتمالی بازآرایی یا گذار فازی حافظه می‌دانم، نه یک ادعای قطعی. تحلیل کامل‌تر آن را بعد از NDA ارائه می‌دهم.'),
        ('فارسی', 'یک تست کوچک فارسی هم انجام دادم: تمایز میان «اِعراب» به معنای اعراب‌گذاری و «اعراب» به معنای قوم عرب. مدل خطی در این تست صفر درصد بود، اما DSA در نسخه اولیه ۱۰۰٪ تشخیص داد. برای من این بخش از نظر AI فارسی اهمیت راهبردی دارد.'),
        ('آینده', 'مسیر آینده را Dual Hemisphere Spiral می‌بینم؛ دو مارپیچ مکمل، یکی نزدیک‌تر به منطق و دیگری نزدیک‌تر به خلاقیت. این توسعه زیرمجموعه معماری مادر DSA است، نه یک مدل جدا.'),
        ('درخواست', 'درخواست من روشن است: یک مسیر محرمانگی یا NDA، یک جلسه فنی دوم برای ارائه فرمول‌ها و کد، و حمایت برای بررسی مسیر ثبت اختراع و مالکیت فکری.'),
        ('پایان', 'ممنونم که وقت گذاشتید. من آماده‌ام در چارچوب محرمانگی، جزئیات فنی، فرمول کامل، کد و نتایج را در جلسه بعد ارائه کنم.'),
    ]
    for title, body in sections:
        d.heading(title)
        d.paragraph(body)

    d.heading('پاسخ‌های آماده به پرسش‌ها')
    qas = [
        ('فرق DSA با روش‌های دیگر چیست؟', 'در DSA، حافظه از خط زمانی صرف به هندسه مارپیچی منتقل می‌شود. اطلاعات قدیمی حذف یا overwrite نمی‌شوند؛ بلکه وزنشان کاهش می‌یابد و امکان بازیابی ساختاری باقی می‌ماند.'),
        ('چرا فرمول کامل در برگه نیست؟', 'چون این جلسه پیش از NDA است. فرمول پایه در سطح مفهومی قابل توضیح است، اما تابع وزن‌دهی کامل و پارامترهای دقیق هسته اختراع هستند و پس از مسیر محرمانگی ارائه می‌شوند.'),
        ('چرا دقت حدود ۱۰٪ است؟', 'این آزمایش برای benchmark نهایی accuracy طراحی نشده؛ هدف سنجش رفتار حافظه و Early Recall در یادگیری متوالی بوده است. معیار کلیدی اینجا بازیابی حافظه اولیه است.'),
        ('اگر خواستند اعداد ۳۰۰۰ و ۶ را توضیح بدهم؟', 'بگو: در تنظیم آزمایشی ما، مدل خطی با حجم بسیار بیشتری از داده درگیر بود، اما DSA با تعداد بسیار محدودتری از نقاط حافظه/نمونه‌های نماینده به Early Recall صددرصد رسید. عدد ۶ را به عنوان نقاط حافظه یا نمونه نماینده بگو، نه کل benchmark نهایی.'),
        ('اگر کد خواستند؟', 'کد تست و اعتبارسنجی موجود است، اما نسخه کامل کد و جزئیات پیاده‌سازی را بعد از NDA یا در جلسه فنی محرمانه ارائه می‌دهم.'),
        ('DSA و Angel دو مدل جدا هستند؟', 'خیر. DSA نام رسمی معماری است؛ DeepSpiral Angel نام کد نسخه پژوهشی آن است. در این نسخه، ایده دو مارپیچ مکمل مشابه نیمکره‌های چپ و راست مغز مطرح می‌شود.'),
    ]
    for q,a in qas:
        d.paragraph('پرسش: ' + q, bold=True, color=BLUE)
        d.paragraph('پاسخ: ' + a)

    d.heading('اگر هول شدی، این سه جمله را بگو')
    d.bullet('DSA حافظه را از خط زمانی به هندسه مارپیچی منتقل می‌کند.')
    d.bullet('هدف این مرحله، نشان دادن پایداری حافظه و Early Recall است، نه benchmark نهایی accuracy.')
    d.bullet('جزئیات فنی کامل، فرمول وزن‌دهی و کد پس از NDA ارائه می‌شود.')
    path = OUT/'DSA_Speaker_Notes_FA.pdf'
    d.save(path)
    return path

if __name__ == '__main__':
    for p in [executive_pdf(), speaker_pdf()]:
        print(p)
