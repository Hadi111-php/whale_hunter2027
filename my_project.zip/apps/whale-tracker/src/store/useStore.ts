import { create } from 'zustand';

interface User {
  id: string;
  username: string;
  email: string;
}

interface WatchlistItem {
  address: string;
  coin?: string;
}

interface AppState {
  user: User | null;
  isAuthenticated: boolean;
  login: (user: User) => void;
  logout: () => void;
  
  watchlist: WatchlistItem[];
  addToWatchlist: (item: WatchlistItem) => void;
  removeFromWatchlist: (address: string, coin?: string) => void;
  
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const useStore = create<AppState>((set) => ({
  user: null,
  isAuthenticated: false,
  login: (user) => set({ user, isAuthenticated: true }),
  logout: () => set({ user: null, isAuthenticated: false }),
  
  watchlist: [],
  addToWatchlist: (item) => set((state) => ({ 
    watchlist: [...state.watchlist.filter(w => w.address !== item.address || w.coin !== item.coin), item] 
  })),
  removeFromWatchlist: (address, coin) => set((state) => ({
    watchlist: state.watchlist.filter(w => !(w.address === address && w.coin === coin))
  })),
  
  activeTab: 'dashboard',
  setActiveTab: (tab) => set({ activeTab: tab }),
}));
