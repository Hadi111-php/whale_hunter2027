import React, { useEffect, useState } from 'react';
import { useStore } from './store/useStore';
import { AuthPage } from './components/AuthPage';
import { Header } from './components/Header';
import { TraderTable } from './components/TraderTable';
import { StatsCard } from './components/StatsCard';
import { WhaleDetector } from './components/WhaleDetector';
import { MarketStats } from './components/MarketStats';
import { PositionTracker } from './components/PositionTracker';
import { WatchlistAlerts } from './components/WatchlistAlerts';
import { fetchTopTraders } from './services/api';
import { Trader } from './types/trader';
import { downloadTraders } from './utils/export';
import { Download, Users, Wallet, TrendingUp, LayoutDashboard, Fish, BarChart3, Activity, Bell } from 'lucide-react';

export const App: React.FC = () => {
  const { isAuthenticated, activeTab, setActiveTab, user, logout } = useStore();
  const [traders, setTraders] = useState<Trader[]>([]);
  const [selectedTraders, setSelectedTraders] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAuthenticated) return;
    const loadData = async () => {
      try {
        const data = await fetchTopTraders();
        setTraders(data);
      } catch (err) {
        console.error("Failed to load traders", err);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, [isAuthenticated]);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-950 text-gray-100 font-sans">
        <Header />
        <AuthPage />
      </div>
    );
  }

  const handleToggleSelect = (address: string) => {
    const newSelected = new Set(selectedTraders);
    if (newSelected.has(address)) {
      newSelected.delete(address);
    } else {
      newSelected.add(address);
    }
    setSelectedTraders(newSelected);
  };

  const handleSelectAll = (select: boolean) => {
    if (select) {
      setSelectedTraders(new Set(traders.map(t => t.address)));
    } else {
      setSelectedTraders(new Set());
    }
  };

  const handleExport = () => {
    const selectedData = traders.filter(t => selectedTraders.has(t.address));
    downloadTraders(selectedData);
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        const totalVolume = traders.reduce((acc, curr) => acc + curr.volume, 0);
        const bestPnL = Math.max(...traders.map(t => t.pnl));
        const avgWinRate = Math.round(traders.reduce((acc, curr) => acc + curr.winRate, 0) / (traders.length || 1));
        
        return (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <StatsCard 
                title="Total Volume (24h)" 
                value={new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(totalVolume)}
                trend="+12.5%"
                isPositive={true}
                icon={<TrendingUp size={20} />}
              />
              <StatsCard 
                title="Highest PnL" 
                value={new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(bestPnL)}
                trend="+5.2%"
                isPositive={true}
                icon={<Wallet size={20} />}
              />
              <StatsCard 
                title="Average Win Rate" 
                value={`${avgWinRate}%`}
                trend="-2.1%"
                isPositive={false}
                icon={<Users size={20} />}
              />
            </div>
            {loading ? (
              <div className="flex flex-col items-center justify-center py-20 text-gray-500">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mb-4"></div>
                <p>Connecting to HyperLiquid API...</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-semibold text-white">Live Leaderboard</h3>
                  <div className="text-sm text-gray-400">
                    Showing {traders.length} active wallets
                  </div>
                </div>
                <TraderTable 
                  traders={traders} 
                  selectedTraders={selectedTraders}
                  onToggleSelect={handleToggleSelect}
                  onSelectAll={handleSelectAll}
                />
              </div>
            )}
          </div>
        );
      case 'whales':
        return <WhaleDetector whaleThreshold={500000} />;
      case 'market':
        return <MarketStats />;
      case 'live':
        return <PositionTracker />;
      case 'alerts':
        return <WatchlistAlerts />;
      default:
        return null;
    }
  };

  const navItems = [
    { id: 'dashboard', label: 'Leaderboard', icon: LayoutDashboard },
    { id: 'whales', label: 'Whale Detector', icon: Fish },
    { id: 'market', label: 'Market Stats', icon: BarChart3 },
    { id: 'live', label: 'Live Trades', icon: Activity },
    { id: 'alerts', label: 'Alerts & Watchlist', icon: Bell },
  ];

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 font-sans flex flex-col selection:bg-blue-500 selection:text-white">
      <Header />

      <div className="flex flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 gap-8">
        
        {/* Sidebar */}
        <aside className="w-64 flex-shrink-0 hidden md:flex flex-col gap-6">
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4 shadow-lg">
            <div className="flex items-center gap-3 mb-6 px-2">
              <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                {user?.username.charAt(0).toUpperCase()}
              </div>
              <div>
                <div className="font-semibold text-white">{user?.username}</div>
                <div className="text-xs text-gray-400">Pro Member</div>
              </div>
            </div>
            
            <nav className="space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                      activeTab === item.id
                        ? 'bg-blue-600/10 text-blue-500 border border-blue-500/20'
                        : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                    }`}
                  >
                    <Icon size={18} />
                    {item.label}
                  </button>
                );
              })}
            </nav>
            
            <div className="mt-8 pt-4 border-t border-gray-800">
              <button
                onClick={logout}
                className="w-full flex items-center gap-3 px-4 py-2 text-sm text-gray-500 hover:text-red-400 transition-colors"
              >
                Logout
              </button>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 min-w-0 pb-20">
          <div className="mb-6 md:hidden overflow-x-auto flex gap-2 pb-2 scrollbar-hide">
             {navItems.map((item) => (
               <button
                 key={item.id}
                 onClick={() => setActiveTab(item.id)}
                 className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                   activeTab === item.id
                     ? 'bg-blue-600 text-white'
                     : 'bg-gray-900 text-gray-400 hover:text-white'
                 }`}
               >
                 {item.label}
               </button>
             ))}
          </div>
          
          {renderContent()}
        </main>
      </div>

      {/* Sticky Action Bar for Dashboard Selection */}
      <div className={`fixed bottom-0 left-0 right-0 z-40 bg-gray-900 border-t border-gray-800 p-4 transform transition-transform duration-300 ${activeTab === 'dashboard' && selectedTraders.size > 0 ? 'translate-y-0' : 'translate-y-full'}`}>
        <div className="max-w-7xl mx-auto flex items-center justify-between px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-4">
            <span className="text-white font-medium">{selectedTraders.size} wallets selected</span>
            <button 
              onClick={() => handleSelectAll(false)}
              className="text-sm text-gray-400 hover:text-white underline"
            >
              Clear selection
            </button>
          </div>
          <button 
            onClick={handleExport}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white px-6 py-2 rounded-lg font-medium transition-colors shadow-lg shadow-blue-900/20"
          >
            <Download size={18} />
            Export Selected
          </button>
        </div>
      </div>
    </div>
  );
};
