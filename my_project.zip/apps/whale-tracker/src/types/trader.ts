export interface Trader {
  rank: number;
  address: string;
  pnl: number;
  roi: number;
  volume: number;
  winRate: number;
  trades: number;
  isMock?: boolean;
  currentPositions?: Position[];
}

export interface Position {
  id: string;
  coin: string;
  side: "long" | "short";
  szi: number; // size
  entryPx: number;
  markPx: number;
  unrealizedPnl: number;
  marginUsed: number;
  leverage: number;
  timestamp: number;
  isOpen: boolean;
  closedAt?: number;
  realizedPnl?: number;
}

export interface MarketStat {
  coin: string;
  totalVolume: number;
  tradeCount: number;
  longPositions: number;
  shortPositions: number;
  topTraders: string[];
}

export interface WhaleConfig {
  minPositionValue: number; // USD threshold
  minVolume: number;
}

export interface RealTimeUpdate {
  type: "position_open" | "position_close" | "position_update";
  data: Position;
  timestamp: number;
}
