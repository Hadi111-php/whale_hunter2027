import React, { useState, useEffect } from 'react';
import { BarChart3, PieChart, TrendingUp, Activity } from 'lucide-react';
import { fetchMarketStats } from '../services/api';
import { MarketStat } from '../types/trader';
import { StatsCard } from './StatsCard';

export const MarketStats: React.FC = () => {
  const [stats, setStats] = useState<MarketStat[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<'volume' | 'trades'>('volume');

  useEffect(() => {
    const loadStats = async () => {
      setLoading(true);
      try {
        const data = await fetchMarketStats();
        setStats(data);
      } catch (err) {
        console.error("Failed to load market stats", err);
      } finally {
        setLoading(false);
      }
    };
    loadStats();
    
    // Refresh every 2 minutes
    const interval = setInterval(loadStats, 120000);
    return () => clearInterval(interval);
  }, []);

  const sortedStats = [...stats].sort((a, b) => {
    if (sortBy === 'volume') return b.totalVolume - a.totalVolume;
    return b.tradeCount - a.tradeCount;
  });

  const totalVolume = stats.reduce((acc, curr) => acc + curr.totalVolume, 0);
  const totalTrades = stats.reduce((acc, curr) => acc + curr.tradeCount, 0);
  const topCoin = stats.reduce((max, curr) => curr.totalVolume > max.totalVolume ? curr : max, stats[0] || { coin: '-', totalVolume: 0, tradeCount: 0, longPositions: 0, shortPositions: 0, topTraders: [] });

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD', 
      maximumFractionDigits: 0 
    }).format(val);
  };

  return (
    <div className="space-y-6">
      {/* Market Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatsCard 
          title="Total Market Volume" 
          value={formatCurrency(totalVolume)}
          trend="24h"
          isPositive={true}
          icon={<BarChart3 size={20} />}
        />
        <StatsCard 
          title="Total Trades" 
          value={totalTrades.toLocaleString()}
          trend="Active"
          isPositive={true}
          icon={<Activity size={20} />}
        />
        <StatsCard 
          title="Top Trading Pair" 
          value={topCoin?.coin || '-'}
          trend={topCoin ? formatCurrency(topCoin.totalVolume) : ''}
          isPositive={true}
          icon={<TrendingUp size={20} />}
        />
        <StatsCard 
          title="Active Markets" 
          value={stats.length.toString()}
          trend="Perps"
          isPositive={true}
          icon={<PieChart size={20} />}
        />
      </div>

      {/* Top Markets Table */}
      <div className="bg-gray-800 rounded-xl border border-gray-700 shadow-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-700 flex justify-between items-center">
          <h3 className="text-lg font-semibold text-white">Top Trading Markets</h3>
          <div className="flex items-center gap-4">
            <div className="flex bg-gray-900 rounded-lg p-1">
              <button
                onClick={() => setSortBy('volume')}
                className={`px-3 py-1 text-sm rounded ${sortBy === 'volume' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'}`}
              >
                By Volume
              </button>
              <button
                onClick={() => setSortBy('trades')}
                className={`px-3 py-1 text-sm rounded ${sortBy === 'trades' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'}`}
              >
                By Trades
              </button>
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-gray-400">
            <thead className="bg-gray-900 text-gray-200 uppercase font-medium">
              <tr>
                <th className="px-6 py-4">Market</th>
                <th className="px-6 py-4 text-right">Volume (24h)</th>
                <th className="px-6 py-4 text-right">Trades</th>
                <th className="px-6 py-4 text-right">Avg Trade Size</th>
                <th className="px-6 py-4">Market Share</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {loading ? (
                <tr>
                  <td colSpan={5} className="px-6 py-8">
                    <div className="flex flex-col items-center justify-center text-gray-500">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mb-2"></div>
                      <p>Analyzing market data...</p>
                    </div>
                  </td>
                </tr>
              ) : sortedStats.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                    No market data available
                  </td>
                </tr>
              ) : (
                sortedStats.map((stat, index) => {
                  const avgTradeSize = stat.tradeCount > 0 ? stat.totalVolume / stat.tradeCount : 0;
                  const marketShare = totalVolume > 0 ? (stat.totalVolume / totalVolume) * 100 : 0;
                  
                  return (
                    <tr key={stat.coin} className="hover:bg-gray-750 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="bg-blue-600 text-white w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">
                            {index + 1}
                          </div>
                          <div>
                            <div className="font-medium text-white">{stat.coin}</div>
                            <div className="text-xs text-gray-500">Perpetual</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right text-white font-medium">
                        {formatCurrency(stat.totalVolume)}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <span className="bg-blue-600 text-white px-2 py-1 rounded-full text-xs font-medium">
                          {stat.tradeCount.toLocaleString()}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right text-gray-300">
                        {formatCurrency(avgTradeSize)}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-24 h-2 bg-gray-700 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-gradient-to-r from-blue-500 to-green-500" 
                              style={{ width: `${Math.min(marketShare * 10, 100)}%` }}
                            />
                          </div>
                          <span className="text-sm text-gray-300">{marketShare.toFixed(1)}%</span>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Market Insights */}
      <div className="bg-gray-900 rounded-xl border border-gray-700 p-6">
        <h4 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <Activity size={18} className="text-blue-400" />
          Market Insights
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-300">
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Most Active Pair:</span>
              <span className="font-medium text-white">{topCoin?.coin || 'N/A'}</span>
            </div>
            <div className="flex justify-between">
              <span>Total Markets:</span>
              <span className="font-medium text-white">{stats.length}</span>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>Volume Leader:</span>
              <span className="font-medium text-white">{topCoin?.coin || 'N/A'}</span>
            </div>
            <div className="flex justify-between">
              <span>Avg Trades/Market:</span>
              <span className="font-medium text-white">{Math.round(totalTrades / (stats.length || 1)).toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};