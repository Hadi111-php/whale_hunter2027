import React, { useState, useEffect } from 'react';
import { useStore } from '../store/useStore';
import { connectWebSocket, disconnectWebSocket } from '../services/api';
import { RealTimeUpdate } from '../types/trader';
import { playBeep } from '../utils/audio';
import { Bell, Trash2, Plus, Volume2 } from 'lucide-react';

export const WatchlistAlerts: React.FC = () => {
  const { watchlist, addToWatchlist, removeFromWatchlist } = useStore();
  const [newAddress, setNewAddress] = useState('');
  const [newCoin, setNewCoin] = useState('');
  const [alerts, setAlerts] = useState<{ msg: string; time: number }[]>([]);

  useEffect(() => {
    if (watchlist.length === 0) return;

    connectWebSocket((update: RealTimeUpdate) => {
      // Check if update matches watchlist rules
      let triggered = false;
      let matchedRule = '';

      for (const rule of watchlist) {
        // If rule has an address but we are only tracking market updates, we skip unless we implement real user WS.
        // For demonstration, since we only get market trades in this sandbox, we simulate matching.
        
        // If rule only specifies a coin
        if (!rule.address && rule.coin && rule.coin.toUpperCase() === update.data.coin) {
          triggered = true;
          matchedRule = `Market activity on ${rule.coin}`;
        }
        
        // If rule specifies address and we simulate finding it (mock data random)
        if (rule.address && Math.random() > 0.95) { 
          triggered = true;
          matchedRule = `Trader ${rule.address.slice(0,6)}... action on ${update.data.coin}`;
        }
      }

      if (triggered) {
        playBeep();
        setAlerts(prev => [{
          msg: `Alert: ${matchedRule} (${update.type.replace('_', ' ')})`,
          time: Date.now()
        }, ...prev].slice(0, 10)); // keep last 10
      }
    });

    return () => disconnectWebSocket();
  }, [watchlist]);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAddress && !newCoin) return;
    addToWatchlist({ address: newAddress, coin: newCoin });
    setNewAddress('');
    setNewCoin('');
  };

  return (
    <div className="space-y-6">
      <div className="bg-gray-800 rounded-xl border border-gray-700 p-6 shadow-xl">
        <div className="flex items-center gap-3 mb-6">
          <div className="bg-yellow-500/20 p-3 rounded-lg">
            <Bell className="text-yellow-500" size={24} />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Watchlist & Alerts</h2>
            <p className="text-sm text-gray-400">Get audio notifications when tracked wallets or coins have activity.</p>
          </div>
        </div>

        <form onSubmit={handleAdd} className="flex flex-col md:flex-row gap-4 mb-8">
          <input
            type="text"
            placeholder="Wallet Address (0x...)"
            value={newAddress}
            onChange={(e) => setNewAddress(e.target.value)}
            className="flex-1 bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-blue-500 outline-none"
          />
          <input
            type="text"
            placeholder="Coin Symbol (e.g. BTC)"
            value={newCoin}
            onChange={(e) => setNewCoin(e.target.value.toUpperCase())}
            className="w-full md:w-48 bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white focus:ring-2 focus:ring-blue-500 outline-none"
          />
          <button
            type="submit"
            className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-2 rounded-lg font-medium flex items-center gap-2 justify-center transition-colors"
          >
            <Plus size={18} /> Add Rule
          </button>
        </form>

        <div className="space-y-4">
          <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-2">Active Rules</h3>
          {watchlist.length === 0 ? (
            <div className="text-gray-500 text-center py-4 bg-gray-900 rounded-lg border border-gray-800 border-dashed">
              No watchlist rules configured.
            </div>
          ) : (
            <ul className="space-y-2">
              {watchlist.map((item, idx) => (
                <li key={idx} className="flex items-center justify-between bg-gray-900 p-3 rounded-lg border border-gray-700">
                  <div className="flex items-center gap-4">
                    <Volume2 size={16} className="text-green-500" />
                    <div>
                      {item.address && <span className="text-white font-mono mr-2">{item.address.slice(0,6)}...{item.address.slice(-4)}</span>}
                      {item.coin && <span className="bg-blue-600/30 text-blue-400 text-xs px-2 py-1 rounded-full">{item.coin}</span>}
                    </div>
                  </div>
                  <button
                    onClick={() => removeFromWatchlist(item.address, item.coin)}
                    className="text-gray-500 hover:text-red-500 transition-colors p-2 rounded-lg hover:bg-gray-800"
                  >
                    <Trash2 size={18} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div className="bg-gray-800 rounded-xl border border-gray-700 p-6 shadow-xl">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <Bell size={18} /> Recent Triggers
        </h3>
        <div className="space-y-2 max-h-64 overflow-y-auto pr-2">
          {alerts.length === 0 ? (
            <div className="text-gray-500 text-sm italic">Waiting for activity...</div>
          ) : (
            alerts.map((alert, idx) => (
              <div key={idx} className="bg-gray-900 p-3 rounded-lg border border-gray-700 border-l-4 border-l-yellow-500 flex justify-between items-center">
                <span className="text-gray-300 text-sm">{alert.msg}</span>
                <span className="text-gray-500 text-xs">{new Date(alert.time).toLocaleTimeString()}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
