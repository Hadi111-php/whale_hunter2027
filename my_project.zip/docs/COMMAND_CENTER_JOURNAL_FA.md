# 🏛️ دفترچه وقایع و راهنمای اتاق فرمان مرکزی (Command Center Journal)
### ثبت رسمی تمام تصمیمات، معماری پروژه‌ها، مصوبات و دستورات کاری برای هادی طباطبایی

**مدیر و پژوهشگر ارشد:** هادی طباطبایی (TaHa111)  
**دستیار و فرمانده عملیاتی:** دستیار هوشمند Arena.ai  
**شاخه فعال و پایدار:** `arena/01a0255b-main-arena-conn`  
**مخزن رسمی:** `HaadiTaba111/Main_Arena_conn`  

---

## 🗺️ ۱. فهرست جامع پروژه‌های تفکیک‌شده در پوشه `apps/`

| نام پروژه | مسیر پوشه | پورت / دستور اجرا | وضعیت و توضیحات |
|---|---|---|---|
| **🧠 Qwen-Hands-Eyes** | `apps/qwen-hands-eyes` | `python3 main.py --port 8765` (پورت ۸۷۶۵) | مغز آفلاین دو مدلی (Qwen + DeepSeek R1) با بینایی دسکتاپ، کنترل ماوس/کیبورد، شل امن و درگاه اندروید (Feet) |
| **🎬 Clip Maker Studio** | `apps/clip-studio` | `python3 app.py` (پورت ۵۰۰۰) | استودیو ساخت کلیپ و لیریکس دوزبانه با افکت رعدوبرق چندباندی و سیستم Tap to Sync |
| **📊 Adaptive Ratio Brain** | `apps/adaptive-ratio-brain` | `npm run dev` (پورت ۵۱۷۳) | موتور هوشمند تله‌های نقدینگی و واگرایی صرافی‌ها بر پایه نسبت‌های OI، حجم و فاندینگ |
| **🐋 Whale Tracker** | `apps/whale-tracker` | `npm run dev` (پورت ۵۱۷۴) | ردیاب لایو نهنگ‌ها و اسکرپر لیدربورد هایپرلیکوئید برای پوزیشن‌های بالای ۵۰۰k |
| **📈 Futures Scalp Lab** | `apps/futures-scalp-lab` | `python3 -m scalplab auto --data bybit` | آزمایشگاه اعتبارسنجی چندمدلی اسکالپ، مدیریت ریسک و اتصال زنده به صرافی Bybit |
| **📱 Futures PWA** | `apps/futures-pwa` | `node server.js` (پورت ۸۷۸۷) | وب‌اپلیکیشن ترید فیوچرز با دکمه قطع اضطراری (Kill) و سوییچ دیتای زنده Bybit |
| **💻 Local Cursor Agent** | `apps/local-cursor-agent` | `python3 dashboard.py` (پورت ۸۷۶۵) | دستیار کدنویسی دسکتاپ و اسکریپت‌های تولید PDFهای رسمی Pre-NDA اسپیرال |
| **📜 DSA Dashboard & Poet** | `apps/dsa-command-dashboard` | `npm run dev` (پورت ۳۰۰۰) | داشبورد آزمایش‌های اسپیرال Fade-Not-Forget و دموی شاعر عصب‌نمادین |
| **🔐 Secure Wake Prototype** | `apps/clip-studio/secure_wake_prototype` | `python3 test_security.py` | پروتوتایپ امنیتی بیدارباش‌محور، فایروال محتوایی، ضد هکر و خواب اجباری نامتقارن |

---

## 🔬 ۲. مبانی علمی، ثوابت تثبیت‌شده و ماتریس استتار DSA

* **نسخه مبنا:** DSA v4 (نسخه v3 به دلیل عدم توازن کلاس‌ها منسوخ شد).
* **معادله ریاضی بازداری حافظه سیناپسی:**
  $$W_{\text{DSA}}(k, \Delta t) = \max\left(w_{\min}, \gamma \cdot e^{-\lambda \cdot \Delta t} \cdot \left(1 + 0.2 \cdot \left|\sin\left(\frac{k \cdot \pi}{2}\right)\right|\right)\right)$$
* **ثوابت تحلیلی بهینه و محرمانه:**
  - نرخ زوال نمایی نرم: $\lambda = 0.15$
  - ضریب نوسان و گام اولیه: $\gamma = 0.40$
  - کف بازداری حداقلی ماندگاری: $w_{\min} = 0.15$
* **فرمول نقطه رزونانس طلایی (نقطه فرشته):**
  $$N^* = \frac{-\ln(w_{\min})}{\lambda} = \frac{1.8971}{0.15} \approx 12.64 \approx 12$$
  *(در $N=12$ بازیابی حافظه Early Recall به ۱۰۰٪ کامل می‌رسد).*
* **قوانین ابدی ریاضی و فیزیک:** با نرخ زوال $\lambda = 0$ در ستون فقرات مرکزی اسپیرال قفل می‌شوند.
* **نقطه افت $N=18$:** به عنوان ابزار فازی پاکسازی نویزها و زباله‌روبی فعال (Active Garbage Collection) تعریف شده است.
* 🚫 **ماتریس استتار واژگانی جهت حفاظت از مالکیت فکری (IP Protection):**
  - واژه ممنوعه: `Spiral` $\rightarrow$ واژه پوششی رسمی: `Non-Euclidean Topological State-Space`
  - واژه ممنوعه: `Linear` $\rightarrow$ واژه پوششی رسمی: `Euclidean Uniform State Trajectory`
  - واژه ممنوعه: `12-points / N=12` $\rightarrow$ واژه پوششی رسمی: `Discrete Phase Gating (Harmonic Eigen-State)`
  - واژه ممنوعه: `Fading / Fade Not Forget` $\rightarrow$ واژه پوششی رسمی: `Stochastic Synaptic Attenuation with Non-Zero Retention Floor`
  - واژه ممنوعه: `Dual Spiral` $\rightarrow$ واژه پوششی رسمی: `Asymmetric Dual-State Engine (Analytical & Associative)`

---

## 📑 ۳. اسناد ثبت‌شده و وضعیت رسمی Zenodo و دانشگاه شریف

* 🌟 **وضعیت ثبت جهانی در Zenodo (سرن اروپا):**
  - **وضعیت:** **منتشرشده رسمی (Published / Version 1 / Open Access / Preprint) ✅**
  - **شناسه دیجیتال دائمی (DOI):** [`10.5281/zenodo.22780163`](https://doi.org/10.5281/zenodo.22780163)
  - **لینک مستقیم رکورد در Zenodo:** [https://zenodo.org/records/22780163](https://zenodo.org/records/22780163)
  - **شناسه بین‌المللی پژوهشگر (ORCID):** [`0009-0006-0210-7479`](https://orcid.org/0009-0006-0210-7479)
  - **تاریخ رسمی ثبت بین‌المللی:** **۱۶ سپتامبر ۲۰۲۶**
  - **نویسنده:** هادی طباطبایی (Tabatabaei, Hadi)
  - **عنوان رسمی:** `Dynamic Synaptic Architecture (DSA): A Non-Euclidean Topological State-Space Framework for Mitigating Catastrophic Forgetting in Continual Learning`

1. `docs/ZENODO_PAPER_PRE_NDA_EN.md` — وایت‌پیپر و مقاله پیش‌پرینت انگلیسی رسمی منتشرشده در Zenodo.
2. `docs/ZENODO_PAPER_PRE_NDA_FA.md` — متن کامل فارسی مقاله جهت ثبت و مطالعه.
3. `docs/DSA_SHARIF_DEFENSE_QA_FA.md` — متن کامل دفاعیه و پاسخ به ۶ سوال کلیدی استاد دانشگاه شریف با تمثیل‌های اینشتینی.
4. `docs/DSA_PreNDA_Executive_Brief_FA.pdf` — فایل رسمی و شیک خلاصه مدیریتی و جداول تست برای ارائه یا دانلود.
5. `docs/DSA_Speaker_Notes_FA.pdf` — یادداشت‌های سخنرانی و پاسخ به سوالات چالش‌برانگیز داوران.
10. `docs/PYTHONANYWHERE_DEPLOY_GUIDE_FA.md` — راهنمای جامع استقرار رایگان پروژه‌های پایتون و لیریکس روی PythonAnywhere و Render.com.
11. `docs/UNIFIED_NET_FISHING_AUTO_TRADER_FA.md` — سند جامع معماری موتور اتوترید یکپارچه «تور ماهیگیری» (تجمیع ۵ پروژه کریپتو).
12. `docs/WORK_ACTION_PACKET_FA.md` — بسته عملیاتی و آماده ارسال ایمیل‌های جذب گرنت و ثبت پتنت به دانشگاه شریف و غول‌های AI.
13. `docs/MOBILE_APK_SETUP_GUIDE_FA.md` — راهنمای جامع تبدیل و اجرای اپلیکیشن‌های کریپتو و لیریکس به APK و PWA روی گوشی همراه.
14. `docs/TERMUX_MOBILE_GUIDE_FA.md` — راهنمای اجرای مستقل و ۱۰۰٪ محلی پروژه‌ها در محیط Termux اندروید.
15. `docs/ZENODO_SUBMISSION_METADATA.md` — متادیتاهای ثبت رسمی.
16. `docs/DSA_STEALTH_NAMING_AND_IP_PROTECTION_FA.md` — ماتریس استتار واژگانی و بایکوت کلمات کلیدی.
17. `docs/DSA_NLP_VERIFIED_BENCHMARK_RESULTS_FA.md` — گزارش رسمی نتایج اعتبارسنجی بنچمارک زبانی روی RTX 3060.
18. `docs/DEEPSEEK_AUDIT_RESPONSE_FA.md` — پاسخ فنی به ممیزی دیپ‌سیک و تست برچسب‌های تصادفی.

---

## 🎣 ۴. پکیج اتوترید تور ماهیگیری (Net Fishing Suite)

* **موتور پایتونی تور ماهیگیری:** `apps/futures-scalp-lab/scalplab/net_fishing_engine.py`
* **سند تحلیلی و راهنمای استراتژی:** `docs/UNIFIED_NET_FISHING_AUTO_TRADER_FA.md`

---

## 📱 ۴. پکیج همراه و APK برای اندروید

* **پروژه بومی کریپتو فیوچرز بای‌بیت:** `android/CryptoScalpLab/`
* **پروژه بومی استودیو لیریکس:** `android/LyraXStudio/`
* **اسکریپت‌های اجرای مستقل در ترموکس:** `termux_setup.sh` و `termux_start.sh`
* **ابزار مدیریت پایش اتصال موبایل:** `tools/build_mobile_apks.py` و `build_apks.bat`

---

## ⚡ ۵. دستورات اجرایی سریع (Cheat Sheet)

* **اجرای اتاق فرمان لانچر:** `python3 launcher.py --port 9000` (یا `./start.sh`)
* **اجرای کلیپ‌ساز:** `cd apps/clip-studio && python3 app.py` (پورت ۵۰۰۰)
* **اجرای ترید فیوچرز بای‌بیت:** `cd apps/futures-pwa && node server.js` (پورت ۸۷۸۷)
* **اجرای مغز دست و چشم:** `cd apps/qwen-hands-eyes && python3 main.py --port 8765` (پورت ۸۷۶۵)
* **پوش خودکار به گیت‌هاب:** `cd /mnt/c/APP/arena/Main_Arena_conn && git add -A && git commit -m "update" && git push origin arena/01a0255b-main-arena-conn`
