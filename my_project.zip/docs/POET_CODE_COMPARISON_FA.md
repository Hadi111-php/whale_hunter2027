# مقایسهٔ کد شاعر: زیپ جدید در برابر کد نوشته‌شده در این ریپو

تاریخ بررسی: ۲۰۲۶-۰۸-۲۶
روش: استخراج هر دو ZIP در محیط موقت و مقایسهٔ بایت‌به‌بایت (`cmp`)، به‌علاوهٔ اجرای واقعی تست import.
همهٔ عددها و ادعاهای این سند با دستور قابل بازتولیدند؛ هیچ ادعای علمیِ آزمایش‌نشده‌ای اینجا ثبت نشده است.

---

## ۱) فایل جدید چیست؟

`archive/raw/persian-llm-training-framework (28).zip`
— ۱۰۲ فایل، بدون پوشهٔ ریشه، زمان فایل‌ها `2026-08-11 07:03`.

مقایسه با `archive/raw/llm_mollana.zip` (۱۰۴ فایل، پوشهٔ ریشهٔ `llm_mollana/`، زمان فایل‌ها `2026-08-21 09:57`):

| بررسی | نتیجه |
|---|---|
| فایل‌های مشترک | ۱۰۲ |
| فایل‌های مشترکِ **کاملاً یکسان** (`cmp -s`) | **۱۰۲ از ۱۰۲** (صفر اختلاف) |
| فقط در `llm_mollana.zip` | `CLAUDE_HANDOFF.md`، `DSA_LEGACY.md` |
| فقط در زیپ (۲۸) | هیچ |

**نتیجه:** زیپ جدید زیرمجموعهٔ دقیق `llm_mollana.zip` است. یعنی محتوای تازه‌ای اضافه نشده؛ `llm_mollana.zip` بسته‌بندی جدیدترِ همان پروژه است (۱۰ روز بعد، با دو سند اضافه). هیچ‌کدام حذف نمی‌شوند؛ هر دو در `archive/raw/` می‌مانند.

---

## ۲) کد شاعر داخل زیپ چه‌کار می‌کند؟ (واقعاً، نه آن‌چه نام فایل می‌گوید)

سه فایل مسئول شعر:

- `src/app/api/poet/route.ts` — اکشن‌های `generate-verse`، `generate-poem`، `generate-metered`، `story-poem`.
- `src/lib/poetry-generator.ts` — موتور تولید.
- `src/lib/poetry-db.ts` + `src/lib/persian-stories.ts` — بانک قافیه/داستان.

موتور تولید در `poetry-generator.ts` **قالب + بانک واژه با انتخاب تصادفی** است، نه شبکهٔ عصبی:

- `PERSIAN_RHYMES`، `POEM_TEMPLATES`، `VERSE_PATTERNS` (۶ قالب مثل `` `چو ${topic} ${getRandomVerb()} ${getRandomAdjective()} ${rhyme}` ``)
- `VERBS`، `ADJECTIVES`، `ADVERBS`، `ACTIONS`، `PRAISES`، `PLACES`، `RANDOM_TOPICS`
- توابع `getRandomVerb/Adjective/Adverb/Action/Praise/Place` و `findRhyme`

یعنی: «شعر جدید می‌سازه» درست است، اما ساختن = چیدن تصادفی واژه در قالب. **هیچ وزنی از DSA در این مسیر وجود ندارد**؛ جست‌وجوی `poet|poem|poetry` در فایل‌های اسپیرال/آموزش زیپ، تنها به `PERSIAN_POEMS` (دیتاست) می‌رسد، نه به موتور شاعر.

## ۳) مسیر آموزش اسپیرال در زیپ (جدا از شاعر)

- `spiral-real-train.py` → `SpiralPoint`, `HolographicMemory`, `SpiralTimeLayer`, `SpiralTimeModel`, `StandardTransformer`؛ داده: `PERSIAN_POEMS` با **۳۰ شعر**.
- `spiral-real-train.py:54` → `self.register_buffer('lambda_decay', torch.tensor(0.1))` و خط ۶۸: `time_weight = torch.exp(-self.lambda_decay * age)`.
  → **λ = 0.1 ثابت، بدون GAMMA، بدون MIN_WEIGHT (کف وزن).**
- `src/lib/spiral-time.ts:51` → `lambda: 0.1`، خط ۱۲۴ → `isDecayed: weight < 0.1`.
- `spiral-time-v2-fixed.py` / `spiral-time-v3-optimized.py` → به‌جای ضرب ساده، `decay_gate` سیگمویدیِ یادگیرنده.

### باگ تأییدشده در زیپ
`train-both-models.py:17` → `from spiral_real_train import SpiralTimeModel, StandardTransformer`
اما نام فایل `spiral-real-train.py` (با خط تیره) است؛ ماژول `spiral_real_train` وجود ندارد.
اجرای واقعی: `python3 -c "import spiral_real_train"` → `ModuleNotFoundError: No module named 'spiral_real_train'`.
پس `train-both-models.py` همان‌طور که در زیپ است اجرا نمی‌شود (نیاز به تغییر نام فایل یا `importlib`).

---

## ۴) کد من در این ریپو چه بود؟

جست‌وجوی `poet|poem|poetry` در درخت کاری: تنها `docs/PORTFOLIO_AND_DSA_POET_DEMO_PLAN_FA.md`.
→ **من تا امروز هیچ موتور شاعری ننوشته‌ام.** آن‌چه نوشتم هستهٔ آزمایش است:

`apps/dsa-command-dashboard/research/greeting_demo/greeting_dsa_demo.py`

- مدل: `IntentGRU` (از صفر، بدون مدل از پیش‌آموزنده‌شده)
- مقایسه: `method in ("linear", "dsa_v4")` با مدل/seed/lr/batch یکسان؛ تنها تفاوت = سیاست مرور دادهٔ قبلی
- وزن‌دهی: `dsa_weight(k, delta_t, lam, gamma, min_weight)`
- پیش‌فرض‌های خط فرمان: `--lam .15 --gamma .4 --min-weight .15 --seeds 42 123 777 --steps-per-stage 240`
- خروجی: `results/run.json` + `results/summary.csv`
- وضعیت: `py_compile OK` — **هنوز روی GPU تو اجرا نشده، پس هیچ عددی از آن ثبت نشده است.**

---

## ۵) جدول جمع‌بندی

| محور | شاعر زیپ (`poetry-generator.ts`) | اسپیرال زیپ (`spiral-real-train.py`) | DSA v4 (مرجع + دمو من) |
|---|---|---|---|
| ماهیت | قالب + انتخاب تصادفی | ترنسفورماتور/لایهٔ اسپیرال | سیاست مرور روی GRU |
| یادگیری واقعی | ندارد | دارد (۳۰ شعر، λ ثابت) | دارد |
| λ | — | `0.1` ثابت | `0.15` (CLI) |
| GAMMA (تقویت دوره‌ای) | — | ندارد | `0.4` (CLI) |
| MIN_WEIGHT (کف فراموشی) | — | ندارد (فقط آستانهٔ `0.1` برای «محو شده») | `0.15` (CLI) |
| کنترل‌شده با seed چندگانه | — | نه | بله (۴۲/۱۲۳/۷۷۷) |
| خروجی ثبت‌شدهٔ قابل استناد | نه | نه (اسکریپت با باگ import) | هنوز اجرا نشده |

## ۶) چه چیزی از این زیپ برداشته می‌شود؟

1. `PERSIAN_POEMS` (۳۰ شعر) به‌عنوان دیتاست کوچک فارسی — قابل استفاده در دمو.
2. بانک قافیه/قالب `poetry-generator.ts` به‌عنوان **ارزیاب/قیدِ سطحی** (وزن و قافیه)، نه به‌عنوان مغز تولید.
3. `spiral-real-train.py` به‌عنوان نمونهٔ معماریِ مقایسه (Spiral vs Standard) — با λ قابل تنظیم.

**مسیر درست برای «شاعر DSA v4»:** شاعر قالبی جای خود را به یک مدل زبانی کوچکِ واقعاً آموزش‌دیده می‌دهد، و سیاست مرور داده با فرمول v4 (`λ=0.15, γ=0.4, floor=0.15`) وزن‌دهی می‌شود؛ سپس با seed چندگانه و کنترل یکسان مقایسه می‌شود. تا وقتی آن اجرا نشده، هیچ برتری‌ای برای شاعر DSA اعلام نمی‌شود.
